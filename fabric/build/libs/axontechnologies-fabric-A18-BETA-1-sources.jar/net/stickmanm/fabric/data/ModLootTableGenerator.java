package net.stickmanm.fabric.data;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_1802;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.entity.ModEntities;
import net.stickmanm.axontechnologies.item.ModItems;

public class ModLootTableGenerator extends FabricBlockLootTableProvider {

    public ModLootTableGenerator(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void method_10379() {
        //Ores
        method_45988(ModBlocks.MIMICARIUM_ORE.get(),method_45981(ModBlocks.MIMICARIUM_ORE.get(), ModItems.MIMICARIUM.get()));
        method_45988(ModBlocks.DEEPSLATE_MIMICARIUM_ORE.get(),method_45981(ModBlocks.DEEPSLATE_MIMICARIUM_ORE.get(), ModItems.MIMICARIUM.get()));
        method_45988(ModBlocks.FAKESTONE_IRON_ORE.get(),method_45981(ModBlocks.FAKESTONE_IRON_ORE.get(), class_1802.field_33400));
        method_45988(ModBlocks.FAKESTONE_GOLD_ORE.get(),method_45981(ModBlocks.FAKESTONE_GOLD_ORE.get(), class_1802.field_33402));
        method_45988(ModBlocks.FAKESLATE_IRON_ORE.get(),method_45981(ModBlocks.FAKESTONE_IRON_ORE.get(), class_1802.field_33400));
        method_45988(ModBlocks.FAKESLATE_GOLD_ORE.get(),method_45981(ModBlocks.FAKESTONE_GOLD_ORE.get(), class_1802.field_33402));
        method_45988(ModBlocks.THUNDERANIUM_ORE.get(),method_45981(ModBlocks.THUNDERANIUM_ORE.get(), ModItems.REFINED_THUNDERANIUM.get()));
        method_45988(ModBlocks.RENDERIUM_ORE.get(),method_45981(ModBlocks.RENDERIUM_ORE.get(), ModItems.RENDERIUM.get()));
        method_45988(ModBlocks.DENDERIUM_ORE.get(),method_45981(ModBlocks.DENDERIUM_ORE.get(), ModItems.DENDERIUM.get()));
        method_45988(ModBlocks.CORRUPTINITE_ORE.get(),method_45981(ModBlocks.CORRUPTINITE_ORE.get(), ModItems.UNSTABLE_CORRUPTINITE.get()));


        //Thundered Tree
        method_46025(ModBlocks.THUNDERED_LOG.get());
        method_46025(ModBlocks.THUNDERED_WOOD.get());
        method_46025(ModBlocks.THUNDERED_PLANKS.get());
        method_46025(ModBlocks.THUNDERED_SAPLING.get());
        method_46025(ModBlocks.STRIPPED_THUNDERED_LOG.get());
        method_46025(ModBlocks.STRIPPED_THUNDERED_WOOD.get());
        method_45999(ModBlocks.THUNDERED_LEAVES.get(),ModBlocks.THUNDERED_LEAVES.get());

        //Dreadstone and Dreadstone Ores
        method_46025(ModBlocks.DREADSTONE.get());
        method_46025(ModBlocks.REINFORCED_DREADSTONE.get());
        method_46025(ModBlocks.REINFORCED_DREADSTONE_STAIRS.get());
        method_46025(ModBlocks.REINFORCED_DREADSTONE_WALL.get());
        method_46025(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get());
        method_46025(ModBlocks.REINFORCED_DREADSTONE_GLASS.get());
        method_45988(ModBlocks.REINFORCED_DREADSTONE_DOOR.get(), method_46022(ModBlocks.REINFORCED_DREADSTONE_DOOR.get()));
        method_45988(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get(), method_45980(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get()));
        method_45988(ModBlocks.DREADSTONE_DIAMOND_ORE.get(),method_45981(ModBlocks.DREADSTONE_DIAMOND_ORE.get(), class_1802.field_8477));
        method_45988(ModBlocks.DREADSTONE_THUNDERANIUM_ORE.get(),method_45981(ModBlocks.DREADSTONE_THUNDERANIUM_ORE.get(), ModItems.RAW_THUNDERANIUM.get()));
        method_45988(ModBlocks.DREADSTONE_NETHERITE_ORE.get(),method_45981(ModBlocks.DREADSTONE_NETHERITE_ORE.get(), ModItems.RAW_NETHERITE.get()));
        method_45988(ModBlocks.VOID_COAL_ORE.get(),method_45981(ModBlocks.VOID_COAL_ORE.get(), ModItems.VOID_COAL.get()));
        method_46025(ModBlocks.VOID_COAL_BLOCK.get());

        method_45988(ModBlocks.MWDC_ORE.get(),method_45981(ModBlocks.MWDC_ORE.get(), ModItems.MWDC.get()));
        method_45988(ModBlocks.DCDC_ORE.get(),method_45981(ModBlocks.DCDC_ORE.get(), ModItems.DCDC.get()));
        method_45988(ModBlocks.TLDC_ORE.get(),method_45981(ModBlocks.TLDC_ORE.get(), ModItems.TLDC.get()));
        method_45988(ModBlocks.CLDC_ORE.get(),method_45981(ModBlocks.CLDC_ORE.get(), ModItems.CLDC.get()));

        //MISC
        method_46025(ModBlocks.VOIDSTONE.get());
        method_46025(ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get());
        method_46025(ModBlocks.FAKESTONE.get());
        method_46025(ModBlocks.FAKESLATE.get());
        method_46025(ModBlocks.CHARGED_DIRT.get());
        method_46025(ModBlocks.THUNDERANIUM_PORTAL_FRAME.get());
        method_46025(ModBlocks.THUNDERED_STONE.get());
        method_46025(ModBlocks.CORRUPTED_DIRT.get());
        method_46025(ModBlocks.CORRUPTED_STONE.get());
        method_46025(ModBlocks.CORRUPTION_PORTAL_FRAME.get());
        method_46025(ModBlocks.CORRUPTION_BLOCK.get());

        //TNT
        method_46025(ModBlocks.THUNDERANIUM_TNT.get());
        method_46025(ModBlocks.RED_THUNDERANIUM_TNT.get());
        method_46025(ModBlocks.AXON_ALLOY_TNT.get());




    }
}
