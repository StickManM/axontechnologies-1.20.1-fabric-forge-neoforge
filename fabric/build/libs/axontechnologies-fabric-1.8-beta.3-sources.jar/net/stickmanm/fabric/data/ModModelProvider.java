package net.stickmanm.fabric.data;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4946;
import net.minecraft.data.client.*;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.item.ModItems;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        //Ores
        blockStateModelGenerator.method_25650(ModBlocks.MIMICARIUM_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.DEEPSLATE_MIMICARIUM_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.RENDERIUM_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.DENDERIUM_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.FAKESTONE_IRON_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.FAKESTONE_GOLD_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.FAKESLATE_IRON_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.FAKESLATE_GOLD_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.THUNDERANIUM_ORE.get());


        //Thundered Tree Blocks
        blockStateModelGenerator.method_25676(ModBlocks.THUNDERED_LOG.get()).method_25730(ModBlocks.THUNDERED_LOG.get()).method_25728(ModBlocks.THUNDERED_WOOD.get());
        blockStateModelGenerator.method_25676(ModBlocks.STRIPPED_THUNDERED_LOG.get()).method_25730(ModBlocks.STRIPPED_THUNDERED_LOG.get()).method_25728(ModBlocks.STRIPPED_THUNDERED_WOOD.get());

        class_4910.class_4912 thunderedPlanksPool = blockStateModelGenerator.method_25650(ModBlocks.THUNDERED_PLANKS.get());
        blockStateModelGenerator.method_25658(ModBlocks.THUNDERED_DOOR.get());
        blockStateModelGenerator.method_25671(ModBlocks.THUNDERED_TRAPDOOR.get());
        thunderedPlanksPool.method_25721(ModBlocks.THUNDERED_FENCE.get());
        thunderedPlanksPool.method_25722(ModBlocks.THUNDERED_FENCE_GATE.get());
        thunderedPlanksPool.method_25725(ModBlocks.THUNDERED_STAIRS.get());
        thunderedPlanksPool.method_25724(ModBlocks.THUNDERED_SLAB.get());
        thunderedPlanksPool.method_25716(ModBlocks.THUNDERED_BUTTON.get());
        thunderedPlanksPool.method_25723(ModBlocks.THUNDERED_PRESSURE_PLATE.get());

        blockStateModelGenerator.method_25650(ModBlocks.THUNDERED_LEAVES.get());
        blockStateModelGenerator.method_25603(ModBlocks.THUNDERED_SAPLING.get(), class_4910.class_4913.field_22840);

        //Corrupted Tree Blocks
        blockStateModelGenerator.method_25676(ModBlocks.CORRUPTED_LOG.get()).method_25730(ModBlocks.CORRUPTED_LOG.get()).method_25728(ModBlocks.CORRUPTED_WOOD.get());
        blockStateModelGenerator.method_25676(ModBlocks.STRIPPED_CORRUPTED_LOG.get()).method_25730(ModBlocks.STRIPPED_CORRUPTED_LOG.get()).method_25728(ModBlocks.STRIPPED_CORRUPTED_WOOD.get());

        class_4910.class_4912 corruptedPlanksPool = blockStateModelGenerator.method_25650(ModBlocks.CORRUPTED_PLANKS.get());
        blockStateModelGenerator.method_25658(ModBlocks.CORRUPTED_DOOR.get());
        blockStateModelGenerator.method_25671(ModBlocks.CORRUPTED_TRAPDOOR.get());
        corruptedPlanksPool.method_25721(ModBlocks.CORRUPTED_FENCE.get());
        corruptedPlanksPool.method_25722(ModBlocks.CORRUPTED_FENCE_GATE.get());
        corruptedPlanksPool.method_25725(ModBlocks.CORRUPTED_STAIRS.get());
        corruptedPlanksPool.method_25724(ModBlocks.CORRUPTED_SLAB.get());
        corruptedPlanksPool.method_25716(ModBlocks.CORRUPTED_BUTTON.get());
        corruptedPlanksPool.method_25723(ModBlocks.CORRUPTED_PRESSURE_PLATE.get());

        blockStateModelGenerator.method_25603(ModBlocks.CORRUPTED_SAPLING.get(), class_4910.class_4913.field_22840);



        //Dreadstone and Dreadstone Ores
        blockStateModelGenerator.method_25650(ModBlocks.DREADSTONE.get());
        class_4910.class_4912 reinforcedDreadstonePool = blockStateModelGenerator.method_25650(ModBlocks.REINFORCED_DREADSTONE.get());
        blockStateModelGenerator.method_25658(ModBlocks.REINFORCED_DREADSTONE_DOOR.get());
        blockStateModelGenerator.method_25671(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get());
        blockStateModelGenerator.method_25650(ModBlocks.REINFORCED_DREADSTONE_GLASS.get());
        blockStateModelGenerator.method_25650(ModBlocks.DREADSTONE_DIAMOND_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.DREADSTONE_THUNDERANIUM_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.DREADSTONE_NETHERITE_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.VOID_COAL_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.VOID_COAL_BLOCK.get());

        //Reinforced Dreadstone
        reinforcedDreadstonePool.method_25720(ModBlocks.REINFORCED_DREADSTONE_WALL.get());
        reinforcedDreadstonePool.method_25725(ModBlocks.REINFORCED_DREADSTONE_STAIRS.get());
        reinforcedDreadstonePool.method_25724(ModBlocks.REINFORCED_DREADSTONE_SLAB.get());

        //Dimension Core ore
        blockStateModelGenerator.method_25650(ModBlocks.MWDC_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.DCDC_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.TLDC_ORE.get());
        blockStateModelGenerator.method_25650(ModBlocks.CLDC_ORE.get());

        //MISC

        blockStateModelGenerator.method_25650(ModBlocks.VOIDSTONE.get());
        blockStateModelGenerator.method_25650(ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get());
        blockStateModelGenerator.method_25650(ModBlocks.THUNDERANIUM_PORTAL_FRAME.get());
        blockStateModelGenerator.method_25650(ModBlocks.CORRUPTION_PORTAL_FRAME.get());

        blockStateModelGenerator.method_25650(ModBlocks.FAKESTONE.get());
        blockStateModelGenerator.method_25650(ModBlocks.FAKESLATE.get());

        blockStateModelGenerator.method_25650(ModBlocks.CHARGED_DIRT.get());
        blockStateModelGenerator.method_25650(ModBlocks.THUNDERED_STONE.get());
        blockStateModelGenerator.method_25706(ModBlocks.THUNDERED_LANTERN.get());

        blockStateModelGenerator.method_25650(ModBlocks.CORRUPTED_STONE.get());
        blockStateModelGenerator.method_25650(ModBlocks.CORRUPTED_DIRT.get());
        blockStateModelGenerator.method_25706(ModBlocks.CORRUPTED_LANTERN.get());
        blockStateModelGenerator.method_25650(ModBlocks.CORRUPTION_BLOCK.get());
        blockStateModelGenerator.method_25650(ModBlocks.CORRUPTINITE_ORE.get());


        blockStateModelGenerator.method_25622(ModBlocks.THUNDERANIUM_TNT.get(), class_4946.field_23055);
        blockStateModelGenerator.method_25622(ModBlocks.RED_THUNDERANIUM_TNT.get(), class_4946.field_23055);
        blockStateModelGenerator.method_25622(ModBlocks.AXON_ALLOY_TNT.get(), class_4946.field_23055);



        //SPAWN EGGS
        blockStateModelGenerator.method_25538(ModItems.RED_ESSENCE_ZOMBIE_SPAWN_EGG.get(), class_4941.method_25845("template_spawn_egg"));
        blockStateModelGenerator.method_25538(ModItems.GENETICALLY_MODIFIED_RED_ESSENCE_ZOMBIE_SPAWN_EGG.get(), class_4941.method_25845("template_spawn_egg"));
        blockStateModelGenerator.method_25538(ModItems.DARK_ESSENCE_ZOMBIE_SPAWN_EGG.get(), class_4941.method_25845("template_spawn_egg"));
        blockStateModelGenerator.method_25538(ModItems.LOST_MINER_SPAWN_EGG.get(), class_4941.method_25845("template_spawn_egg"));
        blockStateModelGenerator.method_25538(ModItems.THUNDERANIUM_GOLEM_SPAWN_EGG.get(), class_4941.method_25845("template_spawn_egg"));

    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {

        itemModelGenerator.method_25733(ModItems.MIMICARIUM.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RAW_NETHERITE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.AXON_ALLOY.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RAZZORIUM.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RENDERIUM.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DENDERIUM.get(), class_4943.field_22938);

        //Buckests
        itemModelGenerator.method_25733(ModItems.LIQUID_THUNDER_BUCKET.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.LIQUID_CORRUPTION_BUCKET.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.GX_BUCKET.get(), class_4943.field_22938);

        //Fuels
        itemModelGenerator.method_25733(ModItems.THUNDER_FUEL.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.VOID_COAL.get(), class_4943.field_22938);

        //Igniters
        itemModelGenerator.method_25733(ModItems.MIMICARIUM_IGNITER.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DREADED_IGNITER.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_KEY.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.CORRUPTION_GATEWAY.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.UNIVERSAL_IGNITER.get(), class_4943.field_22938);

        //COMPRESSED STICKS
        itemModelGenerator.method_25733(ModItems.COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DOUBLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.TRIPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.QUADRUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.QUINTUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.SEXTUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.SEPTUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.OCTUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.NONUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DECUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.UNDECUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DUODECUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.TREDECUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.QUATTUORDECUPLE_COMPRESSED_STICK.get(), class_4943.field_22938);

        //Dimension Core
        itemModelGenerator.method_25733(ModItems.MWDC.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DCDC.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.TLDC.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.CLDC.get(), class_4943.field_22938);

        //Thunderanium
        itemModelGenerator.method_25733(ModItems.RAW_THUNDERANIUM.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.REFINED_THUNDERANIUM.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_CLUSTER.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_INGOT.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_NUGGET.get(), class_4943.field_22938);

        //Red Thunderanium
        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_INGOT.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_CLUSTER.get(), class_4943.field_22938);

        //Essence
        itemModelGenerator.method_25733(ModItems.RED_ESSENCE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DARK_ESSENCE.get(), class_4943.field_22938);

        //Dark Thunderanium
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_INGOT.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_CLUSTER.get(), class_4943.field_22938);

        //Corruptinite
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.UNSTABLE_CORRUPTINITE.get(), class_4943.field_22938);

        //Armors

        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_HELMET.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_CHESTPLATE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_LEGGINGS.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_BOOTS.get(), class_4943.field_22938);

        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_HELMET.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_CHESTPLATE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_LEGGINGS.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_BOOTS.get(), class_4943.field_22938);

        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_HELMET.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_CHESTPLATE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_LEGGINGS.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_BOOTS.get(), class_4943.field_22938);

        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_HELMET.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_CHESTPLATE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_LEGGINGS.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_BOOTS.get(), class_4943.field_22938);

        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXON_ALLOY_HELMET.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXON_ALLOY_CHESTPLATE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXON_ALLOY_LEGGINGS.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXON_ALLOY_BOOTS.get(), class_4943.field_22938);

        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HELMET.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_CHESTPLATE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_LEGGINGS.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_BOOTS.get(), class_4943.field_22938);

        itemModelGenerator.method_25733(ModItems.AXON_ALLOY_HELMET.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.AXON_ALLOY_CHESTPLATE.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.AXON_ALLOY_LEGGINGS.get(), class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.AXON_ALLOY_BOOTS.get(), class_4943.field_22938);

        //Tools

        itemModelGenerator.method_25733(ModItems.ANTIGLITCH_SWORD.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.VANILLA_HOE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.ULTIMATE_HOE_TROPHY.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RAZZOR.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RAZZORIUM_MINER.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.TICKLE_TRAVIS_TICKLER.get(), class_4943.field_22939);

        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_SWORD.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_AXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_PICKAXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_SHOVEL.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.THUNDERANIUM_HOE.get(), class_4943.field_22939);

        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_SWORD.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_AXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_PICKAXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_SHOVEL.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RED_THUNDERANIUM_HOE.get(), class_4943.field_22939);

        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_SWORD.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_PICKAXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_SHOVEL.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_HOE.get(), class_4943.field_22939);

        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_SWORD.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_PICKAXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_SHOVEL.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_HOE.get(), class_4943.field_22939);

        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SWORD.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_AXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_PICKAXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SHOVEL.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HOE.get(), class_4943.field_22939);

        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXON_ALLOY_SWORD.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXON_ALLOY_AXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXON_ALLOY_PICKAXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXON_ALLOY_SHOVEL.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.CORRUPTINITE_AXON_ALLOY_HOE.get(), class_4943.field_22939);

        itemModelGenerator.method_25733(ModItems.AXON_ALLOY_SWORD.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.AXON_ALLOY_AXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.AXON_ALLOY_PICKAXE.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.AXON_ALLOY_SHOVEL.get(), class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.AXON_ALLOY_HOE.get(), class_4943.field_22939);


    }
}
