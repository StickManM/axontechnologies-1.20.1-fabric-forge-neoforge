package net.stickmanm.fabric.data;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.block.ModBlockTags;
import net.stickmanm.axontechnologies.block.ModBlocks;

import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {
        public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
            super(output, registriesFuture);
        }

        @Override
        protected void method_10514(class_7225.class_7874 arg) {
            method_10512(class_3481.field_33715)
                    .add(ModBlocks.MIMICARIUM_ORE.get())
                    .add(ModBlocks.RENDERIUM_ORE.get())
                    .add(ModBlocks.DENDERIUM_ORE.get())
                    .add(ModBlocks.DEEPSLATE_MIMICARIUM_ORE.get())
                    .add(ModBlocks.FAKESLATE.get())
                    .add(ModBlocks.FAKESTONE.get())
                    .add(ModBlocks.FAKESLATE_IRON_ORE.get())
                    .add(ModBlocks.FAKESLATE_GOLD_ORE.get())
                    .add(ModBlocks.FAKESTONE_GOLD_ORE.get())
                    .add(ModBlocks.FAKESTONE_IRON_ORE.get())
                    .add(ModBlocks.DREADSTONE.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_DOOR.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_STAIRS.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_SLAB.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_WALL.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_GLASS.get())
                    .add(ModBlocks.DREADSTONE_DIAMOND_ORE.get())
                    .add(ModBlocks.DREADSTONE_NETHERITE_ORE.get())
                    .add(ModBlocks.DREADSTONE_THUNDERANIUM_ORE.get())
                    .add(ModBlocks.VOID_COAL_ORE.get())
                    .add(ModBlocks.VOID_COAL_BLOCK.get())
                    .add(ModBlocks.VOIDSTONE.get())
                    .add(ModBlocks.OCTUPLE_COMPRESSED_COBBLESTONE.get())
                    .add(ModBlocks.THUNDERED_STONE.get())
                    .add(ModBlocks.CORRUPTION_PORTAL_FRAME.get())
                    .add(ModBlocks.THUNDERANIUM_PORTAL_FRAME.get())
                    .add(ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get())
                    .add(ModBlocks.THUNDERANIUM_ORE.get())
                    .add(ModBlocks.CORRUPTED_STONE.get())
                    .add(ModBlocks.CORRUPTION_BLOCK.get())
                    .add(ModBlocks.CORRUPTINITE_ORE.get())
                    .add(ModBlocks.MWDC_ORE.get())
                    .add(ModBlocks.DCDC_ORE.get())
                    .add(ModBlocks.CLDC_ORE.get())
                    .add(ModBlocks.TLDC_ORE.get())
                    .add(ModBlocks.RED_THUNDERANIUM_TNT.get())
                    .add(ModBlocks.THUNDERANIUM_TNT.get());

            method_10512(class_3481.field_33713)
                    .add(ModBlocks.THUNDERED_LOG.get())
                    .add(ModBlocks.THUNDERED_PLANKS.get())
                    .add(ModBlocks.THUNDERED_WOOD.get())
                    .add(ModBlocks.STRIPPED_THUNDERED_LOG.get())
                    .add(ModBlocks.STRIPPED_THUNDERED_WOOD.get())
                    .add(ModBlocks.THUNDERED_FENCE_GATE.get())
                    .add(ModBlocks.THUNDERED_FENCE.get())
                    .add(ModBlocks.THUNDERED_PRESSURE_PLATE.get())
                    .add(ModBlocks.THUNDERED_TRAPDOOR.get())
                    .add(ModBlocks.THUNDERED_STAIRS.get())
                    .add(ModBlocks.THUNDERED_SLAB.get())
                    .add(ModBlocks.THUNDERED_DOOR.get())
                    .add(ModBlocks.THUNDERED_BUTTON.get())

                    .add(ModBlocks.CORRUPTED_LOG.get())
                    .add(ModBlocks.CORRUPTED_PLANKS.get())
                    .add(ModBlocks.CORRUPTED_WOOD.get())
                    .add(ModBlocks.STRIPPED_CORRUPTED_LOG.get())
                    .add(ModBlocks.STRIPPED_CORRUPTED_WOOD.get())
                    .add(ModBlocks.CORRUPTED_FENCE.get())
                    .add(ModBlocks.CORRUPTED_FENCE_GATE.get())
                    .add(ModBlocks.CORRUPTED_PRESSURE_PLATE.get())
                    .add(ModBlocks.CORRUPTED_TRAPDOOR.get())
                    .add(ModBlocks.CORRUPTED_STAIRS.get())
                    .add(ModBlocks.CORRUPTED_SLAB.get())
                    .add(ModBlocks.CORRUPTED_DOOR.get())
                    .add(ModBlocks.CORRUPTED_BUTTON.get());

            method_10512(class_3481.field_33716)
                    .add(ModBlocks.CHARGED_DIRT.get())
                    .add(ModBlocks.CORRUPTED_DIRT.get());

            method_10512(class_3481.field_44469);

            method_10512(class_3481.field_33714);

            method_10512(class_3481.field_33719)
                    .add(ModBlocks.THUNDERED_STONE.get())
                    .add(ModBlocks.CORRUPTED_STONE.get())
                    .add(ModBlocks.FAKESTONE_IRON_ORE.get())
                    .add(ModBlocks.FAKESLATE_IRON_ORE.get())
                    .add(ModBlocks.OCTUPLE_COMPRESSED_COBBLESTONE.get());

            method_10512(class_3481.field_33718)
                    .add(ModBlocks.MIMICARIUM_ORE.get())
                    .add(ModBlocks.DEEPSLATE_MIMICARIUM_ORE.get())
                    .add(ModBlocks.VOIDSTONE.get())
                    .add(ModBlocks.FAKESTONE_GOLD_ORE.get())
                    .add(ModBlocks.FAKESLATE_GOLD_ORE.get())
                    .add(ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get());

            method_10512(class_3481.field_33717)
                    .add(ModBlocks.DREADSTONE_NETHERITE_ORE.get())
                    .add(ModBlocks.DREADSTONE.get())
                    .add(ModBlocks.DREADSTONE_DIAMOND_ORE.get())
                    .add(ModBlocks.THUNDERANIUM_PORTAL_FRAME.get());

            method_10512(class_6862.method_40092(class_7924.field_41254, new class_2960("fabric", "needs_tool_level_4")))
                    .add(ModBlocks.VOID_COAL_ORE.get())
                    .add(ModBlocks.DREADSTONE_THUNDERANIUM_ORE.get())
                    .add(ModBlocks.THUNDERANIUM_TNT.get())
                    .add(ModBlocks.VOID_COAL_BLOCK.get());

            method_10512(class_6862.method_40092(class_7924.field_41254, new class_2960("fabric", "needs_tool_level_5")))
                    .add(ModBlocks.THUNDERANIUM_ORE.get())
                    .add(ModBlocks.RED_THUNDERANIUM_TNT.get())
                    .add(ModBlocks.RENDERIUM_ORE.get());

            method_10512(class_6862.method_40092(class_7924.field_41254, new class_2960("fabric", "needs_tool_level_6")))
                    .add(ModBlocks.CORRUPTINITE_ORE.get())
                    .add(ModBlocks.DENDERIUM_ORE.get())
                    .add(ModBlocks.CORRUPTION_PORTAL_FRAME.get())
                    .add(ModBlocks.CORRUPTION_BLOCK.get())
                    .method_26792(ModBlockTags.REINFORCED_DREADSTONE);

            method_10512(class_6862.method_40092(class_7924.field_41254, new class_2960("fabric", "needs_tool_level_10")))
                    .add(ModBlocks.AXON_ALLOY_TNT.get())
                    .add(ModBlocks.TLDC_ORE.get())
                    .add(ModBlocks.MWDC_ORE.get())
                    .add(ModBlocks.CLDC_ORE.get())
                    .add(ModBlocks.DCDC_ORE.get());

            method_10512(class_3481.field_15504)
                    .add(ModBlocks.REINFORCED_DREADSTONE_WALL.get());

            method_10512(class_3481.field_29822)
                    .add(ModBlocks.CHARGED_DIRT.get())
                    .add(ModBlocks.CORRUPTED_DIRT.get());

            method_10512(class_3481.field_15475)
                    .add(ModBlocks.THUNDERED_LOG.get())
                    .add(ModBlocks.THUNDERED_WOOD.get())
                    .add(ModBlocks.STRIPPED_THUNDERED_LOG.get())
                    .add(ModBlocks.STRIPPED_THUNDERED_WOOD.get())
                    .add(ModBlocks.CORRUPTED_LOG.get())
                    .add(ModBlocks.CORRUPTED_WOOD.get())
                    .add(ModBlocks.STRIPPED_CORRUPTED_LOG.get())
                    .add(ModBlocks.STRIPPED_CORRUPTED_WOOD.get());

            method_10512(class_3481.field_15503)
                    .add(ModBlocks.THUNDERED_LEAVES.get());

            method_10512(class_3481.field_15471)
                    .add(ModBlocks.THUNDERED_PLANKS.get())
                    .add(ModBlocks.CORRUPTED_PLANKS.get());

            method_10512(class_3481.field_15499)
                    .add(ModBlocks.THUNDERED_BUTTON.get())
                    .add(ModBlocks.CORRUPTED_BUTTON.get());

            method_10512(class_3481.field_15494)
                    .add(ModBlocks.THUNDERED_DOOR.get())
                    .add(ModBlocks.CORRUPTED_DOOR.get());

            method_10512(class_3481.field_17619)
                    .add(ModBlocks.THUNDERED_FENCE.get())
                    .add(ModBlocks.CORRUPTED_FENCE.get());

            method_10512(class_3481.field_15468)
                    .add(ModBlocks.THUNDERED_SLAB.get())
                    .add(ModBlocks.CORRUPTED_SLAB.get());

            method_10512(class_3481.field_15502)
                    .add(ModBlocks.THUNDERED_STAIRS.get())
                    .add(ModBlocks.CORRUPTED_STAIRS.get());

            method_10512(class_3481.field_15491)
                    .add(ModBlocks.THUNDERED_TRAPDOOR.get())
                    .add(ModBlocks.CORRUPTED_TRAPDOOR.get());

            method_10512(class_3481.field_15477)
                    .add(ModBlocks.THUNDERED_PRESSURE_PLATE.get())
                    .add(ModBlocks.CORRUPTED_PRESSURE_PLATE.get());

            method_10512(class_3481.field_25147)
                    .add(ModBlocks.THUNDERED_FENCE_GATE.get())
                    .add(ModBlocks.CORRUPTED_FENCE_GATE.get());

            method_10512(ModBlockTags.REINFORCED_DREADSTONE)
                    .add(ModBlocks.REINFORCED_DREADSTONE.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_DOOR.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_GLASS.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_SLAB.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_WALL.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get())
                    .add(ModBlocks.REINFORCED_DREADSTONE_STAIRS.get());

            method_10512(ModBlockTags.THUNDERED_PLANKS_CONVERTIBLE)
                    .add(ModBlocks.THUNDERED_LOG.get())
                    .add(ModBlocks.THUNDERED_WOOD.get())
                    .add(ModBlocks.STRIPPED_THUNDERED_LOG.get())
                    .add(ModBlocks.STRIPPED_THUNDERED_WOOD.get());

            method_10512(ModBlockTags.CORRUPTED_PLANKS_CONVERTIBLE)
                    .add(ModBlocks.CORRUPTED_LOG.get())
                    .add(ModBlocks.CORRUPTED_WOOD.get())
                    .add(ModBlocks.STRIPPED_CORRUPTED_LOG.get())
                    .add(ModBlocks.STRIPPED_CORRUPTED_WOOD.get());

            method_10512(class_3481.field_17754)
                    .method_26792(ModBlockTags.REINFORCED_DREADSTONE);

            method_10512(class_3481.field_17753)
                    .method_26792(ModBlockTags.REINFORCED_DREADSTONE);

            method_10512(ModBlockTags.CORRUPTION_REPLACEABLE)
                    .add(ModBlocks.CORRUPTION_BLOCK.get())
                    .add(ModBlocks.CORRUPTED_DIRT.get())
                    .add(ModBlocks.CORRUPTED_STONE.get())
                    .add(ModBlocks.CORRUPTINITE_ORE.get())

                    .add(ModBlocks.DENDERIUM_ORE.get())
                    .add(ModBlocks.CLDC_ORE.get());

            method_10512(ModBlockTags.CORRUPTION)
                    .add(ModBlocks.CORRUPTION_BLOCK.get())
                    .add(ModBlocks.CORRUPTED_DIRT.get())
                    .add(ModBlocks.CORRUPTED_STONE.get())
                    .add(ModBlocks.CORRUPTINITE_ORE.get())
                    .add(ModBlocks.CORRUPTED_LOG.get())
                    .add(ModBlocks.CORRUPTED_PLANKS.get())
                    .add(ModBlocks.CORRUPTED_WOOD.get())
                    .add(ModBlocks.STRIPPED_CORRUPTED_LOG.get())
                    .add(ModBlocks.STRIPPED_CORRUPTED_WOOD.get())
                    .add(ModBlocks.CORRUPTED_FENCE.get())
                    .add(ModBlocks.CORRUPTED_FENCE_GATE.get())
                    .add(ModBlocks.CORRUPTED_PRESSURE_PLATE.get())
                    .add(ModBlocks.CORRUPTED_TRAPDOOR.get())
                    .add(ModBlocks.CORRUPTED_STAIRS.get())
                    .add(ModBlocks.CORRUPTED_SLAB.get())
                    .add(ModBlocks.CORRUPTED_DOOR.get())
                    .add(ModBlocks.CORRUPTED_BUTTON.get());

        }
    }