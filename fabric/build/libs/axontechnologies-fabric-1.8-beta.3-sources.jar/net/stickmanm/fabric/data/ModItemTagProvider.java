package net.stickmanm.fabric.data;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import net.stickmanm.axontechnologies.block.ModBlockTags;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.item.ModItemTags;
import net.stickmanm.axontechnologies.util.ModTags;

import java.util.concurrent.CompletableFuture;

public class ModItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public ModItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture,
                              FabricTagProvider.BlockTagProvider blockTagProvider) {
        super(output, registriesFuture, blockTagProvider);
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        copy(ModBlockTags.THUNDERED_PLANKS_CONVERTIBLE, ModItemTags.THUNDERED_PLANKS_CONVERTIBLE);
        copy(class_3481.field_15471, class_3489.field_15537);
        copy(class_3481.field_15475, class_3489.field_15539);
        copy(ModBlockTags.CORRUPTED_PLANKS_CONVERTIBLE, ModItemTags.CORRUPTED_PLANKS_CONVERTIBLE);

        method_10512(class_3489.field_25808)
                .add(ModBlocks.THUNDERED_STONE.get().method_8389())
                .add(ModBlocks.CORRUPTED_STONE.get().method_8389())
                .add(ModBlocks.FAKESTONE.get().method_8389())
                .add(ModBlocks.FAKESLATE.get().method_8389())
                .add(ModBlocks.DREADSTONE.get().method_8389());

        method_10512(class_3489.field_23802)
                .add(ModBlocks.THUNDERED_STONE.get().method_8389())
                .add(ModBlocks.CORRUPTED_STONE.get().method_8389())
                .add(ModBlocks.FAKESTONE.get().method_8389())
                .add(ModBlocks.FAKESLATE.get().method_8389())
                .add(ModBlocks.DREADSTONE.get().method_8389());


    }
}