package net.stickmanm.fabric.data;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2246;
import net.minecraft.class_2444;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2960;
import net.minecraft.class_7800;
import net.stickmanm.axontechnologies.AxonTechnologies;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.block.ModBlockTags;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.item.ModItemTags;
import net.stickmanm.axontechnologies.item.ModItems;
import net.stickmanm.axontechnologies.util.ModTags;

import java.util.List;
import java.util.function.Consumer;

import static net.stickmanm.axontechnologies.util.ModTags.Items.TRIMS;

public class ModRecipeGenerator extends FabricRecipeProvider {
    public ModRecipeGenerator(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void method_10419(Consumer<class_2444> exporter) { //cool comment



        //Merging

        //Ores
        method_36233(exporter, List.of(ModBlocks.MIMICARIUM_ORE.get()), class_7800.field_40642, ModItems.MIMICARIUM.get(),
                3f, 75, "mimicarium");
        method_36233(exporter, List.of(ModBlocks.DEEPSLATE_MIMICARIUM_ORE.get()), class_7800.field_40642, ModItems.MIMICARIUM.get(),
                3f, 10, "mimicarium");


        method_36233(exporter, List.of(ModBlocks.DREADSTONE_DIAMOND_ORE.get()), class_7800.field_40642, class_1802.field_8477,
                3f, 75, "diamond");

        method_36233(exporter, List.of(ModBlocks.DREADSTONE_NETHERITE_ORE.get()), class_7800.field_40642, class_1802.field_22020,
                3f, 75, "netherite");

        method_36233(exporter, List.of(ModBlocks.VOID_COAL_ORE.get()), class_7800.field_40642, ModItems.VOID_COAL.get(),
                3f, 75, "void_coal");

        method_36234(exporter, List.of(ModItems.RAW_NETHERITE.get()), class_7800.field_40642, class_1802.field_22020,
                3f, 75, "netherite");

        method_36233(exporter, List.of(ModBlocks.DREADSTONE_THUNDERANIUM_ORE.get()), class_7800.field_40642, ModItems.REFINED_THUNDERANIUM.get(),
                5f, 75, "thunderanium");

        method_36233(exporter, List.of(ModBlocks.THUNDERANIUM_ORE.get()), class_7800.field_40642, ModItems.REFINED_THUNDERANIUM.get(),
                5f, 75, "thunderanium");

        method_36233(exporter, List.of(ModBlocks.CORRUPTINITE_ORE.get()), class_7800.field_40642, ModItems.UNSTABLE_CORRUPTINITE.get(),
                5f, 75, "corruptinite");

        method_36233(exporter, List.of(ModBlocks.RENDERIUM_ORE.get()), class_7800.field_40642, ModItems.RENDERIUM.get(),
                5f, 75, "renderium");

        method_36233(exporter, List.of(ModBlocks.DENDERIUM_ORE.get()), class_7800.field_40642, ModItems.DENDERIUM.get(),
                5f, 75, "denderium");


        method_36234(exporter, List.of(ModItems.RAW_THUNDERANIUM.get()), class_7800.field_40642, ModItems.REFINED_THUNDERANIUM.get(),
                5f, 75, "thunderanium");

        method_36234(exporter, List.of(ModItems.THUNDERANIUM_CLUSTER.get()), class_7800.field_40642, ModItems.THUNDERANIUM_INGOT.get(),
                5f, 75, "thunderanium");

        method_36234(exporter, List.of(ModItems.RED_THUNDERANIUM_CLUSTER.get()), class_7800.field_40642, ModItems.RED_THUNDERANIUM_INGOT.get(),
                10f, 75, "red_thunderanium");

        method_36234(exporter, List.of(ModItems.DARK_THUNDERANIUM_CLUSTER.get()), class_7800.field_40642, ModItems.DARK_THUNDERANIUM_INGOT.get(),
                1000f, 100, "dark_thunderanium");

        method_36234(exporter, List.of(ModBlocks.MWDC_ORE.get()), class_7800.field_40642, ModItems.MWDC.get(),
                2000f, 250, "dimension_core");

        method_36234(exporter, List.of(ModBlocks.DCDC_ORE.get()), class_7800.field_40642, ModItems.DCDC.get(),
                2000f, 250, "dimension_core");

        method_36234(exporter, List.of(ModBlocks.TLDC_ORE.get()), class_7800.field_40642, ModItems.TLDC.get(),
                2000f, 250, "dimension_core");

        method_36234(exporter, List.of(ModBlocks.CLDC_ORE.get()), class_7800.field_40642, ModItems.CLDC.get(),
                2000f, 250, "dimension_core");

        //BLAST FURNACE +
        method_36234(exporter, List.of(class_2246.field_10102), class_7800.field_40634, class_2246.field_10033,
                5f, 100, "glass");

        method_36234(exporter, List.of(class_2246.field_10534), class_7800.field_40634, class_2246.field_10033,
                5f, 100, "glass");


        method_36234(exporter, List.of(class_1802.field_8696), class_7800.field_40634, class_1802.field_8621,
                5f, 100, "brick");

        method_36234(exporter, List.of(class_2246.field_10515), class_7800.field_40634, class_1802.field_8729,
                5f, 100, "brick");


        method_36234(exporter, List.of(class_2246.field_10056), class_7800.field_40634, class_2246.field_10416,
                5f, 100, "cracked");

        method_36234(exporter, List.of(class_2246.field_28900), class_7800.field_40634, class_2246.field_29222,
                5f, 100, "cracked");

        method_36234(exporter, List.of(class_2246.field_28896), class_7800.field_40634, class_2246.field_29223,
                5f, 100, "cracked");

        method_36234(exporter, List.of(class_2246.field_23874), class_7800.field_40634, class_2246.field_23875,
                5f, 100, "cracked");

        method_36234(exporter, List.of(class_2246.field_10266), class_7800.field_40634, class_2246.field_23867,
                5f, 100, "cracked");

        //Reinforced Dreadstone Recipes
        method_33544(ModBlocks.REINFORCED_DREADSTONE_DOOR.get(), class_1856.method_8091(ModBlocks.REINFORCED_DREADSTONE.get()))
                .method_33530(FabricRecipeProvider.method_32807(ModBlocks.REINFORCED_DREADSTONE.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.REINFORCED_DREADSTONE_DOOR.get()))
        .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.REINFORCED_DREADSTONE_DOOR.get())));

        method_33553(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get(), class_1856.method_8091(ModBlocks.REINFORCED_DREADSTONE.get()))
                .method_33530(FabricRecipeProvider.method_32807(ModBlocks.REINFORCED_DREADSTONE.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get())));

        method_32808(ModBlocks.REINFORCED_DREADSTONE_STAIRS.get(), class_1856.method_8091(ModBlocks.REINFORCED_DREADSTONE.get()))
                .method_33530(FabricRecipeProvider.method_32807(ModBlocks.REINFORCED_DREADSTONE.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.REINFORCED_DREADSTONE_STAIRS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.REINFORCED_DREADSTONE_STAIRS.get())));


        method_32804(class_7800.field_40642, ModBlocks.REINFORCED_DREADSTONE_SLAB.get(), class_1856.method_8091(ModBlocks.REINFORCED_DREADSTONE_SLAB.get()))
                .method_33530(FabricRecipeProvider.method_32807(ModBlocks.REINFORCED_DREADSTONE.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.REINFORCED_DREADSTONE_SLAB.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.REINFORCED_DREADSTONE_SLAB.get())));


        class_2447.method_10436(class_7800.field_40642, ModBlocks.REINFORCED_DREADSTONE_WALL.get(), 6)
                .method_10439("# #")
                .method_10439("# #")
                .method_10439("# #")
                .method_10434('#', ModBlocks.REINFORCED_DREADSTONE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.REINFORCED_DREADSTONE.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.REINFORCED_DREADSTONE_WALL.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.REINFORCED_DREADSTONE_WALL.get())));


        //CRAFTING +
        class_2447.method_10437(class_7800.field_40636, class_1802.field_8239)
                .method_10439("# #")
                .method_10439("#B#")
                .method_10439(" # ")
                .method_10434('#', class_1802.field_8620)
                .method_10434('B', class_1802.field_16307)
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_16307),
                        FabricRecipeProvider.method_10426(class_1802.field_8239))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(class_1802.field_8239)));



        //TNT
        class_2447.method_10437(class_7800.field_40642, ModBlocks.THUNDERANIUM_TNT.get())
                .method_10439("###")
                .method_10439("#T#")
                .method_10439("###")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('T', class_2246.field_10375)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERANIUM_TNT.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERANIUM_TNT.get())));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.RED_THUNDERANIUM_TNT.get())
                .method_10439("###")
                .method_10439("#T#")
                .method_10439("###")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('T', ModBlocks.THUNDERANIUM_TNT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.RED_THUNDERANIUM_TNT.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.RED_THUNDERANIUM_TNT.get())));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.AXON_ALLOY_TNT.get())
                .method_10439("###")
                .method_10439("#T#")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModBlocks.RED_THUNDERANIUM_TNT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.AXON_ALLOY_TNT.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.AXON_ALLOY_TNT.get())));


        //Thundered Wood

        class_2447.method_10437(class_7800.field_40642, ModBlocks.THUNDERED_WOOD.get())
                .method_10439("##")
                .method_10439("##")
                .method_10434('#', ModBlocks.THUNDERED_LOG.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.THUNDERED_LOG.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERED_WOOD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_WOOD.get())));

        //Thundered Planks
        class_2450.method_10448(class_7800.field_40634, ModBlocks.THUNDERED_PLANKS.get(), 4)
                .method_10446(ModItemTags.THUNDERED_PLANKS_CONVERTIBLE)
                .method_10452("planks")
                .method_10442("has_thundered_planks_convertible",
                        FabricRecipeProvider.method_10420(ModItemTags.THUNDERED_PLANKS_CONVERTIBLE))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_PLANKS.get())));

        class_2450.method_10448(class_7800.field_40634, ModBlocks.THUNDERED_BUTTON.get(), 4)
                .method_10454(ModBlocks.THUNDERED_PLANKS.get())
                .method_10452("button")
                .method_10442(FabricRecipeProvider.method_32807(ModBlocks.THUNDERED_PLANKS.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERED_BUTTON.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_BUTTON.get())));

        class_2447.method_10436(class_7800.field_40634, ModBlocks.THUNDERED_SLAB.get(), 6)
                .method_10439("###")
                .method_10434('#', ModBlocks.THUNDERED_PLANKS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.THUNDERED_PLANKS.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERED_SLAB.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_SLAB.get())));

        class_2447.method_10436(class_7800.field_40634, ModBlocks.THUNDERED_STAIRS.get(), 6)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###")
                .method_10434('#', ModBlocks.THUNDERED_PLANKS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.THUNDERED_PLANKS.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERED_STAIRS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_STAIRS.get())));

        class_2447.method_10436(class_7800.field_40634, ModBlocks.THUNDERED_DOOR.get(), 3)
                .method_10439("##")
                .method_10439("##")
                .method_10439("##")
                .method_10434('#', ModBlocks.THUNDERED_PLANKS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.THUNDERED_PLANKS.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERED_DOOR.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_DOOR.get())));

        class_2447.method_10436(class_7800.field_40634, ModBlocks.THUNDERED_TRAPDOOR.get(),6)
                .method_10439("###")
                .method_10439("###")
                .method_10434('#', ModBlocks.THUNDERED_PLANKS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.THUNDERED_PLANKS.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERED_TRAPDOOR.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_TRAPDOOR.get())));

        class_2447.method_10436(class_7800.field_40634, ModBlocks.THUNDERED_PRESSURE_PLATE.get(),2)
                .method_10439("##")
                .method_10434('#', ModBlocks.THUNDERED_PLANKS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.THUNDERED_PLANKS.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERED_PRESSURE_PLATE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_PRESSURE_PLATE.get())));

        class_2447.method_10436(class_7800.field_40634, ModBlocks.THUNDERED_FENCE.get(),4)
                .method_10439("#S#")
                .method_10439("#S#")
                .method_10434('#', ModBlocks.THUNDERED_PLANKS.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.THUNDERED_PLANKS.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERED_FENCE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_FENCE.get())));

        class_2447.method_10436(class_7800.field_40634, ModBlocks.THUNDERED_FENCE_GATE.get(),2)
                .method_10439("S#S")
                .method_10439("S#S")
                .method_10434('#', ModBlocks.THUNDERED_PLANKS.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.THUNDERED_PLANKS.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERED_FENCE_GATE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERED_FENCE_GATE.get())));


        //Corrupted Wood

        class_2447.method_10437(class_7800.field_40642, ModBlocks.CORRUPTED_WOOD.get())
                .method_10439("##")
                .method_10439("##")
                .method_10434('#', ModBlocks.CORRUPTED_LOG.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.CORRUPTED_LOG.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.CORRUPTED_WOOD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.CORRUPTED_WOOD.get())));

        //Corrupted Planks
        class_2450.method_10448(class_7800.field_40634, ModBlocks.CORRUPTED_PLANKS.get(), 4)
                .method_10446(ModItemTags.CORRUPTED_PLANKS_CONVERTIBLE)
                .method_10452("planks")
                .method_10442("has_thundered_planks_convertible",
                        FabricRecipeProvider.method_10420(ModItemTags.CORRUPTED_PLANKS_CONVERTIBLE))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.CORRUPTED_PLANKS.get())));


        //IGNITERS
        class_2447.method_10437(class_7800.field_40642, ModItems.MIMICARIUM_IGNITER.get())
                .method_10439(" F#")
                .method_10439(" SF")
                .method_10439("S  ")
                .method_10434('#', ModItems.MIMICARIUM.get())
                .method_10434('F', class_1802.field_8145)
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.MIMICARIUM.get()),
                        FabricRecipeProvider.method_10426(ModItems.MIMICARIUM_IGNITER.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.MIMICARIUM_IGNITER.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DREADED_IGNITER.get())
                .method_10439("FVF")
                .method_10439("V#V")
                .method_10439("FVF")
                .method_10434('#', ModItems.MIMICARIUM_IGNITER.get())
                .method_10434('V', ModBlocks.VOIDSTONE.get())
                .method_10434('F', class_1802.field_8145)
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.VOIDSTONE.get()),
                        FabricRecipeProvider.method_10426(ModItems.DREADED_IGNITER.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DREADED_IGNITER.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_KEY.get())
                .method_10439("RGR")
                .method_10439("#I#")
                .method_10439("RGR")
                .method_10434('I', ModItems.DREADED_IGNITER.get())
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('G', class_1802.field_8695)
                .method_10434('R', class_1802.field_8725)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_KEY.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_KEY.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTION_GATEWAY.get())
                .method_10439("DRD")
                .method_10439("#K#")
                .method_10439("DRD")
                .method_10434('K', ModItems.THUNDERANIUM_KEY.get())
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('D', ModBlocks.CORRUPTION_BLOCK.get())
                .method_10434('R', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.CORRUPTION_BLOCK.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTION_GATEWAY.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTION_GATEWAY.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.UNIVERSAL_IGNITER.get())
                .method_10439("MAA")
                .method_10439("DTA")
                .method_10439("FCM")
                .method_10434('T', ModItems.THUNDERANIUM_KEY.get())
                .method_10434('C', ModItems.CORRUPTION_GATEWAY.get())
                .method_10434('D', ModItems.DREADED_IGNITER.get())
                .method_10434('F', ModItems.MIMICARIUM_IGNITER.get())
                .method_10434('M', ModItems.MIMICARIUM.get())
                .method_10434('A', ModItems.AXON_ALLOY.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTION_GATEWAY.get()),
                        FabricRecipeProvider.method_10426(ModItems.UNIVERSAL_IGNITER.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.UNIVERSAL_IGNITER.get())));

        //PORTAL FRAMES
        class_2447.method_10437(class_7800.field_40642, ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get())
                .method_10439("I#I")
                .method_10439("#C#")
                .method_10439("I#I")
                .method_10434('#', ModItems.MIMICARIUM.get())
                .method_10434('I', class_1802.field_8620)
                .method_10434('C', class_1802.field_8713)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.MIMICARIUM.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get())));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.THUNDERANIUM_PORTAL_FRAME.get())
                .method_10439("DVD")
                .method_10439("#V#")
                .method_10439("DVD")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('D', ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get())
                .method_10434('V', ModBlocks.VOIDSTONE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.THUNDERANIUM_PORTAL_FRAME.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.THUNDERANIUM_PORTAL_FRAME.get())));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.CORRUPTION_PORTAL_FRAME.get())
                .method_10439("DRD")
                .method_10439("#F#")
                .method_10439("DTD")
                .method_10434('#', ModItems.RED_ESSENCE.get())
                .method_10434('D', ModBlocks.CORRUPTION_BLOCK.get())
                .method_10434('F', ModBlocks.THUNDERANIUM_PORTAL_FRAME.get())
                .method_10434('T', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('R', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.CORRUPTION_BLOCK.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.CORRUPTION_PORTAL_FRAME.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.CORRUPTION_PORTAL_FRAME.get())));

        //MISC
        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_CLUSTER.get())
                .method_10439("###")
                .method_10439("TTT")
                .method_10439("###")
                .method_10434('#', ModItems.RED_ESSENCE.get())
                .method_10434('T', ModItems.THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_ESSENCE.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_CLUSTER.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_CLUSTER.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_CLUSTER.get())
                .method_10439("###")
                .method_10434('#', ModItems.REFINED_THUNDERANIUM.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.REFINED_THUNDERANIUM.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_CLUSTER.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_CLUSTER.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_CLUSTER.get())
                .method_10439(" ##")
                .method_10439(" TT")
                .method_10439(" ##")
                .method_10434('#', ModItems.DARK_ESSENCE.get())
                .method_10434('T', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_ESSENCE.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_CLUSTER.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_CLUSTER.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE.get())
                .method_10439("###")
                .method_10439("UUU")
                .method_10439("###")
                .method_10434('#', ModItems.DARK_ESSENCE.get())
                .method_10434('U', ModItems.UNSTABLE_CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.UNSTABLE_CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE.get())));

        class_2447.method_10437(class_7800.field_40642, class_1802.field_41946)
                .method_10439("#I#")
                .method_10439("#N#")
                .method_10439("###")
                .method_10433('I', TRIMS)
                .method_10434('N', class_2246.field_10515)
                .method_10434('#', class_2246.field_22108)
                .method_10429(FabricRecipeProvider.method_32807(class_1802.field_22020),
                        FabricRecipeProvider.method_10426(class_1802.field_41946))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(class_1802.field_41946)));

        class_2447.method_10437(class_7800.field_40642, ModItems.GX_BUCKET.get())
                .method_10439("#D#")
                .method_10439("#L#")
                .method_10439("#R#")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('L', ModItems.LIQUID_THUNDER_BUCKET.get())
                .method_10434('D', ModItems.AXON_ALLOY_HELMET.get())
                .method_10434('R', ModItems.AXON_ALLOY_BOOTS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.LIQUID_THUNDER_BUCKET.get()),
                        FabricRecipeProvider.method_10426(ModItems.GX_BUCKET.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.GX_BUCKET.get())));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.REINFORCED_DREADSTONE.get())
                .method_10439("###")
                .method_10439("#G#")
                .method_10439("###")
                .method_10434('#', ModBlocks.DREADSTONE.get())
                .method_10434('G', class_1802.field_8601)
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.DREADSTONE.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.REINFORCED_DREADSTONE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.REINFORCED_DREADSTONE.get())));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.REINFORCED_DREADSTONE_GLASS.get())
                .method_10439("G#G")
                .method_10439("#G#")
                .method_10439("G#G")
                .method_10434('#', ModBlocks.REINFORCED_DREADSTONE.get())
                .method_10434('G', class_2246.field_10033)
                .method_10429(FabricRecipeProvider.method_32807(ModBlocks.REINFORCED_DREADSTONE.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.REINFORCED_DREADSTONE_GLASS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.REINFORCED_DREADSTONE_GLASS.get())));


        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY.get())
                .method_10439("RES")
                .method_10439("THN")
                .method_10439("CDM")
                .method_10434('E', ModItems.DARK_ESSENCE.get())
                .method_10434('C', ModItems.CORRUPTINITE.get())
                .method_10434('D', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('R', ModItems.RED_ESSENCE.get())
                .method_10434('M', ModItems.MIMICARIUM.get())
                .method_10434('T', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('H', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('N', class_1802.field_22020)
                .method_10434('S', ModItems.QUADRUPLE_COMPRESSED_STICK.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY.get()))
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.RAZZORIUM.get())
                .method_10439("MAD")
                .method_10439("GHG")
                .method_10439("TAC")
                .method_10434('M', ModItems.MWDC.get())
                .method_10434('D', ModItems.DCDC.get())
                .method_10434('T', ModItems.TLDC.get())
                .method_10434('C', ModItems.CLDC.get())
                .method_10434('H', ModItems.ULTIMATE_HOE_TROPHY.get())
                .method_10434('G', ModItems.GX_BUCKET.get())
                .method_10434('A', ModItems.AXON_ALLOY.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.GX_BUCKET.get()),
                        FabricRecipeProvider.method_10426(ModItems.RAZZORIUM.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RAZZORIUM.get())));


        class_2447.method_10437(class_7800.field_40642, ModItems.RAZZOR.get())
                .method_10439("RRR")
                .method_10439("RRR")
                .method_10439("RSR")
                .method_10434('R', ModItems.RAZZORIUM.get())
                .method_10434('S', ModItems.QUATTUORDECUPLE_COMPRESSED_STICK.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RAZZORIUM.get()),
                        FabricRecipeProvider.method_10426(ModItems.RAZZOR.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RAZZOR.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.RAZZORIUM_MINER.get())
                .method_10439("RRR")
                .method_10439("RSR")
                .method_10439("RSR")
                .method_10434('R', ModItems.RAZZORIUM.get())
                .method_10434('S', ModItems.QUATTUORDECUPLE_COMPRESSED_STICK.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RAZZORIUM.get()),
                        FabricRecipeProvider.method_10426(ModItems.RAZZORIUM_MINER.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RAZZORIUM_MINER.get())));


        class_2450.method_10447(class_7800.field_40642, ModItems.TICKLE_TRAVIS_TICKLER.get())
                .method_10454(ModItems.RAZZOR.get())
                .method_10454(class_1802.field_8153)
                .method_10442(FabricRecipeProvider.method_32807(ModItems.RAZZOR.get()),
                        FabricRecipeProvider.method_10426(ModItems.TICKLE_TRAVIS_TICKLER.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.TICKLE_TRAVIS_TICKLER.get())));

        class_2450.method_10448(class_7800.field_40642, ModItems.RED_ESSENCE.get(), 4)
                .method_10454(ModItems.RENDERIUM.get())
                .method_10442(FabricRecipeProvider.method_32807(ModItems.RENDERIUM.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_ESSENCE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_ESSENCE.get())));

        class_2450.method_10448(class_7800.field_40642, ModItems.DARK_ESSENCE.get(), 4)
                .method_10454(ModItems.DENDERIUM.get())
                .method_10442(FabricRecipeProvider.method_32807(ModItems.DENDERIUM.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_ESSENCE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_ESSENCE.get())));

        //Fuels
        class_2450.method_10448(class_7800.field_40642, ModItems.THUNDER_FUEL.get(), 2)
                .method_10454(ModItems.THUNDERANIUM_INGOT.get())
                .method_10454(ModBlocks.VOID_COAL_BLOCK.get())
                .method_10442(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDER_FUEL.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDER_FUEL.get())));

        class_2447.method_10437(class_7800.field_40642, ModBlocks.VOID_COAL_BLOCK.get())
                .method_10439("###")
                .method_10439("###")
                .method_10439("###")
                .method_10434('#', ModItems.VOID_COAL.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.VOID_COAL.get()),
                        FabricRecipeProvider.method_10426(ModBlocks.VOID_COAL_BLOCK.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModBlocks.VOID_COAL_BLOCK.get())));

        //Compressed Sticks
        method_47522(exporter, class_7800.field_40642, ModItems.COMPRESSED_STICK.get(), class_1802.field_8600);
        method_47522(exporter, class_7800.field_40642, ModItems.DOUBLE_COMPRESSED_STICK.get(), ModItems.COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.TRIPLE_COMPRESSED_STICK.get(),  ModItems.DOUBLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.QUADRUPLE_COMPRESSED_STICK.get(),  ModItems.TRIPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.QUINTUPLE_COMPRESSED_STICK.get(),  ModItems.QUADRUPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.SEXTUPLE_COMPRESSED_STICK.get(),  ModItems.QUINTUPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.SEPTUPLE_COMPRESSED_STICK.get(),  ModItems.SEXTUPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.OCTUPLE_COMPRESSED_STICK.get(),  ModItems.SEPTUPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.NONUPLE_COMPRESSED_STICK.get(),  ModItems.OCTUPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.DECUPLE_COMPRESSED_STICK.get(),  ModItems.NONUPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.UNDECUPLE_COMPRESSED_STICK.get(),  ModItems.DECUPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.DUODECUPLE_COMPRESSED_STICK.get(),  ModItems.UNDECUPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.TREDECUPLE_COMPRESSED_STICK.get(),  ModItems.DUODECUPLE_COMPRESSED_STICK.get());
        method_47522(exporter, class_7800.field_40642, ModItems.QUATTUORDECUPLE_COMPRESSED_STICK.get(),  ModItems.TREDECUPLE_COMPRESSED_STICK.get());

        //Armor

        //Thunderanium
        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_HELMET.get())
                .method_10439("###")
                .method_10439("# #")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_HELMET.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_HELMET.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_CHESTPLATE.get())
                .method_10439("# #")
                .method_10439("###")
                .method_10439("###")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_CHESTPLATE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_CHESTPLATE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_LEGGINGS.get())
                .method_10439("###")
                .method_10439("# #")
                .method_10439("# #")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_LEGGINGS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_LEGGINGS.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_BOOTS.get())
                .method_10439("# #")
                .method_10439("# #")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_BOOTS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_BOOTS.get())));

        //Red Thunderanium
        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_HELMET.get())
                .method_10439("###")
                .method_10439("#T#")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('T', ModItems.THUNDERANIUM_HELMET.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_HELMET.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_HELMET.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_CHESTPLATE.get())
                .method_10439("#T#")
                .method_10439("###")
                .method_10439("###")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('T', ModItems.THUNDERANIUM_CHESTPLATE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_CHESTPLATE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_CHESTPLATE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_LEGGINGS.get())
                .method_10439("###")
                .method_10439("#T#")
                .method_10439("# #")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('T', ModItems.THUNDERANIUM_LEGGINGS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_LEGGINGS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_LEGGINGS.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_BOOTS.get())
                .method_10439("#T#")
                .method_10439("# #")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('T', ModItems.THUNDERANIUM_BOOTS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_BOOTS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_BOOTS.get())));


        //Dark Thunderanium
        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_HELMET.get())
                .method_10439("###")
                .method_10439("#T#")
                .method_10434('#', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('T', ModItems.RED_THUNDERANIUM_HELMET.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_HELMET.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_HELMET.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_CHESTPLATE.get())
                .method_10439("#T#")
                .method_10439("###")
                .method_10439("###")
                .method_10434('#', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('T', ModItems.RED_THUNDERANIUM_CHESTPLATE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_CHESTPLATE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_CHESTPLATE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_LEGGINGS.get())
                .method_10439("###")
                .method_10439("#T#")
                .method_10439("# #")
                .method_10434('#', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('T', ModItems.RED_THUNDERANIUM_LEGGINGS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_LEGGINGS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_LEGGINGS.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_BOOTS.get())
                .method_10439("#T#")
                .method_10439("# #")
                .method_10434('#', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('T', ModItems.RED_THUNDERANIUM_BOOTS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_BOOTS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_BOOTS.get())));

        //Corruptinite
        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_HELMET.get())
                .method_10439("###")
                .method_10439("#T#")
                .method_10434('#', ModItems.CORRUPTINITE.get())
                .method_10434('T', ModItems.RED_THUNDERANIUM_HELMET.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_HELMET.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_HELMET.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_CHESTPLATE.get())
                .method_10439("#T#")
                .method_10439("###")
                .method_10439("###")
                .method_10434('#', ModItems.CORRUPTINITE.get())
                .method_10434('T', ModItems.RED_THUNDERANIUM_CHESTPLATE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_CHESTPLATE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_CHESTPLATE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_LEGGINGS.get())
                .method_10439("###")
                .method_10439("#T#")
                .method_10439("# #")
                .method_10434('#', ModItems.CORRUPTINITE.get())
                .method_10434('T', ModItems.RED_THUNDERANIUM_LEGGINGS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_LEGGINGS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_LEGGINGS.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_BOOTS.get())
                .method_10439("#T#")
                .method_10439("# #")
                .method_10434('#', ModItems.CORRUPTINITE.get())
                .method_10434('T', ModItems.RED_THUNDERANIUM_BOOTS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_BOOTS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_BOOTS.get())));

        //Axon Alloy G
        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HELMET.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.DARK_THUNDERANIUM_HELMET.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HELMET.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HELMET.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXON_ALLOY_CHESTPLATE.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.DARK_THUNDERANIUM_CHESTPLATE.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_CHESTPLATE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_CHESTPLATE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXON_ALLOY_LEGGINGS.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.DARK_THUNDERANIUM_LEGGINGS.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_LEGGINGS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_LEGGINGS.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXON_ALLOY_BOOTS.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.DARK_THUNDERANIUM_BOOTS.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_BOOTS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_BOOTS.get())));

        //Axon Alloy C
        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXON_ALLOY_HELMET.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.CORRUPTINITE_HELMET.get())
                .method_10434('M', ModItems.CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXON_ALLOY_HELMET.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXON_ALLOY_HELMET.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXON_ALLOY_CHESTPLATE.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.CORRUPTINITE_CHESTPLATE.get())
                .method_10434('M', ModItems.CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXON_ALLOY_CHESTPLATE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXON_ALLOY_CHESTPLATE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXON_ALLOY_LEGGINGS.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.CORRUPTINITE_LEGGINGS.get())
                .method_10434('M', ModItems.CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXON_ALLOY_LEGGINGS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXON_ALLOY_LEGGINGS.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXON_ALLOY_BOOTS.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.CORRUPTINITE_BOOTS.get())
                .method_10434('M', ModItems.CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXON_ALLOY_BOOTS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXON_ALLOY_BOOTS.get())));

        //Axon Alloy A
        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY_HELMET.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.DARK_THUNDERANIUM_HELMET.get())
                .method_10434('M', ModItems.CORRUPTINITE_HELMET.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY_HELMET.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY_HELMET.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY_CHESTPLATE.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.DARK_THUNDERANIUM_CHESTPLATE.get())
                .method_10434('M', ModItems.CORRUPTINITE_CHESTPLATE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY_CHESTPLATE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY_CHESTPLATE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY_LEGGINGS.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.DARK_THUNDERANIUM_LEGGINGS.get())
                .method_10434('M', ModItems.CORRUPTINITE_LEGGINGS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY_LEGGINGS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY_LEGGINGS.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY_BOOTS.get())
                .method_10439("###")
                .method_10439("A#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('A', ModItems.DARK_THUNDERANIUM_BOOTS.get())
                .method_10434('M', ModItems.CORRUPTINITE_BOOTS.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY_BOOTS.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY_BOOTS.get())));


        //Tools

        //MISC
        class_2447.method_10437(class_7800.field_40642, ModItems.ANTIGLITCH_SWORD.get())
                .method_10439("EEE")
                .method_10439("E#E")
                .method_10439("EEE")
                .method_10434('#', ModItems.RED_THUNDERANIUM_SWORD.get())
                .method_10434('E', ModItems.DARK_ESSENCE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_ESSENCE.get()),
                        FabricRecipeProvider.method_10426(ModItems.ANTIGLITCH_SWORD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.ANTIGLITCH_SWORD.get())));

        class_2450.method_10447(class_7800.field_40642, ModItems.VANILLA_HOE.get())
                .method_10454(class_1802.field_8303)
                .method_10454(class_1802.field_8609)
                .method_10454(class_1802.field_8527)
                .method_10454(class_1802.field_8167)
                .method_10454(class_1802.field_8431)
                .method_10454(class_1802.field_22026)
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8167),
                        FabricRecipeProvider.method_10426(ModItems.VANILLA_HOE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.VANILLA_HOE.get())));




        //Axon
        class_2450.method_10447(class_7800.field_40642, ModItems.ULTIMATE_HOE_TROPHY.get())
                .method_10454(ModItems.VANILLA_HOE.get())
                .method_10454(ModItems.THUNDERANIUM_HOE.get())
                .method_10454(ModItems.RED_THUNDERANIUM_HOE.get())
                .method_10454(ModItems.DARK_THUNDERANIUM_HOE.get())
                .method_10454(ModItems.CORRUPTINITE_HOE.get())
                .method_10454(ModItems.CORRUPTINITE_AXON_ALLOY_HOE.get())
                .method_10454(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HOE.get())
                .method_10454(ModItems.AXON_ALLOY_HOE.get())
                .method_10442(FabricRecipeProvider.method_32807(class_1802.field_22026),
                        FabricRecipeProvider.method_10426(ModItems.ULTIMATE_HOE_TROPHY.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.ULTIMATE_HOE_TROPHY.get())));


//Thunderanium
        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_SWORD.get())
                .method_10439(" # ")
                .method_10439(" # ")
                .method_10439(" S ")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_SWORD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_SWORD.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_PICKAXE.get())
                .method_10439("###")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_PICKAXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_PICKAXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_SHOVEL.get())
                .method_10439(" # ")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_SHOVEL.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_SHOVEL.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_AXE.get())
                .method_10439("## ")
                .method_10439("#S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_AXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_AXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.THUNDERANIUM_HOE.get())
                .method_10439("## ")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.THUNDERANIUM_HOE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.THUNDERANIUM_HOE.get())));


//Red Thunderanium
        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_SWORD.get())
                .method_10439(" # ")
                .method_10439(" # ")
                .method_10439(" S ")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_SWORD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_SWORD.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_PICKAXE.get())
                .method_10439("###")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_PICKAXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_PICKAXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_SHOVEL.get())
                .method_10439(" # ")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_SHOVEL.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_SHOVEL.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_AXE.get())
                .method_10439("## ")
                .method_10439("#S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_AXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_AXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.RED_THUNDERANIUM_HOE.get())
                .method_10439("## ")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.RED_THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.RED_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.RED_THUNDERANIUM_HOE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.RED_THUNDERANIUM_HOE.get())));



//Dark Thunderanium
        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_SWORD.get())
                .method_10439("E#E")
                .method_10439("E#E")
                .method_10439("ESE")
                .method_10434('#', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('S', ModItems.ANTIGLITCH_SWORD.get())
                .method_10434('E', ModItems.DARK_ESSENCE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_SWORD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_SWORD.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_PICKAXE.get())
                .method_10439("###")
                .method_10439("ESE")
                .method_10439("EBE")
                .method_10434('#', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10434('E', ModItems.DARK_ESSENCE.get())
                .method_10434('B', ModItems.RED_THUNDERANIUM_PICKAXE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_PICKAXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_PICKAXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_SHOVEL.get())
                .method_10439("E#E")
                .method_10439("ESE")
                .method_10439("EBE")
                .method_10434('#', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10434('E', ModItems.DARK_ESSENCE.get())
                .method_10434('B', ModItems.RED_THUNDERANIUM_SHOVEL.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_SHOVEL.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_SHOVEL.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXE.get())
                .method_10439("##E")
                .method_10439("#SE")
                .method_10439("EBE")
                .method_10434('#', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10434('E', ModItems.DARK_ESSENCE.get())
                .method_10434('B', ModItems.RED_THUNDERANIUM_AXE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_HOE.get())
                .method_10439("##E")
                .method_10439("ESE")
                .method_10439("EBE")
                .method_10434('#', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10434('S', class_1802.field_8600)
                .method_10434('E', ModItems.DARK_ESSENCE.get())
                .method_10434('B', ModItems.RED_THUNDERANIUM_HOE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.DARK_THUNDERANIUM_INGOT.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_HOE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_HOE.get())));


//Corruptinite
        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_SWORD.get())
                .method_10439(" # ")
                .method_10439(" # ")
                .method_10439(" S ")
                .method_10434('#', ModItems.CORRUPTINITE.get())
                .method_10434('S', ModItems.ANTIGLITCH_SWORD.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_SWORD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_SWORD.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_PICKAXE.get())
                .method_10439("###")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.CORRUPTINITE.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_PICKAXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_PICKAXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_SHOVEL.get())
                .method_10439(" # ")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.CORRUPTINITE.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_SHOVEL.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_SHOVEL.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXE.get())
                .method_10439("## ")
                .method_10439("#S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.CORRUPTINITE.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_HOE.get())
                .method_10439("## ")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10434('#', ModItems.CORRUPTINITE.get())
                .method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(ModItems.CORRUPTINITE.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_HOE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_HOE.get())));

//Axon Alloy G
        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SWORD.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.DARK_THUNDERANIUM_SWORD.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SWORD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SWORD.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXON_ALLOY_AXE.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.DARK_THUNDERANIUM_AXE.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_AXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_AXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXON_ALLOY_PICKAXE.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.DARK_THUNDERANIUM_PICKAXE.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_PICKAXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_PICKAXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SHOVEL.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.DARK_THUNDERANIUM_SHOVEL.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SHOVEL.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SHOVEL.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HOE.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.DARK_THUNDERANIUM_HOE.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_INGOT.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HOE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HOE.get())));

//Axon Alloy C
        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXON_ALLOY_SWORD.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_SWORD.get())
                .method_10434('M', ModItems.CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXON_ALLOY_SWORD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXON_ALLOY_SWORD.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXON_ALLOY_AXE.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_AXE.get())
                .method_10434('M', ModItems.CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXON_ALLOY_AXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXON_ALLOY_AXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXON_ALLOY_PICKAXE.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_PICKAXE.get())
                .method_10434('M', ModItems.CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXON_ALLOY_PICKAXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXON_ALLOY_PICKAXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXON_ALLOY_SHOVEL.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_SHOVEL.get())
                .method_10434('M', ModItems.CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXON_ALLOY_SHOVEL.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXON_ALLOY_SHOVEL.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.CORRUPTINITE_AXON_ALLOY_HOE.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_HOE.get())
                .method_10434('M', ModItems.CORRUPTINITE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.CORRUPTINITE_AXON_ALLOY_HOE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.CORRUPTINITE_AXON_ALLOY_HOE.get())));

//Axon Alloy A
        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY_SWORD.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_SWORD.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_SWORD.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY_SWORD.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY_SWORD.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY_AXE.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_AXE.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_AXE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY_AXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY_AXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY_PICKAXE.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_PICKAXE.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_PICKAXE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY_PICKAXE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY_PICKAXE.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY_SHOVEL.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_SHOVEL.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_SHOVEL.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY_SHOVEL.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY_SHOVEL.get())));

        class_2447.method_10437(class_7800.field_40642, ModItems.AXON_ALLOY_HOE.get())
                .method_10439("###")
                .method_10439("T#M")
                .method_10439("###")
                .method_10434('#', ModItems.AXON_ALLOY.get())
                .method_10434('T', ModItems.CORRUPTINITE_HOE.get())
                .method_10434('M', ModItems.DARK_THUNDERANIUM_HOE.get())
                .method_10429(FabricRecipeProvider.method_32807(ModItems.AXON_ALLOY.get()),
                        FabricRecipeProvider.method_10426(ModItems.AXON_ALLOY_HOE.get()))
                .method_17972(exporter, new class_2960(FabricRecipeProvider.method_36450(ModItems.AXON_ALLOY_HOE.get())));



    }
}
