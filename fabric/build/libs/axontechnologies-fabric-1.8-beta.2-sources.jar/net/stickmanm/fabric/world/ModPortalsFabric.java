package net.stickmanm.fabric.world;

import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.kyrptonaught.customportalapi.api.CustomPortalBuilder;
import net.kyrptonaught.customportalapi.portal.PortalIgnitionSource;
import net.kyrptonaught.customportalapi.portal.PortalPlacer;
import net.minecraft.class_1271;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.item.ModItems;

import java.util.List;

import static net.stickmanm.axontechnologies.world.dimension.ModDimensions.*;

public class ModPortalsFabric {

    public static void registerModPortalsFabric() {
        //DREAD CAVERNS PORTAL
        CustomPortalBuilder.beginPortal()
                .frameBlock(ModBlocks.VOIDSTONE.get())
                .destDimID(DCDIM_DIMENSION_KEY.method_29177())
                .tintColor(0, 0,0)
                .lightWithItem(ModItems.DREADED_IGNITER.get())
                .flatPortal()
                .registerPortal();


        //MIMIC WORLD PORTAL
        CustomPortalBuilder.beginPortal()
                .frameBlock(ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get())
                .destDimID(MIMDIM_DIMENSION_KEY.method_29177())
                .tintColor(144, 238, 144)
                .lightWithItem(ModItems.MIMICARIUM_IGNITER.get())
                .registerPortal();

        //THUNDERLANDS PORTAL
        CustomPortalBuilder.beginPortal()
                .frameBlock(ModBlocks.THUNDERANIUM_PORTAL_FRAME.get())
                .destDimID(THUNDERLANDS_DIMENSION_KEY.method_29177())
                .tintColor(170, 169, 173)
                .lightWithItem(ModItems.THUNDERANIUM_KEY.get())
                .registerPortal();

        //CORRUPTEDLANDS PORTAL
        CustomPortalBuilder.beginPortal()
                .frameBlock(ModBlocks.CORRUPTION_PORTAL_FRAME.get())
                .destDimID(CORRUPTIONLANDS_DIMENSION_KEY.method_29177())
                .tintColor(139, 0, 0)
                .lightWithItem(ModItems.CORRUPTION_GATEWAY.get())
                .returnDim(THUNDERLANDS_DIMENSION_KEY.method_29177(), false)
                .registerPortal();


        // Universal igniter: try each portal's igniter, the frame decides which one actually lights
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 stack = player.method_5998(hand);
            if (world.field_9236 || !stack.method_31574(ModItems.UNIVERSAL_IGNITER.get()))
                return class_1271.method_22430(stack);

            class_239 hit = player.method_5745(6, 1, false);
            if (hit.method_17783() != class_239.class_240.field_1332)
                return class_1271.method_22430(stack);

            class_3965 blockHit = (class_3965) hit;
            class_2338 lightPos = blockHit.method_17777().method_10093(blockHit.method_17780());

            for (class_1792 igniter : List.of(
                    ModItems.DREADED_IGNITER.get(),
                    ModItems.MIMICARIUM_IGNITER.get(),
                    ModItems.THUNDERANIUM_KEY.get(),
                    ModItems.CORRUPTION_GATEWAY.get())) {
                if (PortalPlacer.attemptPortalLight(world, lightPos,
                        PortalIgnitionSource.ItemUseSource(igniter).withPlayer(player))) {
                    return class_1271.method_22427(stack);
                }
            }
            return class_1271.method_22430(stack);
        });

    }


}
