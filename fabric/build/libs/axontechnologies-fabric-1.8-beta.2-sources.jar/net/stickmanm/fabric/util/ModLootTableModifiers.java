package net.stickmanm.fabric.util;

import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.item.ModItems;

public class ModLootTableModifiers {
    private static final class_2960 ARCHAEOLOGY_DESERT_TEMPLE_ID =
            new class_2960("minecraft", "archaeology/desert_pyramid");

    private static final class_2960 ARCHAEOLOGY_TRAIL_RUINS_ID =
            new class_2960("minecraft", "archaeology/trail_ruins_common");

    private static final class_2960 ARCHAEOLOGY_TRAIL_RUINS_RARE_ID =
            new class_2960("minecraft", "archaeology/trail_ruins_rare");

    private static final class_2960 DESERT_TEMPLE_ID =
            new class_2960("minecraft", "chests/desert_pyramid");

    private static final class_2960 ANCIENT_CITY_ID =
            new class_2960("minecraft", "chests/ancient_city");

    private static final class_2960 END_CITY_ID =
            new class_2960("minecraft", "chests/end_city_treasure");

    private static final class_2960 BURIED_TREASURE_ID =
            new class_2960("minecraft", "chests/buried_treasure");



    public static void modifyLootTables() {
        LootTableEvents.MODIFY.register((resourceManager, lootManager, id, tableBuilder, source) -> {


            if(DESERT_TEMPLE_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.05f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModBlocks.THUNDERED_SAPLING.get().method_8389()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)));

                tableBuilder.pool(poolBuilder.method_355());
            }

            if(DESERT_TEMPLE_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.1f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModItems.QUADRUPLE_COMPRESSED_STICK.get()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)));

                tableBuilder.pool(poolBuilder.method_355());
            }

            if(ANCIENT_CITY_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.5f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModItems.QUADRUPLE_COMPRESSED_STICK.get()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 3.5f)));

                tableBuilder.pool(poolBuilder.method_355());

            }

            if(ANCIENT_CITY_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.001f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModItems.QUATTUORDECUPLE_COMPRESSED_STICK.get()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)));

                tableBuilder.pool(poolBuilder.method_355());
            }

            if(END_CITY_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.5f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModItems.QUADRUPLE_COMPRESSED_STICK.get()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 3.5f)));

                tableBuilder.pool(poolBuilder.method_355());
            }

            if(END_CITY_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.01f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModItems.QUATTUORDECUPLE_COMPRESSED_STICK.get()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)));

                tableBuilder.pool(poolBuilder.method_355());
            }

            if(END_CITY_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.15f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModItems.QUINTUPLE_COMPRESSED_STICK.get()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)));

                tableBuilder.pool(poolBuilder.method_355());
            }

            if(BURIED_TREASURE_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.15f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModItems.QUINTUPLE_COMPRESSED_STICK.get()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)));

                tableBuilder.pool(poolBuilder.method_355());
            }
            if(BURIED_TREASURE_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.001f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModItems.QUATTUORDECUPLE_COMPRESSED_STICK.get()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)));

                tableBuilder.pool(poolBuilder.method_355());
            }
            if(BURIED_TREASURE_ID.equals(id)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.1f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModBlocks.THUNDERED_SAPLING.get().method_8389()))
                        .method_353(class_141.method_621(class_5662.method_32462(1.0f, 1.0f)));

                tableBuilder.pool(poolBuilder.method_355());
            }



        });

        LootTableEvents.REPLACE.register((resourceManager, lootManager, id, original, source) -> {

            if(ARCHAEOLOGY_DESERT_TEMPLE_ID.equals(id)){
                class_55.class_56 pool = class_55.method_347()
                        .method_351(class_77.method_411(ModBlocks.THUNDERED_SAPLING.get()))
                        .method_351(class_77.method_411(ModItems.QUADRUPLE_COMPRESSED_STICK.get()));
                for (int i = 0; i < original.field_943[0].field_953.length; i++) {
                    pool.with(original.field_943[0].field_953[i]);
                }
                return class_52.method_324().method_336(pool).method_338();
            }

            if(ARCHAEOLOGY_TRAIL_RUINS_ID.equals(id)){
                class_55.class_56 pool = class_55.method_347()
                        .method_351(class_77.method_411(ModBlocks.THUNDERED_SAPLING.get()))
                        .method_351(class_77.method_411(ModItems.QUADRUPLE_COMPRESSED_STICK.get()));
                for (int i = 0; i < original.field_943[0].field_953.length; i++) {
                    pool.with(original.field_943[0].field_953[i]);
                }
                return class_52.method_324().method_336(pool).method_338();
            }

            if(ARCHAEOLOGY_TRAIL_RUINS_RARE_ID.equals(id)){
                class_55.class_56 pool = class_55.method_347()
                        .method_351(class_77.method_411(ModBlocks.THUNDERED_SAPLING.get()))
                        .method_351(class_77.method_411(ModItems.QUADRUPLE_COMPRESSED_STICK.get()))
                        .method_351(class_77.method_411(ModItems.QUINTUPLE_COMPRESSED_STICK.get()))
                        .method_351(class_77.method_411(ModItems.QUATTUORDECUPLE_COMPRESSED_STICK.get()));
                for (int i = 0; i < original.field_943[0].field_953.length; i++) {
                    pool.with(original.field_943[0].field_953[i]);
                }
                return class_52.method_324().method_336(pool).method_338();
            }


            return null;
        });
    }
}
