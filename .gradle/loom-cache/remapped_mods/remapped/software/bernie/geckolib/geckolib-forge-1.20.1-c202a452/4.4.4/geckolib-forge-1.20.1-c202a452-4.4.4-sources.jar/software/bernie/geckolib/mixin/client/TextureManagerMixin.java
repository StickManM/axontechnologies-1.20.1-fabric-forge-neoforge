package software.bernie.geckolib.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import software.bernie.geckolib.cache.texture.AnimatableTexture;

import java.util.Map;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.util.Identifier;

@Mixin(TextureManager.class)
public abstract class TextureManagerMixin {
	@Shadow @Final private Map<Identifier, AbstractTexture> byPath;

	@Shadow public abstract void register(Identifier resourceLocation, AbstractTexture abstractTexture);

	@Inject(method = "getTexture(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/texture/AbstractTexture;", at = @At("HEAD"))
	private void wrapAnimatableTexture(Identifier path, CallbackInfoReturnable<AbstractTexture> callback) {
		AbstractTexture existing = this.byPath.get(path);

		if (existing == null) {
			existing = new AnimatableTexture(path);

			register(path, existing);
		}
	}
}
