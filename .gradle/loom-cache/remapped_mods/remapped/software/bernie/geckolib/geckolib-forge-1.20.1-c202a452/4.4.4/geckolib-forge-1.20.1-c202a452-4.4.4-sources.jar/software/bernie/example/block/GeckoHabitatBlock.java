package software.bernie.example.block;

import software.bernie.example.block.entity.GeckoHabitatBlockEntity;
import software.bernie.example.client.model.block.GeckoHabitatModel;
import software.bernie.example.client.renderer.block.GeckoHabitatBlockRenderer;
import software.bernie.example.registry.BlockEntityRegistry;

import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;

/**
 * Example animated block using GeckoLib animations.<br>
 * There's nothing to see here since the {@link Block} class itself has little to do with animations
 * @see GeckoHabitatModel
 * @see GeckoHabitatBlockEntity
 * @see GeckoHabitatBlockRenderer
 */
public class GeckoHabitatBlock extends BlockWithEntity implements BlockEntityProvider {
	public static final DirectionProperty FACING = BlockStateProperties.FACING;

	public GeckoHabitatBlock() {
		super(Settings.of().noOcclusion());
	}

	@Override
	public BlockRenderType getRenderShape(BlockState state) {
		return BlockRenderType.ENTITYBLOCK_ANIMATED;
	}

	@Override
	protected void createBlockStateDefinition(StateManager.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Nullable
	@Override
	public BlockState getStateForPlacement(ItemPlacementContext context) {
		return this.defaultBlockState().setValue(FACING,
				context.getHorizontalDirection().getClockWise().getClockWise());
	}

	@Nullable
	@Override
	public BlockEntity newBlockEntity(BlockPos blockPos, BlockState blockState) {
		return BlockEntityRegistry.GECKO_HABITAT.get().create(blockPos, blockState);
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
		return switch (state.getValue(FACING)) {
			case NORTH -> Block.box(0, 0, 0, 32, 16, 16);
			case SOUTH -> Block.box(-16, 0, 0, 16, 16, 16);
			case WEST -> Block.box(0, 0, -16, 16, 16, 16);
			default -> Block.box(0, 0, 0, 16, 16, 32);
		};
	}

	@Override
	public boolean canSurvive(BlockState state, WorldView world, BlockPos pos) {
		for (BlockPos testPos : BlockPos.betweenClosed(pos,
				pos.relative(state.getValue(FACING).getClockWise(), 2))) {
			if (!testPos.equals(pos) && !world.getBlockState(testPos).isAir())
				return false;
		}

		return true;
	}
}
