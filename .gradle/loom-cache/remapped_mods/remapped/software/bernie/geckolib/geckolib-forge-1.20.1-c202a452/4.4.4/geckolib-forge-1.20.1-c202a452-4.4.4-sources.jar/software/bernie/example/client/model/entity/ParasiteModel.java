package software.bernie.example.client.model.entity;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import software.bernie.example.client.renderer.entity.ParasiteRenderer;
import software.bernie.example.entity.ParasiteEntity;
import software.bernie.geckolib.GeckoLib;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.model.GeoModel;

/**
 * Example {@link GeoModel} for the {@link ParasiteEntity}
 * @see ParasiteRenderer
 */
public class ParasiteModel extends DefaultedEntityGeoModel<ParasiteEntity> {
	public ParasiteModel() {
		super(new Identifier(GeckoLib.MOD_ID, "parasite"));
	}

	// We want our model to render using the translucent render type
	@Override
	public RenderLayer getRenderType(ParasiteEntity animatable, Identifier texture) {
		return RenderLayer.entityTranslucent(getTextureResource(animatable));
	}
}