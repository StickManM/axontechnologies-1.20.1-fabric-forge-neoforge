package net.stickmanm.axontechnologies.entity.custom;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1314;
import net.minecraft.class_1347;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1590;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3988;
import net.minecraft.class_4255;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;
import net.stickmanm.axontechnologies.entity.ModEntities;
import net.stickmanm.axontechnologies.item.ModItems;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animatable.instance.SingletonAnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;

public class LostMinerEntity extends class_1314 implements GeoEntity {
    private AnimatableInstanceCache cache = new SingletonAnimatableInstanceCache(this);
    public LostMinerEntity(class_1299<? extends class_1314> entityType, class_1937 world) {
        super(entityType, world);
    }



    public static class_5132.class_5133 setAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23718, 0.2f)
                .method_26868(class_5134.field_23722, 0.4f)
                .method_26868(class_5134.field_23717, 15)
                .method_26868(class_5134.field_23716, 40.0D)
                .method_26868(class_5134.field_23721, 15f)
                .method_26868(class_5134.field_23723, 5.0f)
                .method_26868(class_5134.field_23726, 1.5f)
                .method_26868(class_5134.field_23719, 0.25f);


    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(1, new class_1347(this));
        this.field_6201.method_6277(2, new class_1366(this, 1.2D, false));
        this.field_6201.method_6277(3, new class_1394(this, 0.75f, 1));
        this.field_6201.method_6277(1, new class_4255(this, false));
        this.field_6185.method_6277(1, new class_1399(this, new Class[0]).method_6318(class_1590.class));




        this.field_6201.method_6277(4, new class_1376(this));

        this.field_6185.method_6277(2, new class_1400<>(this, class_1657.class, true));
        this.field_6185.method_6277(2, new class_1400<>(this, class_3988.class, true));
        this.field_6185.method_6277(3, new class_1400<>(this, class_1646.class, true));
        this.method_5673(class_1304.field_6173, new class_1799(class_1802.field_22024));
        this.method_6092(new class_1293(class_1294.field_5906, 200, 0, false, false, false));
        this.method_6092(new class_1293(class_1294.field_5924, -1, 0, false, false, false));



    }





    @Nullable

    public class_1308 createChild(class_3218 world, class_1308 entity) {
        return ModEntities.LOST_MINER.get().method_5883(world);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllerRegistrar) {
        controllerRegistrar.add(new AnimationController<>(this, "controller", 0, this::predicate));

    }

    private <T extends GeoAnimatable> PlayState predicate(AnimationState<T> tAnimationState) {
        if (tAnimationState.isMoving()){
            tAnimationState.getController().setAnimation(RawAnimation.begin().then("animation.lostminer.walking", Animation.LoopType.LOOP));
            return PlayState.CONTINUE;
        }

        tAnimationState.getController().setAnimation(RawAnimation.begin().then("animation.lostminer.idle", Animation.LoopType.LOOP));
        return PlayState.CONTINUE;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
