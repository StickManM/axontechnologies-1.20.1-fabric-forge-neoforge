package net.stickmanm.axontechnologies.entity.custom;

import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1314;
import net.minecraft.class_1347;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1590;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3988;
import net.minecraft.class_4255;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_7260;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.passive.*;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.effect.ModEffects;
import net.stickmanm.axontechnologies.entity.ModEntities;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animatable.instance.SingletonAnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;

public class RedEssenceZombieEntity extends class_1314 implements GeoEntity {
    private AnimatableInstanceCache cache = new SingletonAnimatableInstanceCache(this);
    public RedEssenceZombieEntity(class_1299<? extends class_1314> entityType, class_1937 world) {
        super(entityType, world);
    }



    public static class_5132.class_5133 setAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23718, 0.2f)
                .method_26868(class_5134.field_23722, 0.4f)
                .method_26868(class_5134.field_23717, 64)
                .method_26868(class_5134.field_23716, 100.0D)
                .method_26868(class_5134.field_23721, 40.0f)
                .method_26868(class_5134.field_23723, 5.0f)
                .method_26868(class_5134.field_23726, 50.5f)
                .method_26868(class_5134.field_23719, 1.0f);


    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(1, new class_1347(this));
        this.field_6201.method_6277(2, new class_1366(this, 1.2D, false));
        this.field_6201.method_6277(3, new class_1394(this, 0.75f, 1));
        this.field_6201.method_6277(1, new class_4255(this, false));
        this.field_6185.method_6277(1, new class_1399(this, new Class[0]).method_6318(class_1590.class));



        this.field_6201.method_6277(4, new class_1376(this));

        this.field_6185.method_6277(2, new class_1400<>(this, class_1657.class, false));
        this.field_6185.method_6277(2, new class_1400<>(this, LostMinerEntity.class, false));
        this.field_6185.method_6277(2, new class_1400<>(this, class_3988.class, false));
        this.field_6185.method_6277(2, new class_1400<>(this, class_1646.class, false));
        this.field_6185.method_6277(3, new class_1400<>(this, class_7260.class, false));
        this.method_6092(new class_1293(class_1294.field_5900, -1, 2,false, false, false));



    }



    @Nullable

    public class_1308 createChild(class_3218 world, class_1308 entity) {
        return ModEntities.RED_ESSENCE_ZOMBIE.get().method_5883(world);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllerRegistrar) {
        controllerRegistrar.add(new AnimationController<>(this, "controller", 0, this::predicate));

    }

    private <T extends GeoAnimatable> PlayState predicate(AnimationState<T> tAnimationState) {
        if (tAnimationState.isMoving()){
            tAnimationState.getController().setAnimation(RawAnimation.begin().then("animation.modified_RedEssenceZombie.walking", Animation.LoopType.LOOP));
            return PlayState.CONTINUE;
        }

        tAnimationState.getController().setAnimation(RawAnimation.begin().then("animation.modified_RedEssenceZombie.idle", Animation.LoopType.LOOP));
        return PlayState.CONTINUE;
    }

    public boolean method_5643(class_1282 source, float amount) {
        // 1. Call the super method first to process the damage normally
        boolean damaged = super.method_5643(source, amount);

        // 2. Only apply the effect if the entity was successfully damaged
        if (damaged) {
            this.method_6092(new class_1293(class_1294.field_5909, 10, 255,false, false, false));
        }

        return damaged;
    }

    public void method_5773() {
        super.method_5773();

        // Check for transformation logic every tick
        class_2338 currentPos = this.method_24515();

        if (this.method_6059(ModEffects.GLITCHSTERX.get())) {
            convertEntity();

        }

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2338 sidePos = currentPos.method_10093(direction);

            // Note: We check the block at the entity's Y-level, assuming the side touch happens here.
            if (this.tryTransform(sidePos)) {
                return;
            }
        }

        class_2338 upperPos = currentPos.method_10084();
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            if (this.tryTransform(upperPos.method_10093(direction))) {
                return;
            }
        }
    }

    private boolean tryTransform(class_2338 pos) {
        class_2680 state = this.method_37908().method_8320(pos);

        // Check if the block at the given position is the trigger block (Cobblestone)
        if (state.method_27852(ModBlocks.CORRUPTION_BLOCK.get())) {

            corruptEntity();
            // Tell the tick loop that the transformation happened
            return true;
        }

        return false;
    }


    private void convertEntity() {
        // This conversion should only happen on the server side
        if (!(this.method_37908() instanceof class_3218 serverWorld)) {
            return;
        }

        // 1. Get the target entity type (e.g., a vanilla Zombie)
        class_1299<GeneticallyModifiedRedEssenceZombieEntity> targetType = ModEntities.GENETICALLY_MODIFIED_RED_ESSENCE_ZOMBIE.get(); // Change to your desired entity type

        // 2. Create the new entity at the current location
        class_1308 newEntity = targetType.method_5883(serverWorld);
        if (newEntity == null) {
            return;
        }

        newEntity.method_5719(this);

        // Optional: Copy NBT data (inventory, name, health, etc.)
        class_2487 nbt = new class_2487();
        this.method_5647(nbt);
        newEntity.method_5651(nbt);
        newEntity.method_6033(this.method_6032());

        // 3. Remove the original entity and add the new one
        this.method_31472(); // Removes the custom entity from the world
        serverWorld.method_30771(newEntity);

        // Optional: Add visual/sound effects for the transformation
        // serverWorld.syncWorldEvent(WorldEvents.ZOMBIE_VILLAGER_CURES, this.getBlockPos(), 0);
    }

    private void corruptEntity() {
        // This conversion should only happen on the server side
        if (!(this.method_37908() instanceof class_3218 serverWorld)) {
            return;
        }

        // 1. Get the target entity type (e.g., a vanilla Zombie)
        class_1299<DarkEssenceZombieEntity> targetType = ModEntities.DARK_ESSENCE_ZOMBIE.get(); // Change to your desired entity type

        // 2. Create the new entity at the current location
        class_1308 newEntity = targetType.method_5883(serverWorld);
        if (newEntity == null) {
            return;
        }

        newEntity.method_5719(this);

        // Optional: Copy NBT data (inventory, name, health, etc.)
        class_2487 nbt = new class_2487();
        this.method_5647(nbt);
        newEntity.method_5651(nbt);
        newEntity.method_6033(this.method_6032());

        // 3. Remove the original entity and add the new one
        this.method_31472(); // Removes the custom entity from the world
        serverWorld.method_30771(newEntity);

        // Optional: Add visual/sound effects for the transformation
        // serverWorld.syncWorldEvent(WorldEvents.ZOMBIE_VILLAGER_CURES, this.getBlockPos(), 0);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
