package net.stickmanm.axontechnologies.entity.client;

import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.entity.custom.LostMinerEntity;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class LostMinerRenderer extends GeoEntityRenderer<LostMinerEntity> {
    public LostMinerRenderer(class_5617.class_5618 renderManager) {
        super(renderManager, new LostMinerModel());
    }

    @Override
    public class_2960 getTextureLocation(LostMinerEntity animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "textures/entity/lost_miner.png");
    }

    @Override
    public void render(LostMinerEntity entity, float entityYaw, float partialTick, class_4587 poseStack,
                       class_4597 bufferSource, int packedLight) {
        if (entity.method_6109()){
            poseStack.method_22905(0.4f, 0.4f, 0.4f);
        }
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }
}
