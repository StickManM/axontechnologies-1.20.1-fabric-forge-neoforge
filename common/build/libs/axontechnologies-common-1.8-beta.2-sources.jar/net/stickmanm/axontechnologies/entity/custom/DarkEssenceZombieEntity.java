package net.stickmanm.axontechnologies.entity.custom;

import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1347;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1590;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3988;
import net.minecraft.class_4255;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_7260;
import net.minecraft.entity.ai.goal.*;
import net.stickmanm.axontechnologies.effect.ModEffects;
import net.stickmanm.axontechnologies.entity.ModEntities;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animatable.instance.SingletonAnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;

public class DarkEssenceZombieEntity extends class_1314 implements GeoEntity {
    private AnimatableInstanceCache cache = new SingletonAnimatableInstanceCache(this);
    public DarkEssenceZombieEntity(class_1299<? extends class_1314> entityType, class_1937 world) {
        super(entityType, world);
    }



    public static class_5132.class_5133 setAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23718, 0.5f)
                .method_26868(class_5134.field_23722, 0.5f)
                .method_26868(class_5134.field_23717, 96)
                .method_26868(class_5134.field_23716, 110.0D)
                .method_26868(class_5134.field_23721, 45.0f)
                .method_26868(class_5134.field_23723, 5.0f)
                .method_26868(class_5134.field_23726, 50.5f)
                .method_26868(class_5134.field_23719, 1.01f);


    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(1, new class_1347(this));
        this.field_6201.method_6277(2, new class_1366(this, 5D, false));
        this.field_6201.method_6277(3, new class_1394(this, 0.75f, 1));
        this.field_6201.method_6277(1, new class_4255(this, false));
        this.field_6185.method_6277(1, new class_1399(this, new Class[0]).method_6318(class_1590.class));



        this.field_6201.method_6277(4, new class_1376(this));

        this.field_6185.method_6277(2, new class_1400<>(this, class_1657.class, false));
        this.field_6185.method_6277(2, new class_1400<>(this, RedEssenceZombieEntity.class, false));
        this.field_6185.method_6277(2, new class_1400<>(this, GeneticallyModifiedRedEssenceZombieEntity.class, false));
        this.field_6185.method_6277(2, new class_1400<>(this, LostMinerEntity.class, false));
        this.field_6185.method_6277(2, new class_1400<>(this, class_3988.class, false));
        this.field_6185.method_6277(3, new class_1400<>(this, class_1646.class, false));
        this.field_6185.method_6277(3, new class_1400<>(this, class_7260.class, false));
        this.method_6092(new class_1293(class_1294.field_5900, -1, 2,false, false, false));


    }



    @Nullable

    public class_1308 createChild(class_3218 world, class_1308 entity) {
        return ModEntities.DARK_ESSENCE_ZOMBIE.get().method_5883(world);
    }

    public boolean method_6121(class_1297 target) {
        if (!super.method_6121(target)) {
            return false;
        } else {
            if (target instanceof class_1309) {
                ((class_1309)target).method_37222(new class_1293(ModEffects.ANTIGLITCHSTER.get(), 1200), this);
            }

            return true;
        }
    }

    public boolean method_5643(class_1282 source, float amount) {
        // 1. Call the super method first to process the damage normally
        boolean damaged = super.method_5643(source, amount);

        // 2. Only apply the effect if the entity was successfully damaged
        if (damaged) {
            this.method_6092(new class_1293(class_1294.field_5909, 15, 255,false, false, false));
        }

        return damaged;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllerRegistrar) {
        controllerRegistrar.add(new AnimationController<>(this, "controller", 0, this::predicate));

    }

    private <T extends GeoAnimatable> PlayState predicate(AnimationState<T> tAnimationState) {
        if (tAnimationState.isMoving()){
            tAnimationState.getController().setAnimation(RawAnimation.begin().then("animation.modified_RedEssenceZombie.walking", Animation.LoopType.LOOP));
            return PlayState.CONTINUE;
        }

        tAnimationState.getController().setAnimation(RawAnimation.begin().then("animation.modified_RedEssenceZombie.idle", Animation.LoopType.LOOP));
        return PlayState.CONTINUE;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
