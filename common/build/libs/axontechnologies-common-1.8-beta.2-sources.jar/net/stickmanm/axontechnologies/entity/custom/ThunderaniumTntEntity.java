package net.stickmanm.axontechnologies.entity.custom;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1541;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3532;
import net.stickmanm.axontechnologies.entity.ModEntities;
import org.jetbrains.annotations.Nullable;

public class ThunderaniumTntEntity extends class_1541 {

    // Default constructor for entity type creation
    public ThunderaniumTntEntity(class_1299<? extends class_1541> entityType, class_1937 world) {
        super(entityType, world);
    }

    // Constructor used when the block is primed
    public ThunderaniumTntEntity(class_1937 world, double x, double y, double z, @Nullable class_1309 igniter) {
        this(ModEntities.THUNDERANIUM_TNT_ENTITY_TYPE.get(), world); // Use your registered entity type
        this.method_5814(x, y, z);
        float f = this.method_37908().field_9229.method_43057() * (float)Math.PI * 2.0F; // 6.2831855F
        this.method_18800(-((float)class_3532.method_15374(f)) * 0.02F, 0.2F, -((float)class_3532.method_15362(f)) * 0.02F);
        this.method_6967(80); // Set fuse to 4 seconds (80 ticks)
    }

    @Override
    public void method_5773() {
        if (!this.method_5740()) {
            this.method_18799(this.method_18798().method_1031(0.0, -0.04, 0.0));
        }
        this.method_5784(class_1313.field_6308, this.method_18798());
        this.method_18799(this.method_18798().method_1021(0.98));
        if (this.method_24828()) {
            this.method_18799(this.method_18798().method_18805(0.7, -0.5, 0.7));
        }
        int i = this.method_6969() - 1;
        this.method_6967(i);
        if (i <= 0) {
            this.method_31472();
            if (!this.method_37908().field_9236) {
                this.method_6971();
            }
        } else {
            this.method_5876();
            if (this.method_37908().field_9236) {
                this.method_37908().method_8406(class_2398.field_11251, this.method_23317(), this.method_23318() + 0.5, this.method_23321(), 0.0, 0.0, 0.0);
            }
        }
    }


    // Override the core explosion logic
    protected void method_6971() {
        // Customize your explosion here
        float explosionPower = 75.0F; // TNT is 4.0F. 6.0F is a bigger blast.

        // Explosion.DestructionType.BREAK causes block damage.
        // true sets the explosion to be 'Smoking' (fire)
        this.method_37908().method_8537(this, this.method_23317(), this.method_23323(1), this.method_23321(),
                explosionPower, false, class_1937.class_7867.field_40891);

        // Add custom status effects or other events here
    }
}
