package net.stickmanm.axontechnologies.entity;

import dev.architectury.registry.level.entity.EntityAttributeRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.entity.custom.*;

import java.util.function.Supplier;

public class ModEntities {

    public static final DeferredRegister<class_1299<?>> ENTITIES =
            DeferredRegister.create(AxonTechnologiesConstants.MOD_ID, class_7924.field_41266);

    public static final RegistrySupplier<class_1299<RedEssenceZombieEntity>> RED_ESSENCE_ZOMBIE = registerEntity("red_essence_zombie",
            () -> class_1299.class_1300.method_5903(RedEssenceZombieEntity::new, class_1311.field_6302)
                    .method_19947()
                    .method_17687(0.6f,2f)
                    .method_5905("red_essence_zombie"));

    public static final RegistrySupplier<class_1299<DarkEssenceZombieEntity>> DARK_ESSENCE_ZOMBIE = registerEntity("dark_essence_zombie",
            () -> class_1299.class_1300.method_5903(DarkEssenceZombieEntity::new, class_1311.field_6302)
                    .method_19947()
                    .method_17687(0.6f,2f)
                    .method_5905("dark_essence_zombie"));

    public static final RegistrySupplier<class_1299<LostMinerEntity>> LOST_MINER = registerEntity("lost_miner",
            () -> class_1299.class_1300.method_5903(LostMinerEntity::new, class_1311.field_6302)
                    .method_17687(0.6f,2f)
                    .method_5905("lost_miner"));

    public static final RegistrySupplier<class_1299<GeneticallyModifiedRedEssenceZombieEntity>> GENETICALLY_MODIFIED_RED_ESSENCE_ZOMBIE = registerEntity("genetically_modified_red_essence_zombie",
            () -> class_1299.class_1300.method_5903(GeneticallyModifiedRedEssenceZombieEntity::new, class_1311.field_6302)
                    .method_19947()
                    .method_17687(0.6f,2f)
                    .method_5905("genetically_modified_red_essence_zombie"));

    public static final RegistrySupplier<class_1299<ThunderaniumTntEntity>> THUNDERANIUM_TNT_ENTITY_TYPE = registerEntity("primed_thunderanium_tnt",
            () -> class_1299.class_1300.<ThunderaniumTntEntity>method_5903(ThunderaniumTntEntity::new, class_1311.field_17715)
                    .method_17687(0.98F, 0.98F)
                    .method_27299(10)
                    .method_5905("primed_thunderanium_tnt"));

    public static final RegistrySupplier<class_1299<RedThunderaniumTntEntity>> RED_THUNDERANIUM_TNT_ENTITY_TYPE = registerEntity("primed_red_thunderanium_tnt",
            () -> class_1299.class_1300.<RedThunderaniumTntEntity>method_5903(RedThunderaniumTntEntity::new, class_1311.field_17715)
                    .method_17687(0.98F, 0.98F)
                    .method_27299(10)
                    .method_5905("primed_red_thunderanium_tnt"));

    public static final RegistrySupplier<class_1299<AxonAlloyTntEntity>> AXON_ALLOY_TNT_ENTITY_TYPE = registerEntity("primed_axon_alloy_tnt",
            () -> class_1299.class_1300.<AxonAlloyTntEntity>method_5903(AxonAlloyTntEntity::new, class_1311.field_17715)
                    .method_17687(0.98F, 0.98F)
                    .method_27299(10)
                    .method_5905("primed_axon_alloy_tnt"));

    private static <T extends class_1299<?>> RegistrySupplier<T> registerEntity(String name, Supplier<T> entity) {
        return ENTITIES.register(name, entity);
    }

    public static void registerModEntities(){
        // Default attributes through Architectury, so it works on both Fabric and Forge
        EntityAttributeRegistry.register(RED_ESSENCE_ZOMBIE, RedEssenceZombieEntity::setAttributes);
        EntityAttributeRegistry.register(GENETICALLY_MODIFIED_RED_ESSENCE_ZOMBIE, GeneticallyModifiedRedEssenceZombieEntity::setAttributes);
        EntityAttributeRegistry.register(DARK_ESSENCE_ZOMBIE, DarkEssenceZombieEntity::setAttributes);
        EntityAttributeRegistry.register(LOST_MINER, LostMinerEntity::setAttributes);
    }
}


