package net.stickmanm.axontechnologies.entity.client;

import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.entity.custom.LostMinerEntity;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

public class LostMinerModel extends GeoModel<LostMinerEntity> {
    @Override
    public class_2960 getModelResource(LostMinerEntity animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID,"geo/lost_miner.geo.json");
    }

    @Override
    public class_2960 getTextureResource(LostMinerEntity animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID,"textures/entity/lost_miner.png");    }

    @Override
    public class_2960 getAnimationResource(LostMinerEntity animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID,"animations/lost_miner.animation.json");
    }
    @Override
    public void setCustomAnimations(LostMinerEntity animatable, long instanceId, AnimationState<LostMinerEntity> animationState) {
        CoreGeoBone head = getAnimationProcessor().getBone("head");

        if (head != null) {
            EntityModelData entityData = animationState.getData(DataTickets.ENTITY_MODEL_DATA);
            head.setRotX(entityData.headPitch() * class_3532.field_29847);
            head.setRotY(entityData.netHeadYaw() * class_3532.field_29847);
        }
    }
}
