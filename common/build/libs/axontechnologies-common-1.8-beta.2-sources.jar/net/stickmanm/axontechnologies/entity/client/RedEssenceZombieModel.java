package net.stickmanm.axontechnologies.entity.client;

import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.entity.custom.RedEssenceZombieEntity;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

public class RedEssenceZombieModel extends GeoModel<RedEssenceZombieEntity> {
    @Override
    public class_2960 getModelResource(RedEssenceZombieEntity animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID,"geo/red_essence_zombie.geo.json");
    }

    @Override
    public class_2960 getTextureResource(RedEssenceZombieEntity animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID,"textures/entity/red_essence_zombie.png");    }

    @Override
    public class_2960 getAnimationResource(RedEssenceZombieEntity animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID,"animations/red_essence_zombie.animation.json");
    }
    @Override
    public void setCustomAnimations(RedEssenceZombieEntity animatable, long instanceId, AnimationState<RedEssenceZombieEntity> animationState) {
        CoreGeoBone head = getAnimationProcessor().getBone("head");

        if (head != null) {
            EntityModelData entityData = animationState.getData(DataTickets.ENTITY_MODEL_DATA);
            head.setRotX(entityData.headPitch() * class_3532.field_29847);
            head.setRotY(entityData.netHeadYaw() * class_3532.field_29847);
        }
    }
}
