package net.stickmanm.axontechnologies.entity.client;

import net.minecraft.class_1059;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.minecraft.class_957;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.entity.custom.AxonAlloyTntEntity;
import net.stickmanm.axontechnologies.entity.custom.RedThunderaniumTntEntity;

public class AxonAlloyTntEntityRenderer extends class_897<AxonAlloyTntEntity> {

    private final class_776 blockRenderManager;
    // You don't need the BlockRenderManager field,
    // as the method we call is static.

    public AxonAlloyTntEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.field_4673 = 0.5F;
        this.blockRenderManager = context.method_43337();
    }

    /**
     * We override the entire render method to change the block state.
     * This code is copied from the vanilla TntEntityRenderer.
     */
    @Override
    public void render(AxonAlloyTntEntity myTntEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i) {
        matrixStack.method_22903();
        matrixStack.method_46416(0.0F, 0.5F, 0.0F);

        // This code handles the bobbing up and down as the fuse ticks down
        int j = myTntEntity.method_6969();
        if ((float)j - g + 1.0F < 10.0F) {
            float h = 1.0F - ((float)j - g + 1.0F) / 10.0F;
            h = class_3532.method_15363(h, 0.0F, 1.0F);
            h *= h;
            h *= h;
            float k = 1.0F + h * 0.3F;
            matrixStack.method_22905(k, k, k);
        }

        // This code handles the white flashing overlay
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(-90.0F));
        matrixStack.method_46416(-0.5F, -0.5F, 0.5F);
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(90.0F));

        //
        // *** THIS IS THE KEY CHANGE ***
        //
        // We call the static method 'renderFlashingBlock' (found in TntMinecartEntityRenderer)
        // and pass in OUR custom block's default state instead of Blocks.TNT.
        class_957.method_23190(this.blockRenderManager, ModBlocks.AXON_ALLOY_TNT.get().method_9564(), matrixStack, vertexConsumerProvider, i, j / 5 % 2 == 0);

        matrixStack.method_22909();
        super.method_3936(myTntEntity, f, g, matrixStack, vertexConsumerProvider, i);
    }

    /**
     * Returns the texture sheet. For blocks, this is always the block atlas.
     */
    @Override
    public class_2960 getTexture(AxonAlloyTntEntity myTntEntity) {
        return class_1059.field_5275;
    }
}
