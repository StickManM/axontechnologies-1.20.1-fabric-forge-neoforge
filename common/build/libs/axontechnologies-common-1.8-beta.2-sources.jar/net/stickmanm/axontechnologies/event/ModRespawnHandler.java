package net.stickmanm.axontechnologies.event;

import com.google.common.collect.Maps;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.EntityEvent;
import dev.architectury.event.events.common.PlayerEvent;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import net.stickmanm.axontechnologies.world.dimension.ModDimensions;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class ModRespawnHandler {

    private static  final Set<class_5321<class_1937>> RESPAWN_IN_PLACE = Set.of(
            ModDimensions.MIMDIM_DIMENSION_KEY,
            ModDimensions.DCDIM_DIMENSION_KEY,
            ModDimensions.THUNDERLANDS_DIMENSION_KEY,
            ModDimensions.CORRUPTIONLANDS_DIMENSION_KEY
    );

    private static final Map<UUID, class_5321<class_1937>> DEATH_DIMENSION = new HashMap<>();

    public static void register() {
        EntityEvent.LIVING_DEATH.register(((entity, source) -> {
            if (entity instanceof class_3222 player) {
                class_5321<class_1937> dim = player.method_51469().method_27983();
                if (RESPAWN_IN_PLACE.contains(dim)) {
                    DEATH_DIMENSION.put(player.method_5667(), dim);
                }
            }
            return EventResult.pass();
        }));

        PlayerEvent.PLAYER_RESPAWN.register((player, conqueredEnd) -> {
            class_5321<class_1937> dim = DEATH_DIMENSION.remove(player.method_5667());
            if (dim == null) return;

            if (player.method_51469().method_27983().equals(dim)) return;

            MinecraftServer server = player.method_5682();
            if (server == null) return;
            class_3218 target = server.method_3847(dim);
            if (target == null) return;

            // Respawn point
            class_2338 pos = target.method_43126();
            int x = pos.method_10263();
            int z = pos.method_10260();
            int y = target.method_8624(class_2902.class_2903.field_13203, x, z);
            if (y <= target.method_31607()) {
                y = target.method_8615() + 1; // no ground found; fall back
            }

            player.method_14251(target, x + 0.5, y, z + 0.5, player.method_36454(), player.method_36455());
        });
    }
}
