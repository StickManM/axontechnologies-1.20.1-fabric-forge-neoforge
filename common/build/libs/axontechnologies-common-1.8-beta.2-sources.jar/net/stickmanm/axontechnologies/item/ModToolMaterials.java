package net.stickmanm.axontechnologies.item;

import java.util.function.Supplier;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_3528;

public enum ModToolMaterials implements class_1832 {
    THUNDERANIUM(5, 3031, 13.0f, 10.0f, 25, () -> class_1856.method_8091(ModItems.THUNDERANIUM_INGOT.get())),
    RED_THUNDERANIUM(6, 0, 20.0f, 12.5f, 35, () -> class_1856.method_8091(ModItems.RED_THUNDERANIUM_INGOT.get())),
    DARK_THUNDERANIUM(7, 0, 30.0f, 13.9f, 55, () -> class_1856.method_8091(ModItems.DARK_THUNDERANIUM_INGOT.get())),
    CORRUPTINITE(7, 0, 25.0f, 13.25f, 50, () -> class_1856.method_8091(ModItems.CORRUPTINITE.get())),
    CORRUPTINITE_AXON_ALLOY(10, 0, 45.0f, 22.5f, 100, () -> class_1856.method_8091(ModItems.CORRUPTINITE.get())),
    DARK_THUNDERANIUM_AXON_ALLOY(10, 0, 50.0f, 25.0f, 115, () -> class_1856.method_8091(ModItems.DARK_THUNDERANIUM_INGOT.get())),
    AXON_ALLOY(10, 0, 40.0f, 21.5f, 90, () -> class_1856.method_8091(ModItems.AXON_ALLOY.get())),

    RAZZORIUM(Integer.MAX_VALUE, 0, Float.MAX_VALUE, 14, Integer.MAX_VALUE, () -> class_1856.method_8091(ModItems.RAZZORIUM.get()));

    private final int miningLevel;
    private final int itemDurability;
    private final float miningSpeed;
    private final float attackDamage;
    private final int enchantability;
    private final class_3528<class_1856> repairIngredient;

    private ModToolMaterials(int miningLevel, int itemDurability, float miningSpeed, float attackDamage, int enchantability, Supplier<class_1856> repairIngredient) {
        this.miningLevel = miningLevel;
        this.itemDurability = itemDurability;
        this.miningSpeed = miningSpeed;
        this.attackDamage = attackDamage;
        this.enchantability = enchantability;
        this.repairIngredient = new class_3528<class_1856>(repairIngredient);
    }

    @Override
    public int method_8025() {
        return this.itemDurability;
    }

    @Override
    public float method_8027() {
        return this.miningSpeed;
    }

    @Override
    public float method_8028() {
        return this.attackDamage;
    }

    @Override
    public int method_8024() {
        return this.miningLevel;
    }

    @Override
    public int method_8026() {
        return this.enchantability;
    }

    @Override
    public class_1856 method_8023() {
        return this.repairIngredient.method_15332();
    }
}
