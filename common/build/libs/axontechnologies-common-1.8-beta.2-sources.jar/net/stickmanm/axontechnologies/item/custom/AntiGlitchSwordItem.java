package net.stickmanm.axontechnologies.item.custom;

import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.stickmanm.axontechnologies.effect.ModEffects;

public class AntiGlitchSwordItem extends class_1829 {
    public AntiGlitchSwordItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }

    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {

        if (target.method_6059(ModEffects.GLITCHSTER.get()) ||
                target.method_6059(ModEffects.GLITCHSTERII.get())||
                target.method_6059(ModEffects.GLITCHSTERIII.get())||
                target.method_6059(ModEffects.GLITCHSTERIV.get()) ||
                target.method_6059(ModEffects.GLITCHSTERV.get())) {
            target.method_6092(new class_1293(ModEffects.ANTIGLITCHSTER.get(), 900, 0));
        } else if (target.method_6059(ModEffects.CORRUPTED_GLITCHSTER.get()) ||
                target.method_6059(ModEffects.CORRUPTED_GLITCHSTERII.get()) ||
                target.method_6059(ModEffects.CORRUPTED_GLITCHSTERIII.get())) {
            target.method_6092(new class_1293(ModEffects.ANTI_CORRUPTED_GLITCHSTER.get(), 900, 0));
        }



        return true;
    }



}
