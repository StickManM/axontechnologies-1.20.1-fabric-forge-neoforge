package net.stickmanm.axontechnologies.item.client;

import net.minecraft.class_2960;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.item.custom.CorruptiniteArmorItem;
import software.bernie.geckolib.model.GeoModel;

public class CorruptiniteArmorModel extends GeoModel<CorruptiniteArmorItem>{
    @Override
    public class_2960 getModelResource(CorruptiniteArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "geo/thunderanium_armor.geo.json");
    }

    @Override
    public class_2960 getTextureResource(CorruptiniteArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "textures/armor/corruptinite_armor.png");
    }

    @Override
    public class_2960 getAnimationResource(CorruptiniteArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "animations/armor_test.animation.json");
    }
}
