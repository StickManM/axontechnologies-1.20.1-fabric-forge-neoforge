package net.stickmanm.axontechnologies.item.custom;

import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.stickmanm.axontechnologies.effect.ModEffects;

public class CorruptiniteSwordItem extends class_1829 {
    public CorruptiniteSwordItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }

    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {

        if(attacker.method_6059(ModEffects.CORRUPTED_GLITCHSTER.get())) {
            target.method_6092(new class_1293(ModEffects.ANTIGLITCHSTER.get(), 1200));


        }
        else if (attacker.method_6059(ModEffects.GLITCHSTER.get()) ||
                attacker.method_6059(ModEffects.GLITCHSTERII.get())||
                attacker.method_6059(ModEffects.GLITCHSTERIII.get())||
                attacker.method_6059(ModEffects.GLITCHSTERIV.get()) ||
                attacker.method_6059(ModEffects.GLITCHSTERV.get())) {
            attacker.method_6092(new class_1293(ModEffects.ANTIGLITCHSTER.get(), 900, 2));
        }

        return true;
    }

    @Override
    public boolean method_7870(class_1799 stack) {
        return super.method_7870(stack);
    }


}
