package net.stickmanm.axontechnologies.item.custom;

import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.stickmanm.axontechnologies.effect.ModEffects;

public class AxonAlloySwordItem extends class_1829 {
    public AxonAlloySwordItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }

    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {

        if (target.method_6059(ModEffects.GLITCHSTERV.get())) {
            target.method_6092(new class_1293(ModEffects.ANTIGLITCHSTER.get(), 1200, 2));
        } else if (target.method_6059(ModEffects.CORRUPTED_GLITCHSTERIII.get())) {
            target.method_6092(new class_1293(ModEffects.ANTI_CORRUPTED_GLITCHSTER.get(), 1200, 2));
        }



        return true;
    }



}
