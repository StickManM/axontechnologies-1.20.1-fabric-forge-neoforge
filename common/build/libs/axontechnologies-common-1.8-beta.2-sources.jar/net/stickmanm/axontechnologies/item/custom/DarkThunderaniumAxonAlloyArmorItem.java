package net.stickmanm.axontechnologies.item.custom;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_572;
import net.stickmanm.axontechnologies.effect.ModEffects;
import net.stickmanm.axontechnologies.item.ModItems;
import net.stickmanm.axontechnologies.item.client.DarkThunderaniumArmorRenderer;
import net.stickmanm.axontechnologies.item.client.DarkThunderaniumAxonAlloyArmorRenderer;
import net.stickmanm.axontechnologies.item.client.ArmorClientHooks;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.RenderProvider;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animatable.instance.SingletonAnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class DarkThunderaniumAxonAlloyArmorItem extends class_1738 implements GeoItem {

    private final AnimatableInstanceCache cache = new SingletonAnimatableInstanceCache(this);
    // Fabric GeckoLib only (GeoItem.makeRenderer does not exist in the Forge build of GeckoLib)
    private Object renderProvider;


    public DarkThunderaniumAxonAlloyArmorItem(class_1741 material, class_8051 type, class_1793 settings) {
        super(material, type, settings);
    }
    /**
     * Forge hook. Same erasure as Forge's Item#initializeClient(Consumer<IClientItemExtensions>), so Forge calls it on the client;
     * on Fabric nothing ever calls it. The Forge-only object is built in the forge module.
     */
    public void initializeClient(Consumer<Object> consumer) {
        Object extensions = ArmorClientHooks.createClientExtensions(() -> new DarkThunderaniumAxonAlloyArmorRenderer());
        if (extensions != null)
            consumer.accept(extensions);
    }

    @Override
    public void createRenderer(Consumer<Object> consumer) {
        consumer.accept(new RenderProvider() {
            private DarkThunderaniumAxonAlloyArmorRenderer renderer;


            @Override
            public class_572<class_1309> getHumanoidArmorModel(class_1309 livingEntity, class_1799 itemStack,
                                                                        class_1304 equipmentSlot, class_572<class_1309> original) {
                if (this.renderer == null)
                    this.renderer = new DarkThunderaniumAxonAlloyArmorRenderer();


                this.renderer.prepForRender(livingEntity, itemStack, equipmentSlot, original);


                return this.renderer;
            }
        });

    }

    @Override
    public Supplier<Object> getRenderProvider() {
        return () -> {
            if (this.renderProvider == null)
                createRenderer(provider -> this.renderProvider = provider);
            return this.renderProvider;
        };
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController(this, "controller", 0, this::predicate));
    }
    private PlayState predicate(AnimationState animationState) {
        animationState.getController().setAnimation(RawAnimation.begin().then("idle", Animation.LoopType.LOOP));
        return PlayState.CONTINUE;
    }


    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {


        if(!world.method_8608()) {
            if(entity instanceof class_1657 player) {
                class_1799 headPiece = player.method_6118(class_1304.field_6169);
                class_1799 chestPiece = player.method_6118(class_1304.field_6174);
                class_1799 legPiece = player.method_6118(class_1304.field_6172);
                class_1799 footPiece = player.method_6118(class_1304.field_6166);




                if (headPiece.method_31574(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HELMET.get()) &&
                        chestPiece.method_31574(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_CHESTPLATE.get()) &&
                        legPiece.method_31574(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_LEGGINGS.get()) &&
                        footPiece.method_31574(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_BOOTS.get())) {

                    if(player.method_6059(ModEffects.ANTIGLITCHSTER.get())) {
                        player.method_6016(ModEffects.GLITCHSTERV.get());
                        player.method_6092(new class_1293(class_1294.field_5907, 200, 3, false, false, true));
                        player.method_6092(new class_1293(ModEffects.NEUTRALIZED_GLITCHSTER.get(), 200, 2, false, false, true));
                        player.method_6092(new class_1293(class_1294.field_5905, 10, 1, false, false, false));
                    }
                    else if(player.method_6059(ModEffects.GLITCHSTERX.get())) {
                        player.method_6016(ModEffects.GLITCHSTERV.get());
                    }
                    else {
                        player.method_6092(new class_1293(ModEffects.GLITCHSTERV.get(), 200, 0, false, false, true));
                        player.method_6092(new class_1293(class_1294.field_5907, 200, 3, false, false, true));

                    }

                  }
                }




    }

        super.method_7888(stack, world, entity, slot, selected);
    }




}
