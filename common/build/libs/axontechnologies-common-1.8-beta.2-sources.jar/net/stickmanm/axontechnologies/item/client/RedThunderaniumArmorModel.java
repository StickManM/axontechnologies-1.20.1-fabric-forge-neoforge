package net.stickmanm.axontechnologies.item.client;

import net.minecraft.class_2960;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.item.custom.RedThunderaniumArmorItem;
import software.bernie.geckolib.model.GeoModel;

public class RedThunderaniumArmorModel extends GeoModel<RedThunderaniumArmorItem>{
    @Override
    public class_2960 getModelResource(RedThunderaniumArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "geo/thunderanium_armor.geo.json");
    }

    @Override
    public class_2960 getTextureResource(RedThunderaniumArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "textures/armor/red_thunderanium_armor.png");
    }

    @Override
    public class_2960 getAnimationResource(RedThunderaniumArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "animations/armor_test.animation.json");
    }
}
