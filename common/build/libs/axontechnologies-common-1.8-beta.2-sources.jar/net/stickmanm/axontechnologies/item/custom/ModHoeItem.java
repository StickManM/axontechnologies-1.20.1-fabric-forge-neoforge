package net.stickmanm.axontechnologies.item.custom;

import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1832;

public class ModHoeItem extends class_1794 {
    public ModHoeItem(class_1832 material, int attackDamage, float attackSpeed, class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }
    @Override
    public boolean method_7870(class_1799 stack) {
        return super.method_7870(stack);
    }
}
