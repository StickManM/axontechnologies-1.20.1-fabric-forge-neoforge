package net.stickmanm.axontechnologies.item;

import dev.architectury.core.item.ArchitecturyBucketItem;
import dev.architectury.core.item.ArchitecturySpawnEggItem;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1802;
import net.minecraft.class_1821;
import net.minecraft.class_1834;
import net.minecraft.class_7924;
import net.minecraft.item.*;
import net.stickmanm.axontechnologies.AxonTechnologies;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
//import net.stickmanm.fabric.AxonTechnologiesFabric;
import net.stickmanm.axontechnologies.entity.ModEntities;
import net.stickmanm.axontechnologies.fluid.ModFluids;
import net.stickmanm.axontechnologies.item.custom.*;

import java.util.function.Supplier;

public class ModItems {

    public static final DeferredRegister<class_1792> ITEMS =
            DeferredRegister.create(AxonTechnologiesConstants.MOD_ID, class_7924.field_41197);

    //MATERIALS
    public static final RegistrySupplier<class_1792> MIMICARIUM = registerItem("mimicarium",
            () -> new class_1792(new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> RAW_NETHERITE = registerItem("raw_netherite",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> RENDERIUM = registerItem("renderium",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> DENDERIUM = registerItem("denderium",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> RAW_THUNDERANIUM = registerItem("raw_thunderanium",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> THUNDERANIUM_CLUSTER = registerItem("thunderanium_cluster",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> REFINED_THUNDERANIUM = registerItem("refined_thunderanium",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> THUNDERANIUM_INGOT = registerItem("thunderanium_ingot",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> RED_ESSENCE = registerItem("red_essence",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_INGOT = registerItem("red_thunderanium_ingot",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> AXON_ALLOY = registerItem("axon_alloy",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_CLUSTER = registerItem("red_thunderanium_cluster",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> DARK_ESSENCE = registerItem("dark_essence",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_INGOT = registerItem("dark_thunderanium_ingot",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_CLUSTER = registerItem("dark_thunderanium_cluster",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> CORRUPTINITE = registerItem("corruptinite",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> UNSTABLE_CORRUPTINITE = registerItem("unstable_corruptinite",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> RAZZORIUM = registerItem("razzorium",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    //Fuels
    public static final RegistrySupplier<class_1792> THUNDER_FUEL = registerItem("thunder_fuel",
            () -> new class_1792(new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> VOID_COAL = registerItem("void_coal",
            () -> new class_1792(new class_1792.class_1793()));

    //Compressed Sticks
    public static final RegistrySupplier<class_1792> COMPRESSED_STICK = registerItem("compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> DOUBLE_COMPRESSED_STICK = registerItem("double_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> TRIPLE_COMPRESSED_STICK = registerItem("triple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> QUADRUPLE_COMPRESSED_STICK = registerItem("quadruple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> QUINTUPLE_COMPRESSED_STICK = registerItem("quintuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> SEXTUPLE_COMPRESSED_STICK = registerItem("sextuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> SEPTUPLE_COMPRESSED_STICK = registerItem("septuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> OCTUPLE_COMPRESSED_STICK = registerItem("octuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> NONUPLE_COMPRESSED_STICK = registerItem("nonuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> DECUPLE_COMPRESSED_STICK = registerItem("decuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> UNDECUPLE_COMPRESSED_STICK = registerItem("undecuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> DUODECUPLE_COMPRESSED_STICK = registerItem("duodecuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> TREDECUPLE_COMPRESSED_STICK = registerItem("tredecuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> QUATTUORDECUPLE_COMPRESSED_STICK = registerItem("quattuordecuple_compressed_stick",
            () -> new CompressedStickItem(new class_1792.class_1793().method_24359()));


    //DIMENSION CORES
    public static final RegistrySupplier<class_1792> MWDC = registerItem("mimic_world_dimension_core",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> DCDC = registerItem("dread_caverns_dimension_core",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> TLDC = registerItem("thunderlands_dimension_core",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> CLDC = registerItem("corruptionlands_dimension_core",
            () -> new class_1792(new class_1792.class_1793().method_24359()));



    //SPAWN EGGS
    public static final RegistrySupplier<class_1792> RED_ESSENCE_ZOMBIE_SPAWN_EGG = registerItem("red_essence_zombie_spawn_egg",
            () -> new ArchitecturySpawnEggItem(ModEntities.RED_ESSENCE_ZOMBIE, 0xFF0000, 0x000000,
                    new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> GENETICALLY_MODIFIED_RED_ESSENCE_ZOMBIE_SPAWN_EGG = registerItem("genetically_modified_red_essence_zombie_spawn_egg",
            () -> new ArchitecturySpawnEggItem(ModEntities.GENETICALLY_MODIFIED_RED_ESSENCE_ZOMBIE, 0xFF0000, 0x00FF00,
                    new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> DARK_ESSENCE_ZOMBIE_SPAWN_EGG = registerItem("dark_essence_zombie_spawn_egg",
            () -> new ArchitecturySpawnEggItem(ModEntities.DARK_ESSENCE_ZOMBIE, 0x301934, 0x000000,
                    new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> LOST_MINER_SPAWN_EGG = registerItem("lost_miner_spawn_egg",
            () -> new ArchitecturySpawnEggItem(ModEntities.LOST_MINER, 0x301934, 0xFFD700,
                    new class_1792.class_1793()));

    //Lighters
    public static final RegistrySupplier<class_1792> MIMICARIUM_IGNITER = registerItem("mimicarium_igniter",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> DREADED_IGNITER = registerItem("dreaded_igniter",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> THUNDERANIUM_KEY = registerItem("thunderanium_key",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> CORRUPTION_GATEWAY = registerItem("corruption_gateway",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> UNIVERSAL_IGNITER = registerItem("universal_igniter",
            () -> new class_1792(new class_1792.class_1793().method_24359()));

    //Armors

    //Thunderanium
    public static final RegistrySupplier<class_1792> THUNDERANIUM_HELMET = registerItem("thunderanium_helmet",
            () -> new ThunderaniumArmorItem(ModArmorMaterials.THUNDERANIUM, class_1738.class_8051.field_41934, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> THUNDERANIUM_CHESTPLATE = registerItem("thunderanium_chestplate",
            () -> new ThunderaniumArmorItem(ModArmorMaterials.THUNDERANIUM, class_1738.class_8051.field_41935, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> THUNDERANIUM_LEGGINGS = registerItem("thunderanium_leggings",
            () -> new ThunderaniumArmorItem(ModArmorMaterials.THUNDERANIUM, class_1738.class_8051.field_41936, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> THUNDERANIUM_BOOTS = registerItem("thunderanium_boots",
            () -> new ThunderaniumArmorItem(ModArmorMaterials.THUNDERANIUM, class_1738.class_8051.field_41937, new class_1792.class_1793().method_24359()));

    //Red Thunderanium
    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_HELMET = registerItem("red_thunderanium_helmet",
            () -> new RedThunderaniumArmorItem(ModArmorMaterials.RED_THUNDERANIUM, class_1738.class_8051.field_41934, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_CHESTPLATE = registerItem("red_thunderanium_chestplate",
            () -> new RedThunderaniumArmorItem(ModArmorMaterials.RED_THUNDERANIUM, class_1738.class_8051.field_41935, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_LEGGINGS = registerItem("red_thunderanium_leggings",
            () -> new RedThunderaniumArmorItem(ModArmorMaterials.RED_THUNDERANIUM, class_1738.class_8051.field_41936, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_BOOTS = registerItem("red_thunderanium_boots",
            () -> new RedThunderaniumArmorItem(ModArmorMaterials.RED_THUNDERANIUM, class_1738.class_8051.field_41937, new class_1792.class_1793().method_24359()));

    //Dark Thunderanium
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_HELMET = registerItem("dark_thunderanium_helmet",
            () -> new DarkThunderaniumArmorItem(ModArmorMaterials.DARK_THUNDERANIUM, class_1738.class_8051.field_41934, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_CHESTPLATE = registerItem("dark_thunderanium_chestplate",
            () -> new DarkThunderaniumArmorItem(ModArmorMaterials.DARK_THUNDERANIUM, class_1738.class_8051.field_41935, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_LEGGINGS = registerItem("dark_thunderanium_leggings",
            () -> new DarkThunderaniumArmorItem(ModArmorMaterials.DARK_THUNDERANIUM, class_1738.class_8051.field_41936, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_BOOTS = registerItem("dark_thunderanium_boots",
            () -> new DarkThunderaniumArmorItem(ModArmorMaterials.DARK_THUNDERANIUM, class_1738.class_8051.field_41937, new class_1792.class_1793().method_24359()));

    //Corruptinite
    public static final RegistrySupplier<class_1792> CORRUPTINITE_HELMET = registerItem("corruptinite_helmet",
            () -> new CorruptiniteArmorItem(ModArmorMaterials.CORRUPTINITE, class_1738.class_8051.field_41934, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_CHESTPLATE = registerItem("corruptinite_chestplate",
            () -> new CorruptiniteArmorItem(ModArmorMaterials.CORRUPTINITE, class_1738.class_8051.field_41935, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_LEGGINGS = registerItem("corruptinite_leggings",
            () -> new CorruptiniteArmorItem(ModArmorMaterials.CORRUPTINITE, class_1738.class_8051.field_41936, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_BOOTS = registerItem("corruptinite_boots",
            () -> new CorruptiniteArmorItem(ModArmorMaterials.CORRUPTINITE, class_1738.class_8051.field_41937, new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXON_ALLOY_HELMET = registerItem("corruptinite_axon_alloy_helmet",
            () -> new CorruptiniteAxonAlloyArmorItem(ModArmorMaterials.CORRUPTINITE_AXON_ALLOY_ARMOR, class_1738.class_8051.field_41934, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXON_ALLOY_CHESTPLATE = registerItem("corruptinite_axon_alloy_chestplate",
            () -> new CorruptiniteAxonAlloyArmorItem(ModArmorMaterials.CORRUPTINITE_AXON_ALLOY_ARMOR, class_1738.class_8051.field_41935, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXON_ALLOY_LEGGINGS = registerItem("corruptinite_axon_alloy_leggings",
            () -> new CorruptiniteAxonAlloyArmorItem(ModArmorMaterials.CORRUPTINITE_AXON_ALLOY_ARMOR, class_1738.class_8051.field_41936, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXON_ALLOY_BOOTS = registerItem("corruptinite_axon_alloy_boots",
            () -> new CorruptiniteAxonAlloyArmorItem(ModArmorMaterials.CORRUPTINITE_AXON_ALLOY_ARMOR, class_1738.class_8051.field_41937, new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXON_ALLOY_HELMET = registerItem("dark_thunderanium_axon_alloy_helmet",
            () -> new DarkThunderaniumAxonAlloyArmorItem(ModArmorMaterials.DARK_THUNDERANIUM_AXON_ALLOY_ARMOR, class_1738.class_8051.field_41934, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXON_ALLOY_CHESTPLATE = registerItem("dark_thunderanium_axon_alloy_chestplate",
            () -> new DarkThunderaniumAxonAlloyArmorItem(ModArmorMaterials.DARK_THUNDERANIUM_AXON_ALLOY_ARMOR, class_1738.class_8051.field_41935, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXON_ALLOY_LEGGINGS = registerItem("dark_thunderanium_axon_alloy_leggings",
            () -> new DarkThunderaniumAxonAlloyArmorItem(ModArmorMaterials.DARK_THUNDERANIUM_AXON_ALLOY_ARMOR, class_1738.class_8051.field_41936, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXON_ALLOY_BOOTS = registerItem("dark_thunderanium_axon_alloy_boots",
            () -> new DarkThunderaniumAxonAlloyArmorItem(ModArmorMaterials.DARK_THUNDERANIUM_AXON_ALLOY_ARMOR, class_1738.class_8051.field_41937, new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> AXON_ALLOY_HELMET = registerItem("axon_alloy_helmet",
            () -> new AxonAlloyArmorItem(ModArmorMaterials.AXON_ALLOY_ARMOR, class_1738.class_8051.field_41934, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> AXON_ALLOY_CHESTPLATE = registerItem("axon_alloy_chestplate",
            () -> new AxonAlloyArmorItem(ModArmorMaterials.AXON_ALLOY_ARMOR, class_1738.class_8051.field_41935, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> AXON_ALLOY_LEGGINGS = registerItem("axon_alloy_leggings",
            () -> new AxonAlloyArmorItem(ModArmorMaterials.AXON_ALLOY_ARMOR, class_1738.class_8051.field_41936, new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> AXON_ALLOY_BOOTS = registerItem("axon_alloy_boots",
            () -> new AxonAlloyArmorItem(ModArmorMaterials.AXON_ALLOY_ARMOR, class_1738.class_8051.field_41937, new class_1792.class_1793().method_24359()));

    //TOOLS

    //MISC TOOLS
    public static final RegistrySupplier<class_1792> ANTIGLITCH_SWORD = registerItem("antiglitch_sword",
            () -> new AntiGlitchSwordItem(ModToolMaterials.RED_THUNDERANIUM, 4, -2.5f,
                    new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> VANILLA_HOE = registerItem("vanilla_hoe",
            () -> new class_1794(class_1834.field_22033, 2, 1f,
                    new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> ULTIMATE_HOE_TROPHY = registerItem("ultimate_hoe_trophy",
            () -> new ModHoeItem(ModToolMaterials.DARK_THUNDERANIUM, 0, -3f,
                    new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> RAZZOR = registerItem("razzor",
            () -> new RazzorSwordItem(ModToolMaterials.RAZZORIUM, Integer.MAX_VALUE, Float.MAX_VALUE,
                    new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> RAZZORIUM_MINER = registerItem("razzorium_miner",
            () -> new ModMultiTool(ModToolMaterials.RAZZORIUM, 10, 10f,
                    new class_1792.class_1793()));

    public static final RegistrySupplier<class_1792> TICKLE_TRAVIS_TICKLER = registerItem("tickle_travis_tickler",
            () -> new RazzorSwordItem(ModToolMaterials.RAZZORIUM, Integer.MAX_VALUE, Float.MAX_VALUE,
                    new class_1792.class_1793()));


    //Thunderanium
    public static final RegistrySupplier<class_1792> THUNDERANIUM_SWORD = registerItem("thunderanium_sword",
            () -> new ModSwordItem(ModToolMaterials.THUNDERANIUM, 5, -2f,
                    new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> THUNDERANIUM_AXE = registerItem("thunderanium_axe",
            () -> new ModAxeItem(ModToolMaterials.THUNDERANIUM, 8, -3.9f,
                    new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> THUNDERANIUM_HOE = registerItem("thunderanium_hoe",
            () -> new ModHoeItem(ModToolMaterials.THUNDERANIUM, 3, -2.3f,
                    new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> THUNDERANIUM_SHOVEL = registerItem("thunderanium_shovel",
            () -> new class_1821(ModToolMaterials.THUNDERANIUM, 3, -2.5f,
                    new class_1792.class_1793().method_24359()));

    public static final RegistrySupplier<class_1792> THUNDERANIUM_PICKAXE = registerItem("thunderanium_pickaxe",
            () -> new ModPickaxeItem(ModToolMaterials.THUNDERANIUM, 3, -2.4f,
                    new class_1792.class_1793().method_24359()));

    //Red Thunderanium
    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_SWORD = registerItem("red_thunderanium_sword",
            () -> new ModSwordItem(ModToolMaterials.RED_THUNDERANIUM, 5, -2f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_AXE = registerItem("red_thunderanium_axe",
            () -> new ModAxeItem(ModToolMaterials.RED_THUNDERANIUM, 8, -3.9f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_HOE = registerItem("red_thunderanium_hoe",
            () -> new ModHoeItem(ModToolMaterials.RED_THUNDERANIUM, -1, -2.3f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_SHOVEL = registerItem("red_thunderanium_shovel",
            () -> new class_1821(ModToolMaterials.RED_THUNDERANIUM, 3, -2.5f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> RED_THUNDERANIUM_PICKAXE = registerItem("red_thunderanium_pickaxe",
            () -> new ModPickaxeItem(ModToolMaterials.RED_THUNDERANIUM, 3, -2.4f,
                    new class_1792.class_1793().method_24359()));

    //Dark Thunderanium
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_SWORD = registerItem("dark_thunderanium_sword",
            () -> new DarkThunderaniumSwordItem(ModToolMaterials.DARK_THUNDERANIUM, 5, -2f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXE = registerItem("dark_thunderanium_axe",
            () -> new ModAxeItem(ModToolMaterials.DARK_THUNDERANIUM, 8, -3.9f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_HOE = registerItem("dark_thunderanium_hoe",
            () -> new ModHoeItem(ModToolMaterials.DARK_THUNDERANIUM, -1, -2.3f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_SHOVEL = registerItem("dark_thunderanium_shovel",
            () -> new class_1821(ModToolMaterials.DARK_THUNDERANIUM, 3, -2.5f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_PICKAXE = registerItem("dark_thunderanium_pickaxe",
            () -> new ModPickaxeItem(ModToolMaterials.DARK_THUNDERANIUM, 3, -2.4f,
                    new class_1792.class_1793().method_24359()));

    //Corruptinite
    public static final RegistrySupplier<class_1792> CORRUPTINITE_SWORD = registerItem("corruptinite_sword",
            () -> new CorruptiniteSwordItem(ModToolMaterials.CORRUPTINITE, 5, -2f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXE = registerItem("corruptinite_axe",
            () -> new ModAxeItem(ModToolMaterials.CORRUPTINITE, 8, -3.9f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_HOE = registerItem("corruptinite_hoe",
            () -> new ModHoeItem(ModToolMaterials.CORRUPTINITE, -1, -2.3f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_SHOVEL = registerItem("corruptinite_shovel",
            () -> new class_1821(ModToolMaterials.CORRUPTINITE, 3, -2.5f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_PICKAXE = registerItem("corruptinite_pickaxe",
            () -> new ModPickaxeItem(ModToolMaterials.CORRUPTINITE, 3, -2.4f,
                    new class_1792.class_1793().method_24359()));

    //Axon Alloy G
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXON_ALLOY_SWORD = registerItem("dark_thunderanium_axon_alloy_sword",
            () -> new DarkThunderaniumSwordItem(ModToolMaterials.DARK_THUNDERANIUM_AXON_ALLOY, 6, -2f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXON_ALLOY_AXE = registerItem("dark_thunderanium_axon_alloy_axe",
            () -> new ModAxeItem(ModToolMaterials.DARK_THUNDERANIUM_AXON_ALLOY, 9, -3.9f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXON_ALLOY_HOE = registerItem("dark_thunderanium_axon_alloy_hoe",
            () -> new ModHoeItem(ModToolMaterials.DARK_THUNDERANIUM_AXON_ALLOY, -2, -2.3f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXON_ALLOY_SHOVEL = registerItem("dark_thunderanium_axon_alloy_shovel",
            () -> new class_1821(ModToolMaterials.DARK_THUNDERANIUM_AXON_ALLOY, 4, -2.5f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> DARK_THUNDERANIUM_AXON_ALLOY_PICKAXE = registerItem("dark_thunderanium_axon_alloy_pickaxe",
            () -> new ModPickaxeItem(ModToolMaterials.DARK_THUNDERANIUM_AXON_ALLOY, 4, -2.4f,
                    new class_1792.class_1793().method_24359()));

    //Axon Alloy C
    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXON_ALLOY_SWORD = registerItem("corruptinite_axon_alloy_sword",
            () -> new CorruptiniteSwordItem(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, 6, -2f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXON_ALLOY_AXE = registerItem("corruptinite_axon_alloy_axe",
            () -> new ModAxeItem(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, 9, -3.9f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXON_ALLOY_HOE = registerItem("corruptinite_axon_alloy_hoe",
            () -> new ModHoeItem(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, -2, -2.3f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXON_ALLOY_SHOVEL = registerItem("corruptinite_axon_alloy_shovel",
            () -> new class_1821(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, 4, -2.5f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> CORRUPTINITE_AXON_ALLOY_PICKAXE = registerItem("corruptinite_axon_alloy_pickaxe",
            () -> new ModPickaxeItem(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, 4, -2.4f,
                    new class_1792.class_1793().method_24359()));

    //Axon Alloy A
    public static final RegistrySupplier<class_1792> AXON_ALLOY_SWORD = registerItem("axon_alloy_sword",
            () -> new AxonAlloySwordItem(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, 6, -2f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> AXON_ALLOY_AXE = registerItem("axon_alloy_axe",
            () -> new ModAxeItem(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, 9, -3.9f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> AXON_ALLOY_HOE = registerItem("axon_alloy_hoe",
            () -> new ModHoeItem(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, -2, -2.3f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> AXON_ALLOY_SHOVEL = registerItem("axon_alloy_shovel",
            () -> new class_1821(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, 4, -2.5f,
                    new class_1792.class_1793().method_24359()));
    public static final RegistrySupplier<class_1792> AXON_ALLOY_PICKAXE = registerItem("axon_alloy_pickaxe",
            () -> new ModPickaxeItem(ModToolMaterials.CORRUPTINITE_AXON_ALLOY, 4, -2.4f,
                    new class_1792.class_1793().method_24359()));

    //BUCKETS
    public static final RegistrySupplier<class_1792> LIQUID_THUNDER_BUCKET = registerItem("liquid_thunder_bucket",
            () -> new ArchitecturyBucketItem(ModFluids.STILL_LIQUID_THUNDER, new class_1792.class_1793().method_7896(class_1802.field_8550).method_7889(1).method_24359()));

    public static final RegistrySupplier<class_1792> LIQUID_CORRUPTION_BUCKET = registerItem("liquid_corruption_bucket",
            () -> new ArchitecturyBucketItem(ModFluids.STILL_LIQUID_CORRUPTION, new class_1792.class_1793().method_7896(class_1802.field_8550).method_7889(1).method_24359()));

    public static final RegistrySupplier<class_1792> GX_BUCKET = registerItem("gx_bucket",
            () -> new ArchitecturyBucketItem(ModFluids.STILL_GX, new class_1792.class_1793().method_7896(class_1802.field_8550).method_7889(1).method_24359()));



    private static RegistrySupplier<class_1792> registerItem(String name, Supplier<class_1792> item){
        return ITEMS.register(name, item);
    }


    public static void registerModItems() {
        AxonTechnologies.LOGGER.info("Registering Mod Items for " + AxonTechnologiesConstants.MOD_ID);

    }
}
