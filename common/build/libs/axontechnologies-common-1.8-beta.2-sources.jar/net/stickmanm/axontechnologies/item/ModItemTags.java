package net.stickmanm.axontechnologies.item;

import net.stickmanm.axontechnologies.AxonTechnologiesConstants;

import static net.minecraft.class_3497.method_43937;
import static net.minecraft.class_3497.method_43945;

import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModItemTags {
    public static final class_6862<class_1792> THUNDERED_PLANKS_CONVERTIBLE = class_6862.method_40092(class_7924.field_41197, new class_2960(AxonTechnologiesConstants.MOD_ID, "thundered_planks_convertible"));
    public static final class_6862<class_1792> CORRUPTED_PLANKS_CONVERTIBLE = class_6862.method_40092(class_7924.field_41197, new class_2960(AxonTechnologiesConstants.MOD_ID, "corrupted_planks_convertible"));
}
