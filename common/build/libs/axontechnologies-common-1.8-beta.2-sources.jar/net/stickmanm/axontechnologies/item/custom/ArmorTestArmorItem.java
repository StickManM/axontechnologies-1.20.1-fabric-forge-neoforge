package net.stickmanm.axontechnologies.item.custom;

import net.stickmanm.axontechnologies.item.client.ArmorTestArmorRenderer;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_572;
import net.stickmanm.axontechnologies.item.client.ArmorClientHooks;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.RenderProvider;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animatable.instance.SingletonAnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class ArmorTestArmorItem extends class_1738 implements GeoItem {

    private final AnimatableInstanceCache cache = new SingletonAnimatableInstanceCache(this);
    // Fabric GeckoLib only (GeoItem.makeRenderer does not exist in the Forge build of GeckoLib)
    private Object renderProvider;


    public ArmorTestArmorItem(class_1741 material, class_8051 type, class_1793 settings) {
        super(material, type, settings);
    }
    /**
     * Forge hook. Same erasure as Forge's Item#initializeClient(Consumer<IClientItemExtensions>), so Forge calls it on the client;
     * on Fabric nothing ever calls it. The Forge-only object is built in the forge module.
     */
    public void initializeClient(Consumer<Object> consumer) {
        Object extensions = ArmorClientHooks.createClientExtensions(() -> new ArmorTestArmorRenderer());
        if (extensions != null)
            consumer.accept(extensions);
    }

    @Override
    public void createRenderer(Consumer<Object> consumer) {
        consumer.accept(new RenderProvider() {
            private ArmorTestArmorRenderer renderer;


            @Override
            public class_572<class_1309> getHumanoidArmorModel(class_1309 livingEntity, class_1799 itemStack,
                                                                        class_1304 equipmentSlot, class_572<class_1309> original) {
                if (this.renderer == null)
                    this.renderer = new ArmorTestArmorRenderer();


                this.renderer.prepForRender(livingEntity, itemStack, equipmentSlot, original);


                return this.renderer;
            }
        });

    }

    @Override
    public Supplier<Object> getRenderProvider() {
        return () -> {
            if (this.renderProvider == null)
                createRenderer(provider -> this.renderProvider = provider);
            return this.renderProvider;
        };
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController(this, "controller", 0, this::predicate));
    }
    private <T extends GeoAnimatable> PlayState predicate(AnimationState<T> tAnimationState) {
        if (tAnimationState.isMoving()){
            tAnimationState.getController().setAnimation(RawAnimation.begin().then("walking", Animation.LoopType.LOOP));
            return PlayState.CONTINUE;
        }

        tAnimationState.getController().setAnimation(RawAnimation.begin().then("idle", Animation.LoopType.LOOP));
        return PlayState.CONTINUE;
    }


    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        if(!world.method_8608()) {
            if(entity instanceof class_1657) {
                class_1657 player = (class_1657)entity;

            }
        }

        super.method_7888(stack, world, entity, slot, selected);
    }





    private void addStatusEffectForMaterial(class_1657 player, class_1741 mapArmorMaterial, class_1291 mapStatusEffect) {
        boolean hasPlayerEffect = player.method_6059(mapStatusEffect);

        if(hasCorrectArmorOn(mapArmorMaterial, player) && !hasPlayerEffect) {
            player.method_6092(new class_1293(mapStatusEffect, 200, 0, true, false,true));
        }
    }

    private boolean hasFullSuitOfArmorOn(class_1657 player) {
        class_1799 boots = player.method_31548().method_7372(0);
        class_1799 leggings = player.method_31548().method_7372(1);
        class_1799 breastplate = player.method_31548().method_7372(2);
        class_1799 helmet = player.method_31548().method_7372(3);

        return !helmet.method_7960() && !breastplate.method_7960()
                && !leggings.method_7960() && !boots.method_7960();
    }

    private boolean hasCorrectArmorOn(class_1741 material, class_1657 player) {
        class_1738 boots = ((class_1738)player.method_31548().method_7372(0).method_7909());
        class_1738 leggings = ((class_1738)player.method_31548().method_7372(1).method_7909());
        class_1738 breastplate = ((class_1738)player.method_31548().method_7372(2).method_7909());
        class_1738 helmet = ((class_1738)player.method_31548().method_7372(3).method_7909());

        return helmet.method_7686() == material && breastplate.method_7686() == material &&
                leggings.method_7686() == material && boots.method_7686() == material;
    }


}