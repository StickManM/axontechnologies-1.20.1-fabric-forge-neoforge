package net.stickmanm.axontechnologies.item.client;

import net.minecraft.class_2960;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.item.custom.CorruptiniteAxonAlloyArmorItem;
import software.bernie.geckolib.model.GeoModel;

public class CorruptiniteAxonAlloyArmorModel extends GeoModel<CorruptiniteAxonAlloyArmorItem>{
    @Override
    public class_2960 getModelResource(CorruptiniteAxonAlloyArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "geo/thunderanium_armor.geo.json");
    }

    @Override
    public class_2960 getTextureResource(CorruptiniteAxonAlloyArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "textures/armor/axon_alloy_armor.png");
    }

    @Override
    public class_2960 getAnimationResource(CorruptiniteAxonAlloyArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "animations/armor_test.animation.json");
    }
}
