package net.stickmanm.axontechnologies.item;

import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.block.ModBlocks;

public class ModItemGroup {
    public static final DeferredRegister<class_1761> TABS =
            DeferredRegister.create(AxonTechnologiesConstants.MOD_ID, class_7924.field_44688);

    // The tab is built lazily, so the .get() calls inside the entries lambda are safe (it only runs once
    // the creative inventory is populated, long after every registry has been filled).
    public static final RegistrySupplier<class_1761> AXONTECHNOLOGIES = TABS.register("axontechnologies",
            () -> CreativeTabRegistry.create(builder -> builder
                    .method_47321(class_2561.method_43471("itemGroup." + AxonTechnologiesConstants.MOD_ID))
                    .method_47320(() -> new class_1799(ModItems.RED_THUNDERANIUM_INGOT.get()))
                    .method_47317((context, entries) -> {
                        // ITEMS
                        entries.method_45421(ModItems.MIMICARIUM.get());
                        entries.method_45421(ModItems.RAW_NETHERITE.get());
                        entries.method_45421(ModItems.RED_ESSENCE.get());
                        entries.method_45421(ModItems.DARK_ESSENCE.get());
                        entries.method_45421(ModItems.RENDERIUM.get());
                        entries.method_45421(ModItems.DENDERIUM.get());
                        entries.method_45421(ModItems.AXON_ALLOY.get());

                        entries.method_45421(ModItems.VOID_COAL.get());
                        entries.method_45421(ModItems.THUNDER_FUEL.get());

                        entries.method_45421(ModItems.CORRUPTINITE.get());
                        entries.method_45421(ModItems.UNSTABLE_CORRUPTINITE.get());

                        entries.method_45421(ModItems.DARK_THUNDERANIUM_INGOT.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_CLUSTER.get());

                        entries.method_45421(ModItems.RAW_THUNDERANIUM.get());
                        entries.method_45421(ModItems.THUNDERANIUM_CLUSTER.get());
                        entries.method_45421(ModItems.REFINED_THUNDERANIUM.get());
                        entries.method_45421(ModItems.THUNDERANIUM_INGOT.get());

                        entries.method_45421(ModItems.RED_THUNDERANIUM_INGOT.get());
                        entries.method_45421(ModItems.RED_THUNDERANIUM_CLUSTER.get());

                        entries.method_45421(ModItems.RED_ESSENCE_ZOMBIE_SPAWN_EGG.get());
                        entries.method_45421(ModItems.GENETICALLY_MODIFIED_RED_ESSENCE_ZOMBIE_SPAWN_EGG.get());
                        entries.method_45421(ModItems.DARK_ESSENCE_ZOMBIE_SPAWN_EGG.get());
                        entries.method_45421(ModItems.LOST_MINER_SPAWN_EGG.get());

                        entries.method_45421(ModItems.MIMICARIUM_IGNITER.get());
                        entries.method_45421(ModItems.DREADED_IGNITER.get());
                        entries.method_45421(ModItems.THUNDERANIUM_KEY.get());
                        entries.method_45421(ModItems.CORRUPTION_GATEWAY.get());
                        entries.method_45421(ModItems.UNIVERSAL_IGNITER.get());

                        entries.method_45421(ModItems.THUNDERANIUM_HELMET.get());
                        entries.method_45421(ModItems.THUNDERANIUM_CHESTPLATE.get());
                        entries.method_45421(ModItems.THUNDERANIUM_LEGGINGS.get());
                        entries.method_45421(ModItems.THUNDERANIUM_BOOTS.get());

                        entries.method_45421(ModItems.THUNDERANIUM_SWORD.get());
                        entries.method_45421(ModItems.THUNDERANIUM_PICKAXE.get());
                        entries.method_45421(ModItems.THUNDERANIUM_AXE.get());
                        entries.method_45421(ModItems.THUNDERANIUM_SHOVEL.get());
                        entries.method_45421(ModItems.THUNDERANIUM_HOE.get());

                        entries.method_45421(ModItems.RED_THUNDERANIUM_HELMET.get());
                        entries.method_45421(ModItems.RED_THUNDERANIUM_CHESTPLATE.get());
                        entries.method_45421(ModItems.RED_THUNDERANIUM_LEGGINGS.get());
                        entries.method_45421(ModItems.RED_THUNDERANIUM_BOOTS.get());

                        entries.method_45421(ModItems.RED_THUNDERANIUM_SWORD.get());
                        entries.method_45421(ModItems.RED_THUNDERANIUM_PICKAXE.get());
                        entries.method_45421(ModItems.RED_THUNDERANIUM_AXE.get());
                        entries.method_45421(ModItems.RED_THUNDERANIUM_SHOVEL.get());
                        entries.method_45421(ModItems.RED_THUNDERANIUM_HOE.get());

                        entries.method_45421(ModItems.DARK_THUNDERANIUM_HELMET.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_CHESTPLATE.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_LEGGINGS.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_BOOTS.get());

                        entries.method_45421(ModItems.DARK_THUNDERANIUM_SWORD.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_PICKAXE.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXE.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_SHOVEL.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_HOE.get());

                        entries.method_45421(ModItems.CORRUPTINITE_HELMET.get());
                        entries.method_45421(ModItems.CORRUPTINITE_CHESTPLATE.get());
                        entries.method_45421(ModItems.CORRUPTINITE_LEGGINGS.get());
                        entries.method_45421(ModItems.CORRUPTINITE_BOOTS.get());

                        entries.method_45421(ModItems.CORRUPTINITE_SWORD.get());
                        entries.method_45421(ModItems.CORRUPTINITE_PICKAXE.get());
                        entries.method_45421(ModItems.CORRUPTINITE_AXE.get());
                        entries.method_45421(ModItems.CORRUPTINITE_SHOVEL.get());
                        entries.method_45421(ModItems.CORRUPTINITE_HOE.get());

                        entries.method_45421(ModItems.CORRUPTINITE_AXON_ALLOY_HELMET.get());
                        entries.method_45421(ModItems.CORRUPTINITE_AXON_ALLOY_CHESTPLATE.get());
                        entries.method_45421(ModItems.CORRUPTINITE_AXON_ALLOY_LEGGINGS.get());
                        entries.method_45421(ModItems.CORRUPTINITE_AXON_ALLOY_BOOTS.get());

                        entries.method_45421(ModItems.CORRUPTINITE_AXON_ALLOY_SWORD.get());
                        entries.method_45421(ModItems.CORRUPTINITE_AXON_ALLOY_PICKAXE.get());
                        entries.method_45421(ModItems.CORRUPTINITE_AXON_ALLOY_AXE.get());
                        entries.method_45421(ModItems.CORRUPTINITE_AXON_ALLOY_SHOVEL.get());
                        entries.method_45421(ModItems.CORRUPTINITE_AXON_ALLOY_HOE.get());

                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HELMET.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_CHESTPLATE.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_LEGGINGS.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_BOOTS.get());

                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SWORD.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_PICKAXE.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_AXE.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_SHOVEL.get());
                        entries.method_45421(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HOE.get());

                        entries.method_45421(ModItems.AXON_ALLOY_HELMET.get());
                        entries.method_45421(ModItems.AXON_ALLOY_CHESTPLATE.get());
                        entries.method_45421(ModItems.AXON_ALLOY_LEGGINGS.get());
                        entries.method_45421(ModItems.AXON_ALLOY_BOOTS.get());

                        entries.method_45421(ModItems.AXON_ALLOY_SWORD.get());
                        entries.method_45421(ModItems.AXON_ALLOY_PICKAXE.get());
                        entries.method_45421(ModItems.AXON_ALLOY_AXE.get());
                        entries.method_45421(ModItems.AXON_ALLOY_SHOVEL.get());
                        entries.method_45421(ModItems.AXON_ALLOY_HOE.get());

                        entries.method_45421(ModItems.ANTIGLITCH_SWORD.get());
                        entries.method_45421(ModItems.VANILLA_HOE.get());
                        entries.method_45421(ModItems.ULTIMATE_HOE_TROPHY.get());
                        entries.method_45421(ModItems.RAZZOR.get());
                        entries.method_45421(ModItems.RAZZORIUM_MINER.get());
                        entries.method_45421(ModItems.TICKLE_TRAVIS_TICKLER.get());

                        // COMPRESSED STICKS
                        entries.method_45421(ModItems.COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.DOUBLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.TRIPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.QUADRUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.QUINTUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.SEXTUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.SEPTUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.OCTUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.NONUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.DECUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.UNDECUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.DUODECUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.TREDECUPLE_COMPRESSED_STICK.get());
                        entries.method_45421(ModItems.QUATTUORDECUPLE_COMPRESSED_STICK.get());

                        entries.method_45421(ModItems.MWDC.get());
                        entries.method_45421(ModItems.DCDC.get());
                        entries.method_45421(ModItems.TLDC.get());
                        entries.method_45421(ModItems.CLDC.get());

                        entries.method_45421(ModItems.LIQUID_THUNDER_BUCKET.get());
                        entries.method_45421(ModItems.LIQUID_CORRUPTION_BUCKET.get());
                        entries.method_45421(ModItems.GX_BUCKET.get());

                        // BLOCKS
                        entries.method_45421(ModBlocks.MIMICARIUM_ORE.get());
                        entries.method_45421(ModBlocks.DEEPSLATE_MIMICARIUM_ORE.get());
                        entries.method_45421(ModBlocks.FAKESTONE_IRON_ORE.get());
                        entries.method_45421(ModBlocks.FAKESTONE_GOLD_ORE.get());
                        entries.method_45421(ModBlocks.FAKESLATE_IRON_ORE.get());
                        entries.method_45421(ModBlocks.FAKESLATE_GOLD_ORE.get());

                        entries.method_45421(ModBlocks.THUNDERED_LOG.get());
                        entries.method_45421(ModBlocks.THUNDERED_WOOD.get());
                        entries.method_45421(ModBlocks.STRIPPED_THUNDERED_LOG.get());
                        entries.method_45421(ModBlocks.STRIPPED_THUNDERED_WOOD.get());
                        entries.method_45421(ModBlocks.THUNDERED_PLANKS.get());
                        entries.method_45421(ModBlocks.THUNDERED_SLAB.get());
                        entries.method_45421(ModBlocks.THUNDERED_STAIRS.get());
                        entries.method_45421(ModBlocks.THUNDERED_DOOR.get());
                        entries.method_45421(ModBlocks.THUNDERED_TRAPDOOR.get());
                        entries.method_45421(ModBlocks.THUNDERED_FENCE.get());
                        entries.method_45421(ModBlocks.THUNDERED_FENCE_GATE.get());
                        entries.method_45421(ModBlocks.THUNDERED_PRESSURE_PLATE.get());
                        entries.method_45421(ModBlocks.THUNDERED_BUTTON.get());
                        entries.method_45421(ModBlocks.THUNDERED_LEAVES.get());
                        entries.method_45421(ModBlocks.THUNDERED_SAPLING.get());

                        entries.method_45421(ModBlocks.CORRUPTED_LOG.get());
                        entries.method_45421(ModBlocks.CORRUPTED_WOOD.get());
                        entries.method_45421(ModBlocks.STRIPPED_CORRUPTED_LOG.get());
                        entries.method_45421(ModBlocks.STRIPPED_CORRUPTED_WOOD.get());
                        entries.method_45421(ModBlocks.CORRUPTED_PLANKS.get());
                        entries.method_45421(ModBlocks.CORRUPTED_SAPLING.get());

                        entries.method_45421(ModBlocks.VOIDSTONE.get());
                        entries.method_45421(ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get());
                        entries.method_45421(ModBlocks.THUNDERANIUM_PORTAL_FRAME.get());
                        entries.method_45421(ModBlocks.CORRUPTION_PORTAL_FRAME.get());

                        entries.method_45421(ModBlocks.DREADSTONE.get());
                        entries.method_45421(ModBlocks.REINFORCED_DREADSTONE.get());
                        entries.method_45421(ModBlocks.REINFORCED_DREADSTONE_SLAB.get());
                        entries.method_45421(ModBlocks.REINFORCED_DREADSTONE_STAIRS.get());
                        entries.method_45421(ModBlocks.REINFORCED_DREADSTONE_WALL.get());
                        entries.method_45421(ModBlocks.REINFORCED_DREADSTONE_DOOR.get());
                        entries.method_45421(ModBlocks.REINFORCED_DREADSTONE_TRAPDOOR.get());
                        entries.method_45421(ModBlocks.REINFORCED_DREADSTONE_GLASS.get());
                        entries.method_45421(ModBlocks.DREADSTONE_DIAMOND_ORE.get());
                        entries.method_45421(ModBlocks.DREADSTONE_THUNDERANIUM_ORE.get());
                        entries.method_45421(ModBlocks.DREADSTONE_NETHERITE_ORE.get());
                        entries.method_45421(ModBlocks.VOID_COAL_ORE.get());
                        entries.method_45421(ModBlocks.VOID_COAL_BLOCK.get());

                        entries.method_45421(ModBlocks.FAKESTONE.get());
                        entries.method_45421(ModBlocks.FAKESLATE.get());

                        entries.method_45421(ModBlocks.THUNDERANIUM_TNT.get());
                        entries.method_45421(ModBlocks.RED_THUNDERANIUM_TNT.get());
                        entries.method_45421(ModBlocks.AXON_ALLOY_TNT.get());

                        entries.method_45421(ModBlocks.CHARGED_DIRT.get());
                        entries.method_45421(ModBlocks.THUNDERED_STONE.get());
                        entries.method_45421(ModBlocks.THUNDERANIUM_ORE.get());
                        entries.method_45421(ModBlocks.RENDERIUM_ORE.get());

                        entries.method_45421(ModBlocks.CORRUPTED_DIRT.get());
                        entries.method_45421(ModBlocks.CORRUPTED_STONE.get());
                        entries.method_45421(ModBlocks.CORRUPTION_BLOCK.get());
                        entries.method_45421(ModBlocks.CORRUPTINITE_ORE.get());
                        entries.method_45421(ModBlocks.DENDERIUM_ORE.get());

                        entries.method_45421(ModBlocks.MWDC_ORE.get());
                        entries.method_45421(ModBlocks.DCDC_ORE.get());
                        entries.method_45421(ModBlocks.TLDC_ORE.get());
                        entries.method_45421(ModBlocks.CLDC_ORE.get());
                    })));

    public static void initItemGroups() {
        TABS.register();
    }
}