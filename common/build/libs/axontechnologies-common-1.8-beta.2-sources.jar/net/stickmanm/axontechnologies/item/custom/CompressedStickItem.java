package net.stickmanm.axontechnologies.item.custom;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class CompressedStickItem extends class_1792 {

    public CompressedStickItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip, class_1836 context) {
        tooltip.add(class_2561.method_43471("tooltip.axontechnologies.compressed_stick")
                .method_27692(class_124.field_1080));
        super.method_7851(stack, world, tooltip, context);
    }
}
