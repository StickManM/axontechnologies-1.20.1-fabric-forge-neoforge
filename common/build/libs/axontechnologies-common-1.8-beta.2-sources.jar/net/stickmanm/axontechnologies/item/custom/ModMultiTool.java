package net.stickmanm.axontechnologies.item.custom;

import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;

public class ModMultiTool extends class_1810 {
    public ModMultiTool(class_1832 material, int attackDamage, float attackSpeed, class_1793 settings) {
        super(material, attackDamage, attackSpeed, settings);
    }
    @Override
    public boolean method_7870(class_1799 stack) {
        return super.method_7870(stack);
    }

    @Override
    public boolean method_7856(class_2680 state) {
        // Check if the block is mineable by a Pickaxe, Axe, Shovel, or Hoe tag
        return state.method_26164(class_3481.field_33715) ||
                state.method_26164(class_3481.field_33713) ||
                state.method_26164(class_3481.field_33716) ||
                state.method_26164(class_3481.field_33714);
    }

    @Override
    public float method_7865(class_1799 stack, class_2680 state) {
        class_1832 material = this.method_8022();

        // Check all relevant tags for the MultiTool
        if (state.method_26164(class_3481.field_33715) ||
                state.method_26164(class_3481.field_33713) ||
                state.method_26164(class_3481.field_33716) ||
                state.method_26164(class_3481.field_33714)) {

            // If the block is mineable by ANY of the tool types
            if (this.method_7856(state)) {
                return material.method_8027();
            }
        }

        return 1.0F; // Return 1.0F (default speed) if not effective
    }


    @Override
    public class_1269 method_7884(class_1838 context) {
        // Logic for tilling farmland (Hoe behavior)
        class_2338 pos = context.method_8037();

        // Example: Check for dirt/grass blocks and attempt to till
        // This often involves calling a static method similar to how vanilla tools work,
        // or replicating the logic from HoeItem's implementation.

        // If successful:
        // context.getStack().damage(1, context.getPlayer(), ...);
        // return ActionResult.SUCCESS;

        return class_1269.field_5811; // If no special action was taken
    }
}
