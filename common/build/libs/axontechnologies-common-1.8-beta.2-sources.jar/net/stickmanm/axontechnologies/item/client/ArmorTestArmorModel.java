package net.stickmanm.axontechnologies.item.client;

import net.minecraft.class_2960;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.item.custom.ArmorTestArmorItem;
import software.bernie.geckolib.model.GeoModel;

public class ArmorTestArmorModel extends GeoModel<ArmorTestArmorItem>{
    @Override
    public class_2960 getModelResource(ArmorTestArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "geo/armor_test.geo.json");
    }

    @Override
    public class_2960 getTextureResource(ArmorTestArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "textures/armor/armor_test.png");
    }

    @Override
    public class_2960 getAnimationResource(ArmorTestArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "animations/armor_test.animation.json");
    }
}
