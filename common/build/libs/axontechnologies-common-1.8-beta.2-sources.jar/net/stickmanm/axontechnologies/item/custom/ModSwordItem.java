package net.stickmanm.axontechnologies.item.custom;

import net.minecraft.class_1829;
import net.minecraft.class_1832;

public class ModSwordItem extends class_1829 {
    public ModSwordItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }


}
