package net.stickmanm.axontechnologies.item.client;

import net.minecraft.class_2960;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.item.custom.ThunderaniumArmorItem;
import software.bernie.geckolib.model.GeoModel;

public class ThunderaniumArmorModel extends GeoModel<ThunderaniumArmorItem>{
    @Override
    public class_2960 getModelResource(ThunderaniumArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "geo/thunderanium_armor.geo.json");
    }

    @Override
    public class_2960 getTextureResource(ThunderaniumArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "textures/armor/thunderanium_armor.png");
    }

    @Override
    public class_2960 getAnimationResource(ThunderaniumArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "animations/armor_test.animation.json");
    }
}
