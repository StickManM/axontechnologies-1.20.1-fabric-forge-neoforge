package net.stickmanm.axontechnologies.item;

import net.minecraft.class_156;
import net.minecraft.class_1738;
import net.minecraft.class_1740;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3528;
import net.minecraft.class_3542;
import net.minecraft.item.*;
import java.util.EnumMap;
import java.util.function.Supplier;

public enum ModArmorMaterials implements class_1741 {

    THUNDERANIUM("thunderanium", 400, class_156.method_654(new EnumMap(class_1738.class_8051.class), (map) -> {
        map.put(class_1738.class_8051.field_41937, 10);
        map.put(class_1738.class_8051.field_41936, 15);
        map.put(class_1738.class_8051.field_41935, 17);
        map.put(class_1738.class_8051.field_41934, 13);
    }), 19, class_3417.field_21866, 2.0F, 0.1F, () -> {
        return class_1856.method_8091(new class_1792[]{ModItems.THUNDERANIUM_INGOT.get()});
    }),

    RED_THUNDERANIUM("red_thunderanium", 0, class_156.method_654(new EnumMap(class_1738.class_8051.class), (map) -> {
        map.put(class_1738.class_8051.field_41937, 13);
        map.put(class_1738.class_8051.field_41936, 20);
        map.put(class_1738.class_8051.field_41935, 23);
        map.put(class_1738.class_8051.field_41934, 16);
    }), 35, class_3417.field_21866, 2.5F, 0.25F, () -> {
        return class_1856.method_8091(new class_1792[]{ModItems.RED_THUNDERANIUM_INGOT.get()});
    }),

    DARK_THUNDERANIUM("dark_thunderanium", 0, class_156.method_654(new EnumMap(class_1738.class_8051.class), (map) -> {
        map.put(class_1738.class_8051.field_41937, 19);
        map.put(class_1738.class_8051.field_41936, 26);
        map.put(class_1738.class_8051.field_41935, 28);
        map.put(class_1738.class_8051.field_41934, 21);
    }), 50, class_3417.field_21866, 3.0F, 0.5F, () -> {
        return class_1856.method_8091(new class_1792[]{ModItems.DARK_THUNDERANIUM_INGOT.get()});
    }),

    CORRUPTINITE("corruptinite", 0, class_156.method_654(new EnumMap(class_1738.class_8051.class), (map) -> {
        map.put(class_1738.class_8051.field_41937, 17);
        map.put(class_1738.class_8051.field_41936, 25);
        map.put(class_1738.class_8051.field_41935, 27);
        map.put(class_1738.class_8051.field_41934, 20);
    }), 55, class_3417.field_21866, 3.0F, 0.5F, () -> {
        return class_1856.method_8091(new class_1792[]{ModItems.CORRUPTINITE.get()});
    }),

    CORRUPTINITE_AXON_ALLOY_ARMOR("corruptinite_axon_alloy_armor", 0, class_156.method_654(new EnumMap(class_1738.class_8051.class), (map) -> {
        map.put(class_1738.class_8051.field_41937, 27);
        map.put(class_1738.class_8051.field_41936, 35);
        map.put(class_1738.class_8051.field_41935, 37);
        map.put(class_1738.class_8051.field_41934, 30);
    }), 100, class_3417.field_21866, 5.0F, 1, () -> {
        return class_1856.method_8091(new class_1792[]{ModItems.CORRUPTINITE.get()});
    }),

    DARK_THUNDERANIUM_AXON_ALLOY_ARMOR("dark_thunderanium_axon_alloy_armor", 0, class_156.method_654(new EnumMap(class_1738.class_8051.class), (map) -> {
        map.put(class_1738.class_8051.field_41937, 29);
        map.put(class_1738.class_8051.field_41936, 36);
        map.put(class_1738.class_8051.field_41935, 38);
        map.put(class_1738.class_8051.field_41934, 31);
    }), 115, class_3417.field_21866, 5.0F, 1F, () -> {
        return class_1856.method_8091(new class_1792[]{ModItems.DARK_THUNDERANIUM_INGOT.get()});
    }),

    AXON_ALLOY_ARMOR("axon_alloy_armor", 0, class_156.method_654(new EnumMap(class_1738.class_8051.class), (map) -> {
        map.put(class_1738.class_8051.field_41937, 25);
        map.put(class_1738.class_8051.field_41936, 33);
        map.put(class_1738.class_8051.field_41935, 35);
        map.put(class_1738.class_8051.field_41934, 28);
    }), 90, class_3417.field_21866, 5.0F, 1F, () -> {
        return class_1856.method_8091(new class_1792[]{ModItems.AXON_ALLOY.get()});
    });

    public static final class_3542.class_7292<class_1740> CODEC = class_3542.method_28140(class_1740::values);
    private static final EnumMap<class_1738.class_8051, Integer> BASE_DURABILITY = class_156.method_654(new EnumMap(class_1738.class_8051.class), (map) -> {
        map.put(class_1738.class_8051.field_41937, 13);
        map.put(class_1738.class_8051.field_41936, 15);
        map.put(class_1738.class_8051.field_41935, 16);
        map.put(class_1738.class_8051.field_41934, 11);
    });
    private final String name;
    private final int durabilityMultiplier;
    private final EnumMap<class_1738.class_8051, Integer> protectionAmounts;
    private final int enchantability;
    private final class_3414 equipSound;
    private final float toughness;
    private final float knockbackResistance;
    private final class_3528<class_1856> repairIngredientSupplier;

    private ModArmorMaterials(String name, int durabilityMultiplier, EnumMap protectionAmounts, int enchantability, class_3414 equipSound, float toughness, float knockbackResistance, Supplier repairIngredientSupplier) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.protectionAmounts = protectionAmounts;
        this.enchantability = enchantability;
        this.equipSound = equipSound;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repairIngredientSupplier = new class_3528(repairIngredientSupplier);
    }

    public int method_48402(class_1738.class_8051 type) {
        return (Integer)BASE_DURABILITY.get(type) * this.durabilityMultiplier;
    }

    public int method_48403(class_1738.class_8051 type) {
        return (Integer)this.protectionAmounts.get(type);
    }

    public int method_7699() {
        return this.enchantability;
    }

    public class_3414 method_7698() {
        return this.equipSound;
    }

    public class_1856 method_7695() {
        return (class_1856)this.repairIngredientSupplier.method_15332();
    }

    public String method_7694() {
        return this.name;
    }

    public float method_7700() {
        return this.toughness;
    }

    public float method_24355() {
        return this.knockbackResistance;
    }

    public String asString() {
        return this.name;
    }
}