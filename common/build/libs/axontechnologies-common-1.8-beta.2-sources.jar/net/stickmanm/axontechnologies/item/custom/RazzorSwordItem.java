package net.stickmanm.axontechnologies.item.custom;

import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.stickmanm.axontechnologies.effect.ModEffects;

public class RazzorSwordItem extends class_1829{
    public RazzorSwordItem(class_1832 toolMaterial, int attackDamage, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {

        target.method_6033(Float.MIN_EXPONENT);
        target.method_6092(new class_1293(ModEffects.OVERDOSE.get(), -1, 255, false,true));
        return super.method_7873(stack, target, attacker);
    }
}
