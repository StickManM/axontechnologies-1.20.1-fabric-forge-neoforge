package net.stickmanm.axontechnologies.item.client;

import net.minecraft.class_2960;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.item.custom.DarkThunderaniumArmorItem;
import software.bernie.geckolib.model.GeoModel;

public class DarkThunderaniumArmorModel extends GeoModel<DarkThunderaniumArmorItem>{
    @Override
    public class_2960 getModelResource(DarkThunderaniumArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "geo/thunderanium_armor.geo.json");
    }

    @Override
    public class_2960 getTextureResource(DarkThunderaniumArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "textures/armor/dark_thunderanium_armor.png");
    }

    @Override
    public class_2960 getAnimationResource(DarkThunderaniumArmorItem animatable) {
        return new class_2960(AxonTechnologiesConstants.MOD_ID, "animations/armor_test.animation.json");
    }
}
