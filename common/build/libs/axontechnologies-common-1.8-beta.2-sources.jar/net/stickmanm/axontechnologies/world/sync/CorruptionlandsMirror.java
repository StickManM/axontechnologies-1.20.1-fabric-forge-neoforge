package net.stickmanm.axontechnologies.world.sync;

import dev.architectury.event.CompoundEventResult;
import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.BlockEvent;
import dev.architectury.event.events.common.ExplosionEvent;
import dev.architectury.event.events.common.InteractionEvent;
import dev.architectury.event.events.common.TickEvent;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2404;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.block.custom.CustomPortalBlock;
import net.stickmanm.axontechnologies.fluid.ModFluids;
import net.stickmanm.axontechnologies.world.dimension.ModDimensions;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * The Corruptionlands is a "future version" of the Thunderlands: block changes made in the Thunderlands are
 * copied (converted to their corrupted equivalents) to the same X/Y/Z in the Corruptionlands.
 *
 * How it works: events (player place/break, bucket use, explosions) only mark positions as "dirty".
 * At the end of the Thunderlands' tick every dirty position is re-read and its final state is copied over.
 * Nothing is mixed into vanilla code, so this works the same on Fabric and Forge.
 *
 * Note: writing to a Corruptionlands chunk that isn't generated yet generates it first, so nothing is lost.
 */
public class CorruptionlandsMirror {
    /** Max positions copied per tick, so big explosions are spread over a few ticks instead of lagging. */
    private static final int POSITIONS_PER_TICK = 2048;

    private static final Set<Long> DIRTY = new LinkedHashSet<>();

    private static Set<class_2248> keepAsIs;            // blocks that are already "corrupted" and are copied unchanged

    public static void register() {
        // Player breaks a block
        BlockEvent.BREAK.register((world, pos, state, player, xp) -> {
            mark(world, pos, 0);
            return EventResult.pass();
        });

        // Player places a block
        BlockEvent.PLACE.register((world, pos, state, placer) -> {
            mark(world, pos, 1);
            return EventResult.pass();
        });

        // Right clicking a block (covers placing/scooping fluids next to the clicked block)
        InteractionEvent.RIGHT_CLICK_BLOCK.register((player, hand, pos, face) -> {
            mark(player.method_37908(), pos, 1);
            return EventResult.pass();
        });

        // Right clicking with an item, e.g. buckets that target a fluid block
        InteractionEvent.RIGHT_CLICK_ITEM.register((player, hand) -> {
            if (player instanceof class_3222 && CorruptionlandsMirror.isThunderlands(player.method_37908())) {
                class_239 hit = player.method_5745(5.0, 1.0f, true);
                if (hit instanceof class_3965 blockHit && hit.method_17783() == class_239.class_240.field_1332) {
                    mark(player.method_37908(), blockHit.method_17777(), 1);
                }
            }
            return CompoundEventResult.pass();
        });

        // Explosions: every block the explosion destroys
        ExplosionEvent.DETONATE.register((world, explosion, affectedEntities) -> {
            if (isThunderlands(world)) {
                for (class_2338 pos : explosion.method_8346()) {
                    mark(world, pos, 0);
                }
            }
        });

        // Copy the dirty positions at the end of the Thunderlands' tick
        TickEvent.SERVER_LEVEL_POST.register(world -> {
            if (DIRTY.isEmpty() || !world.method_27983().equals(ModDimensions.THUNDERLANDS_DIMENSION_KEY)) return;

            class_3218 target = world.method_8503().method_3847(ModDimensions.CORRUPTIONLANDS_DIMENSION_KEY);
            if (target == null) {
                DIRTY.clear();
                return;
            }

            Iterator<Long> it = DIRTY.iterator();
            int processed = 0;
            while (it.hasNext() && processed++ < POSITIONS_PER_TICK) {
                class_2338 pos = class_2338.method_10092(it.next());
                it.remove();
                copy(world, target, pos);
            }
        });
    }

    private static boolean isThunderlands(class_1937 world) {
        return !world.field_9236 && world.method_27983().equals(ModDimensions.THUNDERLANDS_DIMENSION_KEY);
    }

    /** Marks pos (and everything within `radius` blocks of it) to be copied at the end of the tick. */
    private static void mark(class_1937 world, class_2338 pos, int radius) {
        if (!isThunderlands(world)) return;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    DIRTY.add(pos.method_10069(dx, dy, dz).method_10063());
                }
            }
        }
    }

    private static void copy(class_3218 source, class_3218 target, class_2338 pos) {
        if (target.method_31606(pos)) return;

        class_2680 mapped = convert(source, pos, source.method_8320(pos));
        if (mapped == null) return; // nothing to copy for this position

        if (target.method_8320(pos) != mapped) {
            target.method_8652(pos, mapped, class_2248.field_31028);
        }
    }

    /**
     * Converts a Thunderlands block into what should exist at the same spot in the Corruptionlands.
     * Returns null when the position should be left alone.
     */
    private static class_2680 convert(class_3218 source, class_2338 pos, class_2680 state) {
        class_2248 block = state.method_26204();
        class_2680 air = class_2246.field_10124.method_9564();

        if (state.method_26215()) return air;

        // Portals: only Corruptionlands portals are mirrored (copied exactly), every other portal becomes air
        if (isPortalBlock(block)) {
            return isCorruptionPortal(source, pos, block) ? state : air;
        }

        // Fluids: any fluid source becomes liquid corruption. Flowing fluid is left alone, the
        // liquid corruption source flows by itself.
        if (block instanceof class_2404) {
            return state.method_26227().method_15771()
                    ? ModFluids.LIQUID_CORRUPTION_BLOCK.get().method_9564()
                    : null;
        }

        // Leaves of any wood set are not reflected
        if (state.method_26164(class_3481.field_15503)) return air;

        // Dirt
        if (state.method_27852(class_2246.field_10566) || state.method_27852(ModBlocks.CHARGED_DIRT.get()) || state.method_27852(ModBlocks.CORRUPTED_DIRT.get())) {
            return ModBlocks.CORRUPTED_DIRT.get().method_9564();
        }

        // Stone
        if (state.method_27852(class_2246.field_10340) || state.method_27852(ModBlocks.THUNDERED_STONE.get()) || state.method_27852(ModBlocks.CORRUPTED_STONE.get())) {
            return ModBlocks.CORRUPTED_STONE.get().method_9564();
        }

        // Portal frame
        if (state.method_27852(ModBlocks.THUNDERANIUM_PORTAL_FRAME.get())) {
            return ModBlocks.CORRUPTION_PORTAL_FRAME.get().method_9564();
        }

        // Every wood set (vanilla, modded, thundered, corrupted) -> the corrupted wood set
        class_2680 wood = convertWood(state);
        if (wood != null) return wood;

        // Already-corrupted blocks are copied exactly
        if (keepAsIs().contains(block)) return state;

        // Everything else
        return ModBlocks.CORRUPTION_BLOCK.get().method_9564();
    }

    /** Logs, wood, stripped variants, planks and saplings of any wood type. Returns null for non-wood blocks. */
    private static class_2680 convertWood(class_2680 state) {
        if (state.method_26164(class_3481.field_15475)) {
            String path = class_7923.field_41175.method_10221(state.method_26204()).method_12832();
            boolean stripped = path.startsWith("stripped_");
            boolean bark = path.endsWith("_wood") || path.endsWith("_hyphae"); // all-sides-bark block

            class_2248 result;
            if (stripped) result = bark ? ModBlocks.STRIPPED_CORRUPTED_WOOD.get() : ModBlocks.STRIPPED_CORRUPTED_LOG.get();
            else          result = bark ? ModBlocks.CORRUPTED_WOOD.get()          : ModBlocks.CORRUPTED_LOG.get();

            class_2680 out = result.method_9564();
            if (state.method_28498(class_2465.field_11459)) out = out.method_11657(class_2465.field_11459, state.method_11654(class_2465.field_11459));
            return out;
        }
        if (state.method_26164(class_3481.field_15471)) return ModBlocks.CORRUPTED_PLANKS.get().method_9564();
        if (state.method_26164(class_3481.field_15462)) return ModBlocks.CORRUPTED_SAPLING.get().method_9564();
        return null;
    }

    private static boolean isPortalBlock(class_2248 block) {
        if (block == class_2246.field_10316 || block == class_2246.field_10027 || block == class_2246.field_10613) return true;
        if (block instanceof CustomPortalBlock) return true; // Forge custom portals (this mod)
        return class_7923.field_41175.method_10221(block).method_12836().equals("customportalapi"); // Fabric Custom Portal API
    }

    /**
     * A portal is a Corruptionlands portal when the frame around it is the corruption portal frame.
     * Works for both loaders: walk away from the portal block in every direction until the first
     * non-portal block, and check whether that block is the corruption frame.
     */
    private static boolean isCorruptionPortal(class_3218 world, class_2338 pos, class_2248 portal) {
        class_2248 frame = ModBlocks.CORRUPTION_PORTAL_FRAME.get();
        for (class_2350 dir : class_2350.values()) {
            class_2338.class_2339 cursor = pos.method_25503();
            for (int i = 0; i < 24; i++) { // portals are at most 21 wide
                cursor.method_10098(dir);
                class_2248 b = world.method_8320(cursor).method_26204();
                if (b == portal) continue;
                if (b == frame) return true;
                break;
            }
        }
        return false;
    }

    private static Set<class_2248> keepAsIs() {
        if (keepAsIs == null) {
            Set<class_2248> set = new HashSet<>();
            set.add(ModBlocks.CORRUPTION_BLOCK.get());
            set.add(ModBlocks.CORRUPTION_PORTAL_FRAME.get());
            keepAsIs = set;
        }
        return keepAsIs;
    }
}