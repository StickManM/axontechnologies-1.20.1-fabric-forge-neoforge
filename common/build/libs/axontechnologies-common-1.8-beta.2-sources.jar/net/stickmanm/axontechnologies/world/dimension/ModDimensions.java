package net.stickmanm.axontechnologies.world.dimension;

import net.minecraft.class_1937;
import net.minecraft.class_2874;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.item.ModItems;

public class ModDimensions {
    //Dread Caverns
    public static final class_5321<class_1937> DCDIM_DIMENSION_KEY = class_5321.method_29179(class_7924.field_41223,
            new class_2960(AxonTechnologiesConstants.MOD_ID, "dreadcaverns"));
    public static final class_5321<class_2874> DCDIM_TYPE_KEY = class_5321.method_29179(class_7924.field_41241, DCDIM_DIMENSION_KEY.method_29177());

    //Mimic World
    public static final class_5321<class_1937> MIMDIM_DIMENSION_KEY = class_5321.method_29179(class_7924.field_41223,
            new class_2960(AxonTechnologiesConstants.MOD_ID, "mimicworld"));
    public static final class_5321<class_2874> MIMDIM_TYPE_KEY = class_5321.method_29179(class_7924.field_41241, MIMDIM_DIMENSION_KEY.method_29177());

    //Thunderlands
    public static final class_5321<class_1937> THUNDERLANDS_DIMENSION_KEY = class_5321.method_29179(class_7924.field_41223,
            new class_2960(AxonTechnologiesConstants.MOD_ID, "thunderlands"));
    public static final class_5321<class_2874> THUNDERLANDS_TYPE_KEY = class_5321.method_29179(class_7924.field_41241, THUNDERLANDS_DIMENSION_KEY.method_29177());

    public static final class_5321<class_1937> CORRUPTIONLANDS_DIMENSION_KEY = class_5321.method_29179(class_7924.field_41223,
            new class_2960(AxonTechnologiesConstants.MOD_ID, "corruptionlands"));
    public static final class_5321<class_2874> CORRUPTIONLANDS_TYPE_KEY = class_5321.method_29179(class_7924.field_41241, CORRUPTIONLANDS_DIMENSION_KEY.method_29177());

    public static final class_5321<class_1937> DAWN_OF_TIME_KEY = class_5321.method_29179(class_7924.field_41223,
            new class_2960(AxonTechnologiesConstants.MOD_ID, "dawn_of_time"));
    public static final class_5321<class_2874> DAWN_OF_TIME_TYPE_KEY = class_5321.method_29179(class_7924.field_41241, DAWN_OF_TIME_KEY.method_29177());

    public static void registerModDimensions() {
        // Portal registration moved to platform-specific modulees

    }
}
