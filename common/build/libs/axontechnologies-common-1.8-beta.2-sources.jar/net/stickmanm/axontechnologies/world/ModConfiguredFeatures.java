package net.stickmanm.axontechnologies.world;

import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3124;
import net.minecraft.class_3798;
import net.minecraft.class_3825;
import net.minecraft.class_4643;
import net.minecraft.class_4646;
import net.minecraft.class_4651;
import net.minecraft.class_5140;
import net.minecraft.class_5204;
import net.minecraft.class_5321;
import net.minecraft.class_6016;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.block.ModBlockTags;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.fluid.ModFluids;

import java.util.List;

public class ModConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> THUNDERED_SAPLING_KEY = registerKey("thundered_tree");
    public static final class_5321<class_2975<?, ?>> CORRUPTED_SAPLING_KEY = registerKey("corrupted_tree");
    public static final class_5321<class_2975<?, ?>> MIMICARIUM_ORE_KEY = registerKey("mimicarium_ore");
    public static final class_5321<class_2975<?, ?>> FAKESTONES_IRON_ORE_KEY = registerKey("fakestones_iron_ore");
    public static final class_5321<class_2975<?, ?>> FAKESTONES_GOLD_ORE_KEY = registerKey("fakestones_gold_ore");
    public static final class_5321<class_2975<?, ?>> VOIDSTONE_ORE_KEY = registerKey("voidstone");
    public static final class_5321<class_2975<?, ?>> DREADSTONE_DIAMOND_ORE_KEY = registerKey("dreadstone_diamond_ore");
    public static final class_5321<class_2975<?, ?>> DREADSTONE_THUNDERANIUM_ORE_KEY = registerKey("dreadstone_thunderanium_ore");
    public static final class_5321<class_2975<?, ?>> DREADSTONE_NETHERITE_ORE_KEY = registerKey("dreadstone_netherite_ore");
    public static final class_5321<class_2975<?, ?>> VOID_COAL_ORE_KEY = registerKey("void_coal_ore");
    public static final class_5321<class_2975<?, ?>> DIMENSION_CORE_ORE_KEY = registerKey("dimension_core_ore");
    public static final class_5321<class_2975<?, ?>> RENDERIUM_ORE_KEY = registerKey("renderium_ore");
    public static final class_5321<class_2975<?, ?>> THUNDERANIUM_ORE_KEY = registerKey("thunderanium_ore");
    public static final class_5321<class_2975<?, ?>> DENDERIUM_ORE_KEY = registerKey("denderium_ore");
    public static final class_5321<class_2975<?, ?>> CORRUPTINITE_ORE_KEY = registerKey("corruptinite_ore");
    public static final class_5321<class_2975<?, ?>> CORRUPTION_BLOCK_ORE_KEY = registerKey("corruption_block_ore");
    public static final class_5321<class_2975<?, ?>> ORE_LIQUID_THUNDER_KEY = registerKey("ore_liquid_thunder");
    public static final class_5321<class_2975<?, ?>> ORE_LIQUID_CORRUPTION_KEY = registerKey("ore_liquid_corruption");


    public static void bootstrap(class_7891<class_2975<?, ?>> context) {
        //Mimicarium Ore
        class_3825 mimicariumStoneReplaceables = new class_3798(ModBlockTags.MIMICARIUM_REPLACEABLE_STONE);
        class_3825 mimicariumDeepslateReplaceables = new class_3798(ModBlockTags.MIMICARIUM_REPLACEABLE_DEEPSLATE);
        class_3825 fakeslate = new class_3798(ModBlockTags.FAKESLATE_REPLACEABLE);
        class_3825 fakestone = new class_3798(ModBlockTags.FAKESTONE_REPLACEABLE);
        class_3825 dreadCaverns = new class_3798(ModBlockTags.DREADSTONE_REPLACEABLE);
        class_3825 thunderlands = new class_3798(ModBlockTags.THUNDERED_STONE_REPLACEABLE);
        class_3825 corruptionlands = new class_3798(ModBlockTags.CORRUPTED_STONE_REPLACEABLE);
        class_3825 voidstoneReplaceable = new class_3798(ModBlockTags.VOIDSTONE_REPLACEABLE);

        List<class_3124.class_5876> overworldMimicariumOres =
                List.of(class_3124.method_33994(mimicariumStoneReplaceables, ModBlocks.MIMICARIUM_ORE.get().method_9564()),
                       class_3124.method_33994(mimicariumDeepslateReplaceables, ModBlocks.DEEPSLATE_MIMICARIUM_ORE.get().method_9564()));

        //Mimic World
        List<class_3124.class_5876> fakestonesIronOre = List.of(class_3124.method_33994(fakestone, ModBlocks.FAKESTONE_IRON_ORE.get().method_9564()),
                class_3124.method_33994(fakeslate, ModBlocks.FAKESLATE_IRON_ORE.get().method_9564()));

        List<class_3124.class_5876> fakestonesGoldOre = List.of(class_3124.method_33994(fakestone, ModBlocks.FAKESTONE_GOLD_ORE.get().method_9564()),
                class_3124.method_33994(fakeslate, ModBlocks.FAKESLATE_GOLD_ORE.get().method_9564()));

        List<class_3124.class_5876> voidstoneOre = List.of(class_3124.method_33994(voidstoneReplaceable, ModBlocks.VOIDSTONE.get().method_9564()));





        //Dimension Cores
        List<class_3124.class_5876> dimensionCoreOres =
                List.of(class_3124.method_33994(fakeslate, ModBlocks.MWDC_ORE.get().method_9564()),
                        class_3124.method_33994(dreadCaverns, ModBlocks.DCDC_ORE.get().method_9564()),
                        class_3124.method_33994(thunderlands, ModBlocks.TLDC_ORE.get().method_9564()),
                        class_3124.method_33994(corruptionlands, ModBlocks.CLDC_ORE.get().method_9564()));

        //Dreadstone Ores
        List<class_3124.class_5876> dreadstoneDiamondOres = List.of(class_3124.method_33994(dreadCaverns, ModBlocks.DREADSTONE_DIAMOND_ORE.get().method_9564()));
        List<class_3124.class_5876> dreadstoneThunderaniumOres = List.of(class_3124.method_33994(dreadCaverns, ModBlocks.DREADSTONE_THUNDERANIUM_ORE.get().method_9564()));
        List<class_3124.class_5876> dreadstoneNetheriteOres = List.of(class_3124.method_33994(dreadCaverns, ModBlocks.DREADSTONE_NETHERITE_ORE.get().method_9564()));
        List<class_3124.class_5876> voidCoalOres = List.of(class_3124.method_33994(dreadCaverns, ModBlocks.VOID_COAL_ORE.get().method_9564()));

        //Thunderlands
        List<class_3124.class_5876> renderiumOres = List.of(class_3124.method_33994(thunderlands, ModBlocks.RENDERIUM_ORE.get().method_9564()));
        List<class_3124.class_5876> thunderaniumOres = List.of(class_3124.method_33994(thunderlands, ModBlocks.THUNDERANIUM_ORE.get().method_9564()));
        List<class_3124.class_5876> corruptionBlockOres = List.of(class_3124.method_33994(thunderlands, ModBlocks.CORRUPTION_BLOCK.get().method_9564()));
        List<class_3124.class_5876> oreLiquidThunder = List.of(class_3124.method_33994(thunderlands, ModFluids.LIQUID_THUNDER_BLOCK.get().method_9564()));

        //Corruptionlands
        List<class_3124.class_5876> denderiumOres = List.of(class_3124.method_33994(corruptionlands, ModBlocks.DENDERIUM_ORE.get().method_9564()));
        List<class_3124.class_5876> corruptiniteOres = List.of(class_3124.method_33994(corruptionlands, ModBlocks.CORRUPTINITE_ORE.get().method_9564()));
        List<class_3124.class_5876> oreLiquidCorruption = List.of(class_3124.method_33994(corruptionlands, ModFluids.LIQUID_CORRUPTION_BLOCK.get().method_9564()));








        //Thundered Tree
        register(context, THUNDERED_SAPLING_KEY, class_3031.field_24134, new class_4643.class_4644(
                class_4651.method_38432(ModBlocks.THUNDERED_LOG.get()),
                new class_5140(5, 6, 3),
                class_4651.method_38432(ModBlocks.THUNDERED_LEAVES.get()),
                new class_4646(class_6016.method_34998(2), class_6016.method_34998(0), 4),
                new class_5204(1, 0, 2)).method_23445());

        register(context, CORRUPTED_SAPLING_KEY, class_3031.field_24134, new class_4643.class_4644(
                class_4651.method_38432(ModBlocks.CORRUPTED_LOG.get()),
                new class_5140(5, 6, 3),
                class_4651.method_38432(class_2246.field_10124),
                new class_4646(class_6016.method_34998(2), class_6016.method_34998(0), 4),
                new class_5204(1, 0, 2)).method_23445());

        //register ores
        register(context, MIMICARIUM_ORE_KEY, class_3031.field_13517, new class_3124(overworldMimicariumOres, 10));
        register(context, DIMENSION_CORE_ORE_KEY, class_3031.field_13517, new class_3124(dimensionCoreOres, 3));
        register(context, FAKESTONES_IRON_ORE_KEY, class_3031.field_13517, new class_3124(fakestonesIronOre, 14));
        register(context, FAKESTONES_GOLD_ORE_KEY, class_3031.field_13517, new class_3124(fakestonesGoldOre, 10));
        register(context, VOIDSTONE_ORE_KEY, class_3031.field_13517, new class_3124(voidstoneOre, 11));
        register(context, RENDERIUM_ORE_KEY, class_3031.field_13517, new class_3124(renderiumOres, 4));
        register(context, THUNDERANIUM_ORE_KEY, class_3031.field_13517, new class_3124(thunderaniumOres, 10));
        register(context, CORRUPTION_BLOCK_ORE_KEY, class_3031.field_13517, new class_3124(corruptionBlockOres, 12));
        register(context, DENDERIUM_ORE_KEY, class_3031.field_13517, new class_3124(denderiumOres, 4));
        register(context, CORRUPTINITE_ORE_KEY, class_3031.field_13517, new class_3124(corruptiniteOres, 5));
        register(context, ORE_LIQUID_THUNDER_KEY, class_3031.field_13517, new class_3124(oreLiquidThunder, 7));
        register(context, ORE_LIQUID_CORRUPTION_KEY, class_3031.field_13517, new class_3124(oreLiquidCorruption, 7));


        //Dreadstone Ores
        register(context, DREADSTONE_DIAMOND_ORE_KEY, class_3031.field_13517, new class_3124(dreadstoneDiamondOres, 8));
        register(context, DREADSTONE_NETHERITE_ORE_KEY, class_3031.field_13517, new class_3124(dreadstoneNetheriteOres, 4));
        register(context, DREADSTONE_THUNDERANIUM_ORE_KEY, class_3031.field_13517, new class_3124(dreadstoneThunderaniumOres, 4));
        register(context, VOID_COAL_ORE_KEY, class_3031.field_13517, new class_3124(voidCoalOres, 10));

    }
    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, new class_2960(AxonTechnologiesConstants.MOD_ID, name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }

}
