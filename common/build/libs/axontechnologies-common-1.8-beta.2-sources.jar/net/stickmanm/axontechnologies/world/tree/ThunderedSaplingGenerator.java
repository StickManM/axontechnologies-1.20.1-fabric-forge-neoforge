package net.stickmanm.axontechnologies.world.tree;

import net.minecraft.class_2647;
import net.minecraft.class_2975;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.stickmanm.axontechnologies.world.ModConfiguredFeatures;
import org.jetbrains.annotations.Nullable;

public class ThunderedSaplingGenerator extends class_2647 {
    @Nullable
    @Override
    protected class_5321<class_2975<?, ?>> method_11430(class_5819 random, boolean bees) {
        return ModConfiguredFeatures.THUNDERED_SAPLING_KEY;
    }
}
