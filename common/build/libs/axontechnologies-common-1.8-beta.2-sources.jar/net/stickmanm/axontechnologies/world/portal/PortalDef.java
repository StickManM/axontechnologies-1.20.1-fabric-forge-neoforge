package net.stickmanm.axontechnologies.world.portal;

import dev.architectury.registry.registries.RegistrySupplier;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_5321;

/** One custom portal: which frame block + igniter item opens a portal to which dimension. */
public class PortalDef {
    public final String name;
    public final Supplier<class_2248> frame;
    public final class_5321<class_1937> destination;
    public final int tint;
    public final Supplier<class_1792> igniter;
    /** Flat portals lie horizontally (like a trapdoor) instead of standing up. */
    public final boolean flat;
    public RegistrySupplier<class_2248> portalBlock;
    public class_5321<class_1937> returnDimension;

    public PortalDef(String name, Supplier<class_2248> frame, class_5321<class_1937> destination, int tint, Supplier<class_1792> igniter, boolean flat) {
        this.name = name;
        this.frame = frame;
        this.destination = destination;
        this.tint = tint;
        this.igniter = igniter;
        this.flat = flat;

    }
}
