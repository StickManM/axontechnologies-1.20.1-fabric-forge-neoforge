package net.stickmanm.axontechnologies.world.portal;

import dev.architectury.event.EventResult;
import dev.architectury.event.events.common.InteractionEvent;
import dev.architectury.registry.registries.DeferredRegister;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4970;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.block.custom.CustomPortalBlock;
import net.stickmanm.axontechnologies.item.ModItems;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

import static net.stickmanm.axontechnologies.world.dimension.ModDimensions.*;

/**
 * Loader-independent custom portals (Forge uses this; Fabric keeps using Custom Portal API).
 * Frame block + right clicking with the igniter item lights a portal; standing in it teleports to the target dimension,
 * a portal inside the target dimension leads back to the overworld.
 */
public class ModPortals {
    public static final DeferredRegister<class_2248> PORTAL_BLOCKS =
            DeferredRegister.create(AxonTechnologiesConstants.MOD_ID, class_7924.field_41254);

    public static final List<PortalDef> PORTALS = new ArrayList<>();

    private static final int WAIT_TICKS = 80;       // 4 seconds in survival, like the nether portal
    private static final int SEARCH_RADIUS = 16;
    private static final int MAX_FRAME = 21;

    // player -> {first tick inside, last tick inside}
    private static final Map<UUID, long[]> IN_PORTAL = new ConcurrentHashMap<>();

    public static final PortalDef DREAD_CAVERNS = define("dreadcaverns", () -> ModBlocks.VOIDSTONE.get(),
            DCDIM_DIMENSION_KEY, 0x000000, () -> ModItems.DREADED_IGNITER.get(), true);
    public static final PortalDef MIMIC_WORLD = define("mimicworld", () -> ModBlocks.MIMIMCARIUM_PORTAL_FRAME.get(),
            MIMDIM_DIMENSION_KEY, 0x90EE90, () -> ModItems.MIMICARIUM_IGNITER.get(), false);
    public static final PortalDef THUNDERLANDS = define("thunderlands", () -> ModBlocks.THUNDERANIUM_PORTAL_FRAME.get(),
            THUNDERLANDS_DIMENSION_KEY, 0xAAA9AD, () -> ModItems.THUNDERANIUM_KEY.get(), false);
    public static final PortalDef CORRUPTIONLANDS = define("corruptionlands", () -> ModBlocks.CORRUPTION_PORTAL_FRAME.get(),
            CORRUPTIONLANDS_DIMENSION_KEY, 0x8B0000, () -> ModItems.CORRUPTION_GATEWAY.get(), false);

    static {
        CORRUPTIONLANDS.returnDimension = THUNDERLANDS_DIMENSION_KEY;
    }

    private static PortalDef define(String name, Supplier<class_2248> frame, net.minecraft.class_5321<class_1937> dest,
                                    int tint, Supplier<net.minecraft.class_1792> igniter, boolean flat) {
        PortalDef def = new PortalDef(name, frame, dest, tint, igniter, flat);
        def.portalBlock = PORTAL_BLOCKS.register(name + "_portal", () -> new CustomPortalBlock(def,
                class_4970.class_2251.method_9630(class_2246.field_10316)));
        PORTALS.add(def);
        return def;
    }

    /** Call once from the Forge mod constructor. */
    public static void init() {
        PORTAL_BLOCKS.register();
        InteractionEvent.RIGHT_CLICK_BLOCK.register(ModPortals::onRightClickBlock);
    }

    // ------------------------------------------------------------------ lighting

    private static EventResult onRightClickBlock(class_1657 player, class_1268 hand, class_2338 pos, class_2350 face) {
        class_1937 world = player.method_37908();
        if (world.method_8608())
            return EventResult.pass();

        class_1799 held = player.method_5998(hand);
        if (held.method_7960())
            return EventResult.pass();

        class_2680 clicked = world.method_8320(pos);
        for (PortalDef def : PORTALS) {
            boolean validIgniter = held.method_31574(def.igniter.get()) || held.method_31574(ModItems.UNIVERSAL_IGNITER.get());
            if (!validIgniter || !clicked.method_27852(def.frame.get()))
                continue;

            class_2338 start = pos.method_10093(face);
            boolean lit = false;
            if (def.flat) {
                lit = tryLight(world, start, class_2350.class_2351.field_11052, def);
            } else {
                lit = tryLight(world, start, class_2350.class_2351.field_11048, def) || tryLight(world, start, class_2350.class_2351.field_11051, def);
            }
            if (lit) {
                world.method_8396(null, start, class_3417.field_14669, class_3419.field_15245, 0.5f, 1.0f);
                return EventResult.interruptTrue();
            }
        }
        return EventResult.pass();
    }

    private static boolean tryLight(class_1937 world, class_2338 start, class_2350.class_2351 axis, PortalDef def) {
        List<class_2338> interior = findFrame(world, start, axis, def.frame.get());
        if (interior == null)
            return false;
        class_2680 portal = def.portalBlock.get().method_9564().method_11657(CustomPortalBlock.AXIS, axis);
        for (class_2338 p : interior)
            world.method_8652(p, portal, class_2248.field_31028 | class_2248.field_31031);
        return true;
    }

    /**
     * Flood fills the air inside a frame in the plane of the given axis. Returns the interior positions if it is a
     * closed rectangle (at least 2 wide and 3 tall, or 2x2 for flat portals), otherwise null.
     */
    private static List<class_2338> findFrame(class_1937 world, class_2338 start, class_2350.class_2351 axis, class_2248 frame) {
        if (!isReplaceable(world.method_8320(start)))
            return null;

        class_2350[] dirs = CustomPortalBlock.planeDirections(axis);
        Set<class_2338> seen = new HashSet<>();
        Deque<class_2338> queue = new ArrayDeque<>();
        queue.add(start);
        seen.add(start);

        while (!queue.isEmpty()) {
            class_2338 cur = queue.poll();
            for (class_2350 d : dirs) {
                class_2338 next = cur.method_10093(d);
                if (seen.contains(next))
                    continue;
                class_2680 state = world.method_8320(next);
                if (isReplaceable(state)) {
                    seen.add(next);
                    if (seen.size() > MAX_FRAME * MAX_FRAME)
                        return null;
                    queue.add(next);
                } else if (!state.method_27852(frame)) {
                    return null; // leak: something that is neither air nor frame
                }
            }
        }

        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE,
                minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
        for (class_2338 p : seen) {
            minX = Math.min(minX, p.method_10263()); maxX = Math.max(maxX, p.method_10263());
            minY = Math.min(minY, p.method_10264()); maxY = Math.max(maxY, p.method_10264());
            minZ = Math.min(minZ, p.method_10260()); maxZ = Math.max(maxZ, p.method_10260());
        }
        int sx = maxX - minX + 1, sy = maxY - minY + 1, sz = maxZ - minZ + 1;
        if (sx * sy * sz != seen.size())
            return null; // not a rectangle

        boolean ok;
        switch (axis) {
            case field_11048 -> ok = sx >= 2 && sy >= 3 && sz == 1;
            case field_11051 -> ok = sz >= 2 && sy >= 3 && sx == 1;
            default -> ok = sx >= 2 && sz >= 2 && sy == 1;
        }
        if (!ok || seen.size() > MAX_FRAME * MAX_FRAME)
            return null;
        return new ArrayList<>(seen);
    }

    private static boolean isReplaceable(class_2680 state) {
        return state.method_26215() || state.method_27852(class_2246.field_10036) || state.method_27852(class_2246.field_22089);
    }

    // ------------------------------------------------------------------ travelling

    /** Called every tick a player is inside one of our portal blocks. */
    public static void playerInPortal(class_3222 player, PortalDef def) {
        if (player.method_30230()) {
            player.method_30229(); // keep the cooldown up while standing in the portal we arrived in
            IN_PORTAL.remove(player.method_5667());
            return;
        }

        long now = player.method_51469().method_8510();
        long[] t = IN_PORTAL.get(player.method_5667());
        if (t == null || now - t[1] > 4) {
            t = new long[]{now, now};
            IN_PORTAL.put(player.method_5667(), t);
        }
        t[1] = now;

        int needed = player.method_7337() ? 1 : WAIT_TICKS;
        if (now - t[0] < needed)
            return;

        IN_PORTAL.remove(player.method_5667());
        travel(player, def);
    }

    private static void travel(class_3222 player, PortalDef def) {
        MinecraftServer server = player.method_5682();
        if (server == null)
            return;

        class_3218 from = player.method_51469();

        class_3218 to;
        if (from.method_27983() == def.destination) {
            to = def.returnDimension != null ? server.method_3847(def.returnDimension) : server.method_30002();
        } else {
            to = server.method_3847(def.destination);
        }

        if (to == null)
            return;

        class_2338 center = class_2338.method_49637(player.method_23317(), player.method_23318(), player.method_23321());
        double[] exit = findOrCreate(to, center, def);
        if (exit == null)
            return;

        player.method_30229();
        player.method_14251(to, exit[0], exit[1], exit[2], player.method_36454(), player.method_36455());
        player.method_30229();
    }

    /** @return {x, y, z} to place the player at */
    private static double[] findOrCreate(class_3218 world, class_2338 center, PortalDef def) {
        class_2248 portalBlock = def.portalBlock.get();

        // 1) look for an existing portal of ours nearby
        class_2338 best = null;
        double bestDist = Double.MAX_VALUE;
        int bottom = world.method_31607();
        int top = world.method_31600();
        for (int x = center.method_10263() - SEARCH_RADIUS; x <= center.method_10263() + SEARCH_RADIUS; x++) {
            for (int z = center.method_10260() - SEARCH_RADIUS; z <= center.method_10260() + SEARCH_RADIUS; z++) {
                world.method_8497(x >> 4, z >> 4); // loads the chunk
                for (int y = bottom; y < top; y++) {
                    class_2338 p = new class_2338(x, y, z);
                    if (world.method_8320(p).method_27852(portalBlock)) {
                        double d = p.method_10262(center);
                        if (d < bestDist) {
                            bestDist = d;
                            best = p;
                        }
                    }
                }
            }
        }
        if (best != null)
            return exitNextTo(world, best);

        // 2) build a new one
        return buildPortal(world, center, def);
    }

    private static double[] exitNextTo(class_3218 world, class_2338 portalPos) {
        class_2680 state = world.method_8320(portalPos);
        class_2350.class_2351 axis = state.method_11654(CustomPortalBlock.AXIS);

        if (axis == class_2350.class_2351.field_11052) {
            // stand on top of a frame block next to the flat portal
            for (class_2350 d : class_2350.class_2353.field_11062) {
                class_2338 side = portalPos.method_10093(d);
                if (!world.method_8320(side).method_27852(state.method_26204()) && isSafe(world, side.method_10084()))
                    return new double[]{side.method_10263() + 0.5, side.method_10264() + 1, side.method_10260() + 0.5};
            }
            return new double[]{portalPos.method_10263() + 0.5, portalPos.method_10264() + 1, portalPos.method_10260() + 0.5};
        }

        class_2338 bottom = portalPos;
        while (world.method_8320(bottom.method_10074()).method_27852(state.method_26204()))
            bottom = bottom.method_10074();

        class_2350 normal = axis == class_2350.class_2351.field_11048 ? class_2350.field_11035 : class_2350.field_11034;
        for (class_2350 d : new class_2350[]{normal, normal.method_10153()}) {
            class_2338 spot = bottom.method_10093(d);
            if (isSafe(world, spot))
                return new double[]{spot.method_10263() + 0.5, spot.method_10264(), spot.method_10260() + 0.5};
        }
        return new double[]{bottom.method_10263() + 0.5, bottom.method_10264(), bottom.method_10260() + 0.5};
    }

    private static boolean isSafe(class_3218 world, class_2338 feet) {
        return world.method_8320(feet).method_26220(world, feet).method_1110()
                && world.method_8320(feet.method_10084()).method_26220(world, feet.method_10084()).method_1110()
                && !world.method_8320(feet.method_10074()).method_26220(world, feet.method_10074()).method_1110();
    }

    private static double[] buildPortal(class_3218 world, class_2338 center, PortalDef def) {
        int x = center.method_10263();
        int z = center.method_10260();
        world.method_8497(x >> 4, z >> 4);

        int bottom = world.method_31607() + 4;
        int top = world.method_31600() - 8;
        int y;
        if (world.method_8597().comp_643())
            y = Math.max(bottom, Math.min(top, center.method_10264()));
        else
            y = Math.max(bottom, Math.min(top, world.method_8624(class_2902.class_2903.field_13203, x, z)));

        class_2248 frame = def.frame.get();
        class_2680 frameState = frame.method_9564();
        class_2680 air = class_2246.field_10124.method_9564();
        int flags = class_2248.field_31028 | class_2248.field_31031;

        if (def.flat) {
            // 4x4 frame ring (2x2 portal) lying flat at height y, with room above it
            for (int dx = -2; dx <= 3; dx++)
                for (int dz = -2; dz <= 3; dz++)
                    for (int dy = 1; dy <= 3; dy++)
                        world.method_8652(new class_2338(x + dx, y + dy, z + dz), air, flags);
            class_2680 portal = def.portalBlock.get().method_9564().method_11657(CustomPortalBlock.AXIS, class_2350.class_2351.field_11052);
            for (int dx = -1; dx <= 2; dx++) {
                for (int dz = -1; dz <= 2; dz++) {
                    boolean inner = dx >= 0 && dx <= 1 && dz >= 0 && dz <= 1;
                    world.method_8652(new class_2338(x + dx, y, z + dz), inner ? portal : frameState, flags);
                }
            }
            return new double[]{x - 0.5, y + 1, z + 0.5};
        }

        // vertical portal along X: frame 4 wide x 5 tall, portal 2x3, floor platform around it
        for (int dx = -1; dx <= 2; dx++)
            for (int dz = -1; dz <= 1; dz++) {
                world.method_8652(new class_2338(x + dx, y, z + dz), frameState, flags); // floor
                for (int dy = 1; dy <= 4; dy++)
                    world.method_8652(new class_2338(x + dx, y + dy, z + dz), air, flags);
            }
        for (int dx = -1; dx <= 2; dx++) {
            world.method_8652(new class_2338(x + dx, y + 4, z), frameState, flags); // top
        }
        for (int dy = 1; dy <= 3; dy++) {
            world.method_8652(new class_2338(x - 1, y + dy, z), frameState, flags);
            world.method_8652(new class_2338(x + 2, y + dy, z), frameState, flags);
        }
        class_2680 portal = def.portalBlock.get().method_9564().method_11657(CustomPortalBlock.AXIS, class_2350.class_2351.field_11048);
        for (int dx = 0; dx <= 1; dx++)
            for (int dy = 1; dy <= 3; dy++)
                world.method_8652(new class_2338(x + dx, y + dy, z), portal, flags);

        return new double[]{x + 1.0, y + 1, z + 1.5};
    }
}
