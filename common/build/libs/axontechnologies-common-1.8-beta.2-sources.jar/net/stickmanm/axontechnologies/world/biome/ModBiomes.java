package net.stickmanm.axontechnologies.world.biome;

import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;

public class ModBiomes {

    public static final class_5321<class_1959> THUNDERED_PLAINS_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","thundered_plains"));
    public static final class_5321<class_1959> CORRUPTED_PLAINS_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","corrupted_plains"));
    public static final class_5321<class_1959> DREAD_WASTES_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","dread_wastes"));
    public static final class_5321<class_1959> MIMIC_PLAINS_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","mimic_plains"));
    public static final class_5321<class_1959> MIMIC_DESERT_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","mimic_desert"));
    public static final class_5321<class_1959> MIMIC_BAMBOO_JUNGLE_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","mimic_bamboo_jungle"));
    public static final class_5321<class_1959> MIMIC_FOREST_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","mimic_forest"));
    public static final class_5321<class_1959> MIMIC_TAIGA_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","mimic_taiga"));
    public static final class_5321<class_1959> MIMIC_SWAMP_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","mimic_swamp"));
    public static final class_5321<class_1959> MIMIC_SNOWY_TAIGA_KEY = class_5321.method_29179(class_7924.field_41236, new class_2960("axontechnologies","mimic_snowy_taiga"));


    public static void registerModBiomes(){
        // Biome registration moved to platform-specific modules
    }
}
