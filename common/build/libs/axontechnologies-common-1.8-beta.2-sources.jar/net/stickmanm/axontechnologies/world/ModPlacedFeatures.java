package net.stickmanm.axontechnologies.world;

import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_5934;
import net.minecraft.class_6792;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6817;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.gen.placementmodifier.*;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.block.ModBlocks;

import java.util.List;

public class ModPlacedFeatures {
    public static final class_5321<class_6796> MIMICARIUM_ORE_PLACED_KEY = registerKey("mimicarium_ore_placed");
    public static final class_5321<class_6796> THUNDERED_TREE_PLACED_KEY = registerKey("thundered_tree_placed");
    public static final class_5321<class_6796> CORRUPTED_TREE_PLACED_KEY = registerKey("corrupted_tree_placed");
    public static final class_5321<class_6796> FAKESTONES_IRON_ORE_PLACED_KEY = registerKey("fakestones_iron_ore");
    public static final class_5321<class_6796> FAKESTONES_GOLD_ORE_PLACED_KEY = registerKey("fakestones_gold_ore");
    public static final class_5321<class_6796> VOIDSTONE_ORE_PLACED_KEY = registerKey("voidstone");
    public static final class_5321<class_6796> DIMENSION_CORE_PLACED_KEY = registerKey("dimension_core_ore");
    public static final class_5321<class_6796> DREADSTONE_DIAMOND_ORE_PLACED_KEY = registerKey("dreadstone_diamond_ore");
    public static final class_5321<class_6796> DREADSTONE_NETHERITE_ORE_PLACED_KEY = registerKey("dreadstone_netherite_ore");
    public static final class_5321<class_6796> DREADSTONE_THUNDERANIUM_ORE_PLACED_KEY = registerKey("dreadstone_thunderanium_ore");
    public static final class_5321<class_6796> VOID_COAL_ORE_PLACED_KEY = registerKey("void_coal_ore");
    public static final class_5321<class_6796> RENDERIUM_ORE_PLACED_KEY = registerKey("renderium_ore");
    public static final class_5321<class_6796> THUNDERANIUM_ORE_PLACED_KEY = registerKey("thunderanium_ore");
    public static final class_5321<class_6796> CORRUPTION_BLOCK_ORE_PLACED_KEY = registerKey("corruption_block_ore");
    public static final class_5321<class_6796> DENDERIUM_ORE_PLACED_KEY = registerKey("denderium_ore");
    public static final class_5321<class_6796> CORRUPTINITE_ORE_PLACED_KEY = registerKey("corruptinite_ore");
    public static final class_5321<class_6796> ORE_LIQUID_THUNDER_PLACED_KEY = registerKey("ore_liquid_thunder");
    public static final class_5321<class_6796> ORE_LIQUID_CORRUPTION_PLACED_KEY = registerKey("ore_liquid_corruption");



    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatureRegistryEntryLookup = context.method_46799(class_7924.field_41239);


        register(context, MIMICARIUM_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.MIMICARIUM_ORE_KEY),
                ModOrePlacement.modifiersWithCount(32, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33846(0), class_5843.method_33849(200))));

        register(context, FAKESTONES_IRON_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.FAKESTONES_IRON_ORE_KEY),
                ModOrePlacement.modifiersWithCount(64, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33846(0), class_5843.method_33849(100))));

        register(context, FAKESTONES_GOLD_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.FAKESTONES_GOLD_ORE_KEY),
                ModOrePlacement.modifiersWithCount(50, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33846(0), class_5843.method_33849(100))));

        register(context, VOIDSTONE_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.VOIDSTONE_ORE_KEY),
                ModOrePlacement.modifiersWithCount(50, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33846(1), class_5843.method_33849(300))));

        register(context, DIMENSION_CORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.DIMENSION_CORE_ORE_KEY),
                ModOrePlacement.modifiersWithCount(8, // Veins per Chunk
                        class_6795.method_39637(class_5843.method_33846(0), class_5843.method_33849(200))));

        //DREADSTONE ORES
        register(context, DREADSTONE_DIAMOND_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.DREADSTONE_DIAMOND_ORE_KEY),
                ModOrePlacement.modifiersWithCount(32, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(0))));

        register(context, DREADSTONE_NETHERITE_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.DREADSTONE_NETHERITE_ORE_KEY),
                ModOrePlacement.modifiersWithCount(19, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(0))));

        register(context, DREADSTONE_THUNDERANIUM_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.DREADSTONE_THUNDERANIUM_ORE_KEY),
                ModOrePlacement.modifiersWithCount(17, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(0))));

        register(context, VOID_COAL_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.VOID_COAL_ORE_KEY),
                ModOrePlacement.modifiersWithCount(27, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(0))));

        //Thunderlands
        register(context, RENDERIUM_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.RENDERIUM_ORE_KEY),
                ModOrePlacement.modifiersWithCount(9, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(100))));

        register(context, THUNDERANIUM_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.THUNDERANIUM_ORE_KEY),
                ModOrePlacement.modifiersWithCount(40, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(50))));

        register(context, CORRUPTION_BLOCK_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.CORRUPTION_BLOCK_ORE_KEY),
                ModOrePlacement.modifiersWithCount(25, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(370))));

        register(context, ORE_LIQUID_THUNDER_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.ORE_LIQUID_THUNDER_KEY),
                ModOrePlacement.modifiersWithCount(12, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(50))));

        register(context, THUNDERED_TREE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.THUNDERED_SAPLING_KEY),
                class_6817.method_39736(1, 0.1f, 2),
                class_5450.method_39639(),
                class_5934.method_39662(0),
                class_6817.field_36081,
                class_6817.method_40365(ModBlocks.THUNDERED_SAPLING.get()),
                class_6792.method_39614());


        //Corruptionlands
        register(context, DENDERIUM_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.DENDERIUM_ORE_KEY),
                ModOrePlacement.modifiersWithCount(9, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(100))));

        register(context, CORRUPTINITE_ORE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.CORRUPTINITE_ORE_KEY),
                ModOrePlacement.modifiersWithCount(14, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(50))));

        register(context, ORE_LIQUID_CORRUPTION_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.ORE_LIQUID_CORRUPTION_KEY),
                ModOrePlacement.modifiersWithCount(12, // Veins per Chunk
                        class_6795.method_39634(class_5843.method_33846(0), class_5843.method_33849(50))));

        register(context, CORRUPTED_TREE_PLACED_KEY, configuredFeatureRegistryEntryLookup.method_46747(ModConfiguredFeatures.CORRUPTED_SAPLING_KEY),
                class_6817.method_39736(1, 0.1f, 2),
                class_5450.method_39639(),
                class_5934.method_39662(0),
                class_6817.field_36081,
                class_6817.method_40365(ModBlocks.CORRUPTED_SAPLING.get()),
                class_6792.method_39614());






    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, new class_2960(AxonTechnologiesConstants.MOD_ID, name));
    }

    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                                                                   class_6880<class_2975<?, ?>> configuration,
                                                                                   class_6797... modifiers) {
        register(context, key, configuration, List.of(modifiers));
    }
}