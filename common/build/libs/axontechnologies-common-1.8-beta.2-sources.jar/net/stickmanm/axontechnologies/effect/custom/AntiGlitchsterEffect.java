package net.stickmanm.axontechnologies.effect.custom;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_4081;
import net.stickmanm.axontechnologies.effect.ModEffects;

public class AntiGlitchsterEffect extends class_1291 {
    public AntiGlitchsterEffect() {
        super(class_4081.field_18272, // whether beneficial or harmful for entities
                0x8B0000); // color in RGB
    }

    // This method is called every tick to check whether it should apply the status effect or not


    // This method is called when it applies the status effect. We implement custom functionality here.
    @Override
    public void method_5572(class_1309 entity, int Amplifier) {
        if (!entity.method_37908().method_8608()) {

            if (entity.method_6059(ModEffects.GLITCHSTER.get())) {
                entity.method_6016(ModEffects.GLITCHSTER.get());
            } else if (entity.method_6059(ModEffects.GLITCHSTERII.get())) {
                entity.method_6016(ModEffects.GLITCHSTERII.get());
            } else if (entity.method_6059(ModEffects.GLITCHSTERIII.get())) {
                entity.method_6016(ModEffects.GLITCHSTERIII.get());
                entity.method_6092(new class_1293(ModEffects.NEUTRALIZED_GLITCHSTER.get(), 40));
            } else if (entity.method_6059(ModEffects.GLITCHSTERIV.get())) {
                entity.method_6016(ModEffects.GLITCHSTERIV.get());
                entity.method_6092(new class_1293(ModEffects.NEUTRALIZED_GLITCHSTER.get(), 40));
            } else if (entity.method_6059(ModEffects.CORRUPTED_GLITCHSTER.get())) {
                entity.method_6016(ModEffects.ANTIGLITCHSTER.get());
            } else if (entity.method_6059(ModEffects.GLITCHSTERIV.get())) {
                entity.method_6016(ModEffects.GLITCHSTERIV.get());
            } else if (entity.method_6059(ModEffects.CORRUPTED_GLITCHSTERII.get())) {
                entity.method_6016(ModEffects.ANTIGLITCHSTER.get());
            } else if (entity.method_6059(ModEffects.CORRUPTED_GLITCHSTERIII.get())) {
                entity.method_6016(ModEffects.ANTIGLITCHSTER.get());
            }
        }


        entity.method_5643(entity.method_48923().method_48809(), 0.75f);



        super.method_5572(entity, Amplifier);
    }
    @Override
    public boolean method_5552(int duration, int amplifier) {
        // In our case, we just make it return true so that it applies the status effect every tick.
        return true;
    }
}