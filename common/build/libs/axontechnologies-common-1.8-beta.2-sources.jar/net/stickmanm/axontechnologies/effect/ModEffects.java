package net.stickmanm.axontechnologies.effect;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1291;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.effect.custom.*;

import java.util.function.Supplier;

public class ModEffects {

    public static final DeferredRegister<class_1291> EFFECTS =
            DeferredRegister.create(AxonTechnologiesConstants.MOD_ID, class_7924.field_41208);

    public static final RegistrySupplier<class_1291> GLITCHSTER = EFFECTS.register("glitchster", GlitchsterEffect::new);
    public static final RegistrySupplier<class_1291> GLITCHSTERII = EFFECTS.register("glitchster2", GlitchsterIIEffect::new);
    public static final RegistrySupplier<class_1291> GLITCHSTERIII = EFFECTS.register("glitchster3", GlitchsterIIIEffect::new);
    public static final RegistrySupplier<class_1291> GLITCHSTERIV = EFFECTS.register("glitchster4", GlitchsterIVEffect::new);
    public static final RegistrySupplier<class_1291> GLITCHSTERV = EFFECTS.register("glitchster5", GlitchsterVEffect::new);
    public static final RegistrySupplier<class_1291> GLITCHSTERX = EFFECTS.register("glitchx", GlitchsterXEffect::new);
    public static final RegistrySupplier<class_1291> OVERDOSE = EFFECTS.register("overdose", OverdoseEffect::new);
    public static final RegistrySupplier<class_1291> NEUTRALIZED_GLITCHSTER = EFFECTS.register("neutralized_glitchster", NeutralizedGlitchsterEffect::new);
    public static final RegistrySupplier<class_1291> THUNDER_POISONING = EFFECTS.register("thunder_poisoning", ThunderPoisoningEffect::new);

    public static final RegistrySupplier<class_1291> ANTIGLITCHSTER = EFFECTS.register("antiglitchster", AntiGlitchsterEffect::new);
    public static final RegistrySupplier<class_1291> CORRUPTED_GLITCHSTER = EFFECTS.register("corrupted_glitchster", CorruptedGlitchsterEffect::new);
    public static final RegistrySupplier<class_1291> CORRUPTED_GLITCHSTERII = EFFECTS.register("corrupted_glitchster2", CorruptedGlitchsterIIEffect::new);
    public static final RegistrySupplier<class_1291> CORRUPTED_GLITCHSTERIII = EFFECTS.register("corrupted_glitchster3", CorruptedGlitchsterIIIEffect::new);
    public static final RegistrySupplier<class_1291> ANTI_CORRUPTED_GLITCHSTER = EFFECTS.register("anti_corrupted_glitchster", AntiCorruptedGlitchsterEffect::new);

    public static final RegistrySupplier<class_1291> UNKILLABLE = EFFECTS.register("unkillable", UnkillableEffect::new);

    public static void registerModEffects() {
    }
}
