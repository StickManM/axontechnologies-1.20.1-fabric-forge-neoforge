package net.stickmanm.axontechnologies.effect.custom;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_4081;
import net.minecraft.class_5134;

public class ThunderPoisoningEffect extends class_1291 {
    public ThunderPoisoningEffect() {
        super(class_4081.field_18272, // whether beneficial or harmful for entities
                0xA8A9AD); // color in RGB
    }

    // This method is called every tick to check whether it should apply the status effect or not


    // This method is called when it applies the status effect. We implement custom functionality here.
    @Override
    public void method_5572(class_1309 entity, int Amplifier) {
        if (!entity.method_37908().method_8608()) {
            entity.method_5643(entity.method_48923().method_48809(), 2F);
                    method_5566(class_5134.field_23721, "22653B89-116E-49DC-9B6B-9971489B5BE5", -1, class_1322.class_1323.field_6328)
                            .method_5566(class_5134.field_23719, "7107DE5E-7CE8-4030-940E-514C1F160890", -0.16, class_1322.class_1323.field_6331)
                            .method_5566(class_5134.field_23716, "55FCED67-E92A-486E-9800-B47F202C4386", -10, class_1322.class_1323.field_6328)
                            .method_5566(class_5134.field_23726, "CC5AF142-2BD2-4215-B636-2605AED11727", -10, class_1322.class_1323.field_6328);


        }


        super.method_5572(entity, Amplifier);
    }
    @Override
    public boolean method_5552(int duration, int amplifier) {
        // In our case, we just make it return true so that it applies the status effect every tick.
        return true;
    }
}