package net.stickmanm.axontechnologies.effect.custom;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_4081;
import net.minecraft.class_5134;
import net.stickmanm.axontechnologies.effect.ModEffects;

public class GlitchsterXEffect extends class_1291 {
    public GlitchsterXEffect() {
        super(class_4081.field_18271, // whether beneficial or harmful for entities
                0x98D982); // color in RGB
    }

    // This method is called every tick to check whether it should apply the status effect or not


    // This method is called when it applies the status effect. We implement custom functionality here.
    @Override
    public void method_5572(class_1309 entity, int Amplifier) {

            if (!entity.method_37908().method_8608() && !entity.method_6059(ModEffects.OVERDOSE.get())) {

                if(entity.method_31747()){
                    ((class_1657) entity).method_7344().method_7585(Amplifier + 1, 1.0f);
                    entity.method_6092(new class_1293(class_1294.field_5905, 10, 1, false, false, false));
                }

                method_5566(class_5134.field_23721, "648D7064-6A60-4F59-8ABE-C2C23A6DD7A9", 50f, class_1322.class_1323.field_6328)
                        .method_5566(class_5134.field_23719, "91AEAA56-376B-4498-935B-2F7F68070635", 50f, class_1322.class_1323.field_6331)
                        .method_5566(class_5134.field_23716, "91AEAA56-376B-4498-935B-2F7F68070635", 200f, class_1322.class_1323.field_6328)
                        .method_5566(class_5134.field_23723, "AF8B6E3F-3328-4C0A-AA36-5BA2BB9DBEF3", 1000f, class_1322.class_1323.field_6331)
                        .method_5566(class_5134.field_23726, "AF8B6E3F-3328-4C0A-AA36-5BA2BB9DBEF3", 255f, class_1322.class_1323.field_6331);
                entity.method_6092(new class_1293(class_1294.field_5900, 10, 255, false, false, false));
                entity.method_6092(new class_1293(class_1294.field_5913, 10, 15, false, false, false));
                if (entity.method_6032() < entity.method_6063()) {
                    entity.method_6025(1f);
                }
            }



        super.method_5572(entity, Amplifier);
    }
    @Override
    public boolean method_5552(int duration, int amplifier) {
        // In our case, we just make it return true so that it applies the status effect every tick.
        return true;
    }
}