package net.stickmanm.axontechnologies.effect.custom;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_4081;
import net.minecraft.class_5134;

public class UnkillableEffect extends class_1291 {
    public UnkillableEffect() {
        super(class_4081.field_18271, // whether beneficial or harmful for entities
                0xFFFFFF); // color in RGB
    }

    // This method is called every tick to check whether it should apply the status effect or not


    // This method is called when it applies the status effect. We implement custom functionality here.
    @Override
    public void method_5572(class_1309 entity, int Amplifier) {

            if (!entity.method_37908().method_8608()) {
                entity.method_6012();
                entity.method_6092(new class_1293(this, 10, 0, false, true));


                if(entity.method_31747()){
                    ((class_1657) entity).method_7344().method_7585(Amplifier + 100000, 10000f);
                }
                method_5566(class_5134.field_23716, "91AEAA56-376B-4498-935B-2F7F68070635", Float.MAX_VALUE, class_1322.class_1323.field_6328);
                entity.method_6033(Integer.MAX_VALUE);

            }



        super.method_5572(entity, Amplifier);
    }
    @Override
    public boolean method_5552(int duration, int amplifier) {
        // In our case, we just make it return true so that it applies the status effect every tick.
        return true;
    }
}