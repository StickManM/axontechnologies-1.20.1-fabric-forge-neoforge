package net.stickmanm.axontechnologies.effect.custom;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_4081;
import net.stickmanm.axontechnologies.effect.ModEffects;

public class AntiCorruptedGlitchsterEffect extends class_1291 {
    public AntiCorruptedGlitchsterEffect() {
        super(class_4081.field_18273, // whether beneficial or harmful for entities
                0x98D982); // color in RGB
    }

    // This method is called every tick to check whether it should apply the status effect or not


    // This method is called when it applies the status effect. We implement custom functionality here.
    @Override
    public void method_5572(class_1309 entity, int Amplifier) {


       if (!entity.method_37908().method_8608()) {
           if(entity.method_6059(ModEffects.GLITCHSTER.get()) ||
                   entity.method_6059(ModEffects.GLITCHSTERII.get()) ||
                   entity.method_6059(ModEffects.GLITCHSTERIII.get()) ||
                   entity.method_6059(ModEffects.GLITCHSTERIV.get()) ||
                   entity.method_6059(ModEffects.GLITCHSTERV.get())) {
               entity.method_6016(this);
           }
           entity.method_5643(entity.method_48923().method_48809(), 0.5f);
        }



        super.method_5572(entity, Amplifier);
    }
    @Override
    public boolean method_5552(int duration, int amplifier) {
        // In our case, we just make it return true so that it applies the status effect every tick.
        return true;
    }
}