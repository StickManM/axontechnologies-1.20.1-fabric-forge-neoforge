package net.stickmanm.axontechnologies.util;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;

public class ModTags {

    public static class Blocks{


        private static class_6862<class_2248> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, name));
        }
    }

    public static class Items {

        public static final class_6862<class_1792> TRIMS = createTag("trims");
        public static final class_6862<class_1792> MIMIC_WORLD_INGITERS = createTag("lights_mimic_world_portal");
        public static final class_6862<class_1792> DREAD_CAVERNS_INGITERS = createTag("lights_dread_caverns_portal");
        public static final class_6862<class_1792> THUNDERLANDS_INGITERS = createTag("lights_thunderlands_portal");

        private static class_6862<class_1792> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41197, new class_2960(AxonTechnologiesConstants.MOD_ID, name));

        }
    }

    }




