package net.stickmanm.axontechnologies.util;

import net.minecraft.class_161;
import net.minecraft.class_189;
import net.minecraft.class_2066;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.item.ModItems;

import java.util.function.Consumer;

public class ModAdvancements implements Consumer<Consumer<class_161>> {
    @Override
    public void accept(Consumer<class_161> consumer) {

        class_161 getMimicarium = class_161.class_162.method_707()
                .method_697(
                        ModItems.MIMICARIUM.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_mimicarium.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_mimicarium.description"), // The description
                        new class_2960("textures/gui/advancements/backgrounds/adventure.png"), // Background image used
                        class_189.field_1254, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_mimicarium", class_2066.class_2068.method_8959(ModItems.MIMICARIUM.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_mimicarium");

        class_161 getThunderaniumIngot = class_161.class_162.method_707().method_701(getMimicarium)
                .method_697(
                        ModItems.THUNDERANIUM_INGOT.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_thunderanium_ingot.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_thunderanium_ingot.description"), // The description
                        null,
                        class_189.field_1254, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_thunderanium_ingot", class_2066.class_2068.method_8959(ModItems.THUNDERANIUM_INGOT.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_thunderanium_ingot");

        class_161 getThunderaniumArmor = class_161.class_162.method_707().method_701(getThunderaniumIngot)
                .method_697(
                        ModItems.THUNDERANIUM_CHESTPLATE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_thunderanium_armor.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_thunderanium_armor.description"), // The description
                        null,
                        class_189.field_1249, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_thunderanium_helmet", class_2066.class_2068.method_8959(ModItems.THUNDERANIUM_HELMET.get()))
                .method_709("got_thunderanium_chestplate", class_2066.class_2068.method_8959(ModItems.THUNDERANIUM_CHESTPLATE.get()))
                .method_709("got_thunderanium_leggings", class_2066.class_2068.method_8959(ModItems.THUNDERANIUM_LEGGINGS.get()))
                .method_709("got_thunderanium_boots", class_2066.class_2068.method_8959(ModItems.THUNDERANIUM_BOOTS.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/has_thunderanium_armor");

        class_161 getRedEssence = class_161.class_162.method_707().method_701(getThunderaniumArmor)
                .method_697(
                        ModItems.RED_ESSENCE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_red_essence.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_red_essence.description"), // The description
                        null,
                        class_189.field_1254, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_red_essence", class_2066.class_2068.method_8959(ModItems.RED_ESSENCE.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_red_essence");

        class_161 getRedThunderaniumIngot = class_161.class_162.method_707().method_701(getRedEssence)
                .method_697(
                        ModItems.RED_THUNDERANIUM_INGOT.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_red_thunderanium_ingot.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_red_thunderanium_ingot.description"), // The description
                        null,
                        class_189.field_1254, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_red_thunderanium_ingot", class_2066.class_2068.method_8959(ModItems.RED_THUNDERANIUM_INGOT.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_red_thunderanium_ingot");

        class_161 getRedThunderaniumArmor = class_161.class_162.method_707().method_701(getRedThunderaniumIngot)
                .method_697(
                        ModItems.RED_THUNDERANIUM_CHESTPLATE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_red_thunderanium_armor.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_red_thunderanium_armor.description"), // The description
                        null,
                        class_189.field_1249, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_red_thunderanium_helmet", class_2066.class_2068.method_8959(ModItems.RED_THUNDERANIUM_HELMET.get()))
                .method_709("got_red_thunderanium_chestplate", class_2066.class_2068.method_8959(ModItems.RED_THUNDERANIUM_CHESTPLATE.get()))
                .method_709("got_red_thunderanium_leggings", class_2066.class_2068.method_8959(ModItems.RED_THUNDERANIUM_LEGGINGS.get()))
                .method_709("got_red_thunderanium_boots", class_2066.class_2068.method_8959(ModItems.RED_THUNDERANIUM_BOOTS.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/has_red_thunderanium_armor");

        class_161 getDarkEssence = class_161.class_162.method_707().method_701(getRedThunderaniumArmor)
                .method_697(
                        ModItems.DARK_ESSENCE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_dark_essence.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_dark_essence.description"), // The description
                        null,
                        class_189.field_1254, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_dark_essence", class_2066.class_2068.method_8959(ModItems.DARK_ESSENCE.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_dark_essence");

        class_161 getDarkThunderaniumIngot = class_161.class_162.method_707().method_701(getDarkEssence)
                .method_697(
                        ModItems.DARK_THUNDERANIUM_INGOT.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_dark_thunderanium_ingot.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_dark_thunderanium_ingot.description"), // The description
                        null,
                        class_189.field_1254, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_dark_thunderanium_ingot", class_2066.class_2068.method_8959(ModItems.DARK_THUNDERANIUM_INGOT.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_dark_thunderanium_ingot");

        class_161 getCorruptinite = class_161.class_162.method_707().method_701(getDarkEssence)
                .method_697(
                        ModItems.CORRUPTINITE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_corruptinite.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_corruptinite.description"), // The description
                        null,
                        class_189.field_1254, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_corruptinite", class_2066.class_2068.method_8959(ModItems.CORRUPTINITE.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_corruptinite");

        class_161 getDarkThunderaniumArmor = class_161.class_162.method_707().method_701(getDarkThunderaniumIngot)
                .method_697(
                        ModItems.DARK_THUNDERANIUM_CHESTPLATE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_dark_thunderanium_armor.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_dark_thunderanium_armor.description"), // The description
                        null,
                        class_189.field_1250, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_dark_thunderanium_helmet", class_2066.class_2068.method_8959(ModItems.DARK_THUNDERANIUM_HELMET.get()))
                .method_709("got_dark_thunderanium_chestplate", class_2066.class_2068.method_8959(ModItems.DARK_THUNDERANIUM_CHESTPLATE.get()))
                .method_709("got_dark_thunderanium_leggings", class_2066.class_2068.method_8959(ModItems.DARK_THUNDERANIUM_LEGGINGS.get()))
                .method_709("got_dark_thunderanium_boots", class_2066.class_2068.method_8959(ModItems.DARK_THUNDERANIUM_BOOTS.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/has_dark_thunderanium_armor");

        class_161 getCorruptiniteArmor = class_161.class_162.method_707().method_701(getCorruptinite)
                .method_697(
                        ModItems.CORRUPTINITE_CHESTPLATE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_corruptinite_armor.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_corruptinite_armor.description"), // The description
                        null,
                        class_189.field_1250, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_corruptinite_helmet", class_2066.class_2068.method_8959(ModItems.CORRUPTINITE_HELMET.get()))
                .method_709("got_corruptinite_chestplate", class_2066.class_2068.method_8959(ModItems.CORRUPTINITE_CHESTPLATE.get()))
                .method_709("got_corruptinite_leggings", class_2066.class_2068.method_8959(ModItems.CORRUPTINITE_LEGGINGS.get()))
                .method_709("got_corruptinite_boots", class_2066.class_2068.method_8959(ModItems.CORRUPTINITE_BOOTS.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/has_corruptinite_armor");

        class_161 getAxonAlloy = class_161.class_162.method_707().method_701(getDarkEssence)
                .method_697(
                        ModItems.AXON_ALLOY.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_axon_alloy.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_axon_alloy.description"), // The description
                        null,
                        class_189.field_1254, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_axon_alloy", class_2066.class_2068.method_8959(ModItems.AXON_ALLOY.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_axon_alloy");

        class_161 getCorruptiniteAxonAlloyArmor = class_161.class_162.method_707().method_701(getAxonAlloy)
                .method_697(
                        ModItems.CORRUPTINITE_AXON_ALLOY_CHESTPLATE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_corruptinite_axon_alloy_armor.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_corruptinite_axon_alloy_armor.description"), // The description
                        null,
                        class_189.field_1250, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_axon_alloy_corruptinite_helmet", class_2066.class_2068.method_8959(ModItems.CORRUPTINITE_AXON_ALLOY_HELMET.get()))
                .method_709("got_axon_alloy_corruptinite_chestplate", class_2066.class_2068.method_8959(ModItems.CORRUPTINITE_AXON_ALLOY_CHESTPLATE.get()))
                .method_709("got_axon_alloy_corruptinite_leggings", class_2066.class_2068.method_8959(ModItems.CORRUPTINITE_AXON_ALLOY_LEGGINGS.get()))
                .method_709("got_axon_alloy_corruptinite_boots", class_2066.class_2068.method_8959(ModItems.CORRUPTINITE_AXON_ALLOY_BOOTS.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/has_axon_alloy_corruptinite_armor");

        class_161 getDarkThunderaniumAxonAlloyArmor = class_161.class_162.method_707().method_701(getAxonAlloy)
                .method_697(
                        ModItems.DARK_THUNDERANIUM_AXON_ALLOY_CHESTPLATE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_dark_thunderanium_axon_alloy_armor.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_dark_thunderanium_axon_alloy_armor.description"), // The description
                        null,
                        class_189.field_1250, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_axon_alloy_dark_thunderanium_helmet", class_2066.class_2068.method_8959(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_HELMET.get()))
                .method_709("got_axon_alloy_dark_thunderanium_chestplate", class_2066.class_2068.method_8959(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_CHESTPLATE.get()))
                .method_709("got_axon_alloy_dark_thunderanium_leggings", class_2066.class_2068.method_8959(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_LEGGINGS.get()))
                .method_709("got_axon_alloy_dark_thunderanium_boots", class_2066.class_2068.method_8959(ModItems.DARK_THUNDERANIUM_AXON_ALLOY_BOOTS.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/has_axon_alloy_dark_thunderanium_armor");

        class_161 getAxonAlloyArmor = class_161.class_162.method_707().method_701(getAxonAlloy)
                .method_697(
                        ModItems.AXON_ALLOY_CHESTPLATE.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_axon_alloy_armor.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_axon_alloy_armor.description"), // The description
                        null,
                        class_189.field_1250, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_axon_alloy_helmet", class_2066.class_2068.method_8959(ModItems.AXON_ALLOY_HELMET.get()))
                .method_709("got_axon_alloy_chestplate", class_2066.class_2068.method_8959(ModItems.AXON_ALLOY_CHESTPLATE.get()))
                .method_709("got_axon_alloy_leggings", class_2066.class_2068.method_8959(ModItems.AXON_ALLOY_LEGGINGS.get()))
                .method_709("got_axon_alloy_boots", class_2066.class_2068.method_8959(ModItems.AXON_ALLOY_BOOTS.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/has_axon_alloy_armor");

        class_161 getUltimateHoeTrophy = class_161.class_162.method_707().method_701(getAxonAlloy)
                .method_697(
                        ModItems.ULTIMATE_HOE_TROPHY.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_ultimate_hoe_trophy.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_ultimate_hoe_trophy.description"), // The description
                        null,
                        class_189.field_1250, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_ultimate_hoe_trophy", class_2066.class_2068.method_8959(ModItems.ULTIMATE_HOE_TROPHY.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_ultimate_hoe_trophy");

        class_161 getRazzorium = class_161.class_162.method_707().method_701(getAxonAlloy)
                .method_697(
                        ModItems.RAZZORIUM.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_razzorium.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_razzorium.description"), // The description
                        null,
                        class_189.field_1250, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_razzorium", class_2066.class_2068.method_8959(ModItems.RAZZORIUM.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_razzorium");

        class_161 getRazzor = class_161.class_162.method_707().method_701(getAxonAlloy)
                .method_697(
                        ModItems.RAZZORIUM.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_razzor.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_razzor.description"), // The description
                        null,
                        class_189.field_1250, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_razzor", class_2066.class_2068.method_8959(ModItems.RAZZOR.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_razzor");

        class_161 getRazzoriumMiner = class_161.class_162.method_707().method_701(getAxonAlloy)
                .method_697(
                        ModItems.RAZZORIUM_MINER.get(), // The display icon
                        class_2561.method_43471("advancement.axontechnologies.get_razzorium_miner.title"), // The title
                        class_2561.method_43471("advancement.axontechnologies.get_razzorium_miner.description"), // The description
                        null,
                        class_189.field_1250, // Options: TASK, CHALLENGE, GOAL
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_razzorium_miner", class_2066.class_2068.method_8959(ModItems.RAZZORIUM_MINER.get()))
                .method_694(consumer, AxonTechnologiesConstants.MOD_ID + "/got_razzorium_miner");





    }
}
