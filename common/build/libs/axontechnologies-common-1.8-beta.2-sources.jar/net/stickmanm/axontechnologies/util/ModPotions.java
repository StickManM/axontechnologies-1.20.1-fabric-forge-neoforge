package net.stickmanm.axontechnologies.util;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_1293;
import net.minecraft.class_1842;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.effect.ModEffects;

import java.util.function.Supplier;

public class ModPotions {

    public static final DeferredRegister<class_1842> POTIONS =
            DeferredRegister.create(AxonTechnologiesConstants.MOD_ID, class_7924.field_41215);

    public static final RegistrySupplier<class_1842> GLITCHSTERX = POTIONS.register("glitchsterx",
            () -> new class_1842(new class_1293(ModEffects.GLITCHSTERX.get(), 3600)));

}
