package net.stickmanm.axontechnologies.fluid.custom;

import dev.architectury.core.fluid.ArchitecturyFlowingFluid;
import dev.architectury.core.fluid.ArchitecturyFluidAttributes;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_5819;
import net.stickmanm.axontechnologies.block.ModBlocks;

/** Fluid behaviour only. Everything else (textures, buckets, ...) is configured in ModFluids through Architectury. */
public class LiquidCorruptionFluid {
    public static class Source extends ArchitecturyFlowingFluid.Source {
        public Source(ArchitecturyFluidAttributes attributes) {
            super(attributes);
        }

        @Override
        public void method_15792(class_1937 world, class_2338 pos, class_3610 state, class_5819 random) {
            LavaLikeFluids.randomTick(world, pos, random);
        }

        @Override
        protected void method_15745(class_1936 world, class_2338 pos, class_2680 state, class_2350 direction, class_3610 fluidState) {
            if (LavaLikeFluids.waterInteraction(this, world, pos, state, direction, ModBlocks.CORRUPTED_STONE.get(), ModBlocks.DREADSTONE.get()))
                return;
            super.method_15745(world, pos, state, direction, fluidState);
        }
    }

    public static class Flowing extends ArchitecturyFlowingFluid.Flowing {
        public Flowing(ArchitecturyFluidAttributes attributes) {
            super(attributes);
        }

        @Override
        public void method_15792(class_1937 world, class_2338 pos, class_3610 state, class_5819 random) {
            LavaLikeFluids.randomTick(world, pos, random);
        }

        @Override
        protected void method_15745(class_1936 world, class_2338 pos, class_2680 state, class_2350 direction, class_3610 fluidState) {
            if (LavaLikeFluids.waterInteraction(this, world, pos, state, direction, ModBlocks.CORRUPTED_STONE.get(), ModBlocks.DREADSTONE.get()))
                return;
            super.method_15745(world, pos, state, direction, fluidState);
        }
    }
}
