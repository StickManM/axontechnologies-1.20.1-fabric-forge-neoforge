package net.stickmanm.axontechnologies.fluid.custom;

import net.minecraft.class_1928;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import net.minecraft.class_4770;
import net.minecraft.class_5819;
import net.minecraft.class_6088;
import net.minecraft.world.*;

/** Lava-like behaviour (fire spreading, turning into stone when meeting water) shared by the mod's hot fluids. */
final class LavaLikeFluids {
    private LavaLikeFluids() {}

    static void randomTick(class_1937 world, class_2338 pos, class_5819 random) {
        if (!world.method_8450().method_8355(class_1928.field_19387)) {
            return;
        }
        int i = random.method_43048(3);
        if (i > 0) {
            class_2338 blockPos = pos;
            for (int j = 0; j < i; ++j) {
                if (!world.method_8477(blockPos = blockPos.method_10069(random.method_43048(3) - 1, 1, random.method_43048(3) - 1))) {
                    return;
                }
                class_2680 blockState = world.method_8320(blockPos);
                if (blockState.method_26215()) {
                    if (!canLightFire(world, blockPos)) continue;
                    world.method_8501(blockPos, class_4770.method_24416(world, blockPos));
                    return;
                }
                if (!blockState.method_51366()) continue;
                return;
            }
        } else {
            for (int k = 0; k < 3; ++k) {
                class_2338 blockPos2 = pos.method_10069(random.method_43048(3) - 1, 0, random.method_43048(3) - 1);
                if (!world.method_8477(blockPos2)) {
                    return;
                }
                if (!world.method_22347(blockPos2.method_10084()) || !hasBurnableBlock(world, blockPos2)) continue;
                world.method_8501(blockPos2.method_10084(), class_4770.method_24416(world, blockPos2));
            }
        }
    }

    private static boolean canLightFire(class_4538 world, class_2338 pos) {
        for (class_2350 direction : class_2350.values()) {
            if (!hasBurnableBlock(world, pos.method_10093(direction))) continue;
            return true;
        }
        return false;
    }

    private static boolean hasBurnableBlock(class_4538 world, class_2338 pos) {
        if (pos.method_10264() >= world.method_31607() && pos.method_10264() < world.method_31600() && !world.method_22340(pos)) {
            return false;
        }
        return world.method_8320(pos).method_50011();
    }

    /**
     * Fluid meeting water: turns into {@code stoneDown} when flowing down, {@code stoneUp} when flowing up.
     * @return true when the interaction happened (the normal flow should be skipped)
     */
    static boolean waterInteraction(class_3611 self, class_1936 world, class_2338 pos, class_2680 state, class_2350 direction,
                                    class_2248 stoneDown, class_2248 stoneUp) {
        if (direction != class_2350.field_11033 && direction != class_2350.field_11036)
            return false;
        class_3610 fluidState = world.method_8316(pos);
        if (self.method_15791(class_3486.field_15518) && fluidState.method_15767(class_3486.field_15517)) {
            if (state.method_26204() instanceof class_2404) {
                class_2248 result = direction == class_2350.field_11033 ? stoneDown : stoneUp;
                world.method_8652(pos, result.method_9564(), class_2248.field_31036);
            }
            world.method_20290(class_6088.field_31138, pos, 0);
            return true;
        }
        return false;
    }
}
