package net.stickmanm.axontechnologies.fluid;

import dev.architectury.core.fluid.ArchitecturyFlowingFluid;
import dev.architectury.core.fluid.ArchitecturyFluidAttributes;
import dev.architectury.core.fluid.SimpleArchitecturyFluidAttributes;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.block.custom.GXFluidBlock;
import net.stickmanm.axontechnologies.block.custom.LiquidCorruptionFluidBlock;
import net.stickmanm.axontechnologies.block.custom.LiquidThunderFluidBlock;
import net.stickmanm.axontechnologies.fluid.custom.LiquidCorruptionFluid;
import net.stickmanm.axontechnologies.fluid.custom.LiquidThunderFluid;
import net.stickmanm.axontechnologies.item.ModItems;

/**
 * Fluids are built on Architectury's fluid API so the same code works on Fabric and Forge
 * (Forge needs a FluidType for every fluid, Architectury creates it from these attributes).
 * Fluids must be registered before the fluid blocks (see the platform entry points).
 */
public class ModFluids {
    public static final DeferredRegister<class_3611> FLUIDS =
            DeferredRegister.create(AxonTechnologiesConstants.MOD_ID, class_7924.field_41270);
    public static final DeferredRegister<class_2248> FLUID_BLOCKS =
            DeferredRegister.create(AxonTechnologiesConstants.MOD_ID, class_7924.field_41254);

    private static final class_2960 WATER_STILL = new class_2960("minecraft", "block/water_still");
    private static final class_2960 WATER_FLOW = new class_2960("minecraft", "block/water_flow");
    private static final class_2960 WATER_OVERLAY = new class_2960("minecraft", "block/water_overlay");

    // ---- Liquid Thunder ----
    public static final ArchitecturyFluidAttributes LIQUID_THUNDER_ATTRIBUTES = SimpleArchitecturyFluidAttributes
            .ofSupplier(() -> ModFluids.FLOWING_LIQUID_THUNDER, () -> ModFluids.STILL_LIQUID_THUNDER)
            .convertToSource(true)
            .slopeFindDistance(8)
            .dropOff(1)
            .tickDelay(5)
            .explosionResistance(200f)
            .sourceTexture(WATER_STILL)
            .flowingTexture(WATER_FLOW)
            .overlayTexture(WATER_OVERLAY)
            .color(0xFFA8A9AD)
            .blockSupplier(() -> ModFluids.LIQUID_THUNDER_BLOCK)
            .bucketItemSupplier(() -> ModItems.LIQUID_THUNDER_BUCKET);

    public static final RegistrySupplier<class_3609> STILL_LIQUID_THUNDER = FLUIDS.register("liquid_thunder",
            () -> new LiquidThunderFluid.Source(LIQUID_THUNDER_ATTRIBUTES));
    public static final RegistrySupplier<class_3609> FLOWING_LIQUID_THUNDER = FLUIDS.register("flowing_liquid_thunder",
            () -> new LiquidThunderFluid.Flowing(LIQUID_THUNDER_ATTRIBUTES));
    public static final RegistrySupplier<LiquidThunderFluidBlock> LIQUID_THUNDER_BLOCK = FLUID_BLOCKS.register("liquid_thunder_block",
            () -> new LiquidThunderFluidBlock(STILL_LIQUID_THUNDER.get(),
                    class_4970.class_2251.method_9630(class_2246.field_10164).method_51177().method_50012(class_3619.field_15971).method_51371()));

    // ---- Liquid Corruption ----
    public static final ArchitecturyFluidAttributes LIQUID_CORRUPTION_ATTRIBUTES = SimpleArchitecturyFluidAttributes
            .ofSupplier(() -> ModFluids.FLOWING_LIQUID_CORRUPTION, () -> ModFluids.STILL_LIQUID_CORRUPTION)
            .convertToSource(true)
            .slopeFindDistance(8)
            .dropOff(1)
            .tickDelay(5)
            .explosionResistance(200f)
            .sourceTexture(WATER_STILL)
            .flowingTexture(WATER_FLOW)
            .overlayTexture(WATER_OVERLAY)
            .color(0xFF111111)
            .blockSupplier(() -> ModFluids.LIQUID_CORRUPTION_BLOCK)
            .bucketItemSupplier(() -> ModItems.LIQUID_CORRUPTION_BUCKET);

    public static final RegistrySupplier<class_3609> STILL_LIQUID_CORRUPTION = FLUIDS.register("liquid_corruption",
            () -> new LiquidCorruptionFluid.Source(LIQUID_CORRUPTION_ATTRIBUTES));
    public static final RegistrySupplier<class_3609> FLOWING_LIQUID_CORRUPTION = FLUIDS.register("flowing_liquid_corruption",
            () -> new LiquidCorruptionFluid.Flowing(LIQUID_CORRUPTION_ATTRIBUTES));
    public static final RegistrySupplier<LiquidCorruptionFluidBlock> LIQUID_CORRUPTION_BLOCK = FLUID_BLOCKS.register("liquid_corruption_block",
            () -> new LiquidCorruptionFluidBlock(STILL_LIQUID_CORRUPTION.get(),
                    class_4970.class_2251.method_9630(class_2246.field_10164).method_51177().method_50012(class_3619.field_15971).method_51371()));

    // ---- GX ----
    public static final ArchitecturyFluidAttributes GX_ATTRIBUTES = SimpleArchitecturyFluidAttributes
            .ofSupplier(() -> ModFluids.FLOWING_GX, () -> ModFluids.STILL_GX)
            .convertToSource(false)
            .slopeFindDistance(1)
            .dropOff(1)
            .tickDelay(5)
            .explosionResistance(200f)
            .sourceTexture(WATER_STILL)
            .flowingTexture(WATER_FLOW)
            .overlayTexture(WATER_OVERLAY)
            .color(0xFF519B66)
            .blockSupplier(() -> ModFluids.GX_BLOCK)
            .bucketItemSupplier(() -> ModItems.GX_BUCKET);

    public static final RegistrySupplier<class_3609> STILL_GX = FLUIDS.register("gx",
            () -> new ArchitecturyFlowingFluid.Source(GX_ATTRIBUTES));
    public static final RegistrySupplier<class_3609> FLOWING_GX = FLUIDS.register("flowing_gx",
            () -> new ArchitecturyFlowingFluid.Flowing(GX_ATTRIBUTES));
    public static final RegistrySupplier<GXFluidBlock> GX_BLOCK = FLUID_BLOCKS.register("gx_block",
            () -> new GXFluidBlock(STILL_GX.get(),
                    class_4970.class_2251.method_9630(class_2246.field_10382).method_51371().method_50012(class_3619.field_15971)));

    public static void register() {
    }
}
