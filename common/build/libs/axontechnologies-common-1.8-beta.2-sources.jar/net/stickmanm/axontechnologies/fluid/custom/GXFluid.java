package net.stickmanm.axontechnologies.fluid.custom;

import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import net.minecraft.world.*;
import net.stickmanm.axontechnologies.fluid.ModFluids;
import net.stickmanm.axontechnologies.item.ModItems;

public abstract class GXFluid extends class_3609 {


    @Override
    protected boolean method_15737(class_1937 world) {
        return false;
    }

    @Override
    protected void method_15730(class_1936 world, class_2338 pos, class_2680 state) {
        class_2586 blockEntity = state.method_31709() ? world.method_8321(pos) : null;
        class_2248.method_9610(state, world, pos, blockEntity);
    }

    @Override
    protected int method_15733(class_4538 world) {
        return 1;
    }

    @Override
    protected int method_15739(class_4538 world) {
        return 1;
    }

    @Override
    public boolean method_15780(class_3611 fluid) {
        return fluid == method_15751() || fluid == method_15750();
    }

    @Override
    public int method_15779(class_3610 state) {
        return 0;
    }

    @Override
    public int method_15789(class_4538 world) {
        return 5;
    }

    @Override
    protected float method_15784() {
        return 200f;
    }

    @Override
    protected boolean method_15777(class_3610 state, class_1922 world, class_2338 pos, class_3611 fluid, class_2350 direction) {
        return false;
    }


    @Override
    public class_3611 method_15751() {
        return ModFluids.STILL_GX.get();
    }

    @Override
    public class_3611 method_15750() {
        return ModFluids.FLOWING_GX.get();
    }

    @Override
    public class_1792 method_15774() {
        return ModItems.GX_BUCKET.get();
    }

    @Override
    protected class_2680 method_15790(class_3610 state) {
        return ModFluids.GX_BLOCK.get().method_9564().method_11657(class_2741.field_12538, method_15741(state));
    }


    public static class Flowing extends GXFluid {
        @Override
        protected void method_15775(class_2689.class_2690<class_3611, class_3610> builder) {
            super.method_15775(builder);
            builder.method_11667(field_15900);
        }

        @Override
        public int method_15779(class_3610 state) {
            return state.method_11654(field_15900);
        }

        @Override
        public boolean method_15793(class_3610 state) {
            return false;
        }
    }

    public static class Still extends GXFluid {
        @Override
        public int method_15779(class_3610 state) {
            return 8;
        }

        @Override
        public boolean method_15793(class_3610 state) {
            return true;
        }
    }





}
