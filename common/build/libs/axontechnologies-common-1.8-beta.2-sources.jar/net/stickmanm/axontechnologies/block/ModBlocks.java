package net.stickmanm.axontechnologies.block;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2373;
import net.minecraft.class_2397;
import net.minecraft.class_2431;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_4719;
import net.minecraft.class_6019;
import net.minecraft.class_7924;
import net.minecraft.class_8177;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;
import net.stickmanm.axontechnologies.block.custom.AxonAlloyTntBlock;
import net.stickmanm.axontechnologies.block.custom.CorruptionBlock;
import net.stickmanm.axontechnologies.block.custom.RedThunderaniumTntBlock;
import net.stickmanm.axontechnologies.block.custom.ThunderaniumTntBlock;
import net.stickmanm.axontechnologies.item.ModItems;
import net.stickmanm.axontechnologies.world.tree.CorruptedSaplingGenerator;
import net.stickmanm.axontechnologies.world.tree.ThunderedSaplingGenerator;

import java.util.function.Supplier;
import java.util.function.ToIntFunction;

public class ModBlocks {

    public static final DeferredRegister<class_2248> BLOCKS =
            DeferredRegister.create(AxonTechnologiesConstants.MOD_ID, class_7924.field_41254);

    //Ore
    public static final RegistrySupplier<class_2248> MIMICARIUM_ORE = registerBlock("mimicarium_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_10571).method_9632(4.0f).method_29292(),
                    class_6019.method_35017(3, 7)));

    public static final RegistrySupplier<class_2248> DEEPSLATE_MIMICARIUM_ORE = registerBlock("deepslate_mimicarium_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_29026).method_9632(4.0f).method_29292(),
                    class_6019.method_35017(3, 7)));

    public static final RegistrySupplier<class_2248> FAKESTONE_IRON_ORE = registerBlock("fakestone_iron_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_10212).method_29292(),
                    class_6019.method_35017(3, 7)));

    public static final RegistrySupplier<class_2248> FAKESTONE_GOLD_ORE = registerBlock("fakestone_gold_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_10571).method_29292(),
                    class_6019.method_35017(3, 7)));

    public static final RegistrySupplier<class_2248> FAKESLATE_IRON_ORE = registerBlock("fakeslate_iron_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_29027).method_29292(),
                    class_6019.method_35017(3, 7)));

    public static final RegistrySupplier<class_2248> FAKESLATE_GOLD_ORE = registerBlock("fakeslate_gold_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_29026).method_29292(),
                    class_6019.method_35017(3, 7)));

    //Thundered Tree
    public static final RegistrySupplier<class_2248> THUNDERED_LOG = registerBlock("thundered_log",
            () -> new class_2465(class_2248.Settings.method_9630(class_2246.field_10431).method_9632(2.0f)));
    public static final RegistrySupplier<class_2248> THUNDERED_WOOD = registerBlock("thundered_wood",
            () -> new class_2465(class_2248.Settings.method_9630(class_2246.field_10126).method_9632(2.0f)));
    public static final RegistrySupplier<class_2248> STRIPPED_THUNDERED_LOG = registerBlock("stripped_thundered_log",
            () -> new class_2465(class_2248.Settings.method_9630(class_2246.field_10519).method_9632(2.0f)));
    public static final RegistrySupplier<class_2248> STRIPPED_THUNDERED_WOOD = registerBlock("stripped_thundered_wood",
            () -> new class_2465(class_2248.Settings.method_9630(class_2246.field_10250).method_9632(2.0f)));

    public static final RegistrySupplier<class_2248> THUNDERED_PLANKS = registerBlock("thundered_planks",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10161).method_9632(2.0f)));

    public static final RegistrySupplier<class_2248> THUNDERED_SLAB = registerBlock("thundered_slab",
            () -> new class_2482(class_2248.Settings.method_9630(THUNDERED_PLANKS.get())));

    public static final RegistrySupplier<class_2248> THUNDERED_STAIRS = registerBlock("thundered_stairs",
            () -> new class_2510(THUNDERED_PLANKS.get().method_9564(), class_2248.Settings.method_9630(THUNDERED_PLANKS.get())));

    public static final RegistrySupplier<class_2248> THUNDERED_FENCE = registerBlock("thundered_fence",
            () -> new class_2354(class_2248.Settings.method_9630(THUNDERED_PLANKS.get())));

    public static final RegistrySupplier<class_2248> THUNDERED_FENCE_GATE = registerBlock("thundered_fence_gate",
            () -> new class_2349(class_2248.Settings.method_9630(THUNDERED_PLANKS.get()), class_4719.field_22183));

    public static final RegistrySupplier<class_2248> THUNDERED_DOOR = registerBlock("thundered_door",
            () -> new class_2323(class_2248.Settings.method_9630(THUNDERED_PLANKS.get()), class_8177.field_42830));

    public static final RegistrySupplier<class_2248> THUNDERED_TRAPDOOR = registerBlock("thundered_trapdoor",
            () -> new class_2533(class_2248.Settings.method_9630(THUNDERED_PLANKS.get()), class_8177.field_42830));

    public static final RegistrySupplier<class_2248> THUNDERED_BUTTON = registerBlock("thundered_button",
            () -> new class_2269(class_2248.Settings.method_9630(THUNDERED_PLANKS.get()), class_8177.field_42830, 30,true));

    public static final RegistrySupplier<class_2248> THUNDERED_PRESSURE_PLATE = registerBlock("thundered_pressure_plate",
            () -> new class_2440(class_2440.class_2441.field_11361, class_2248.Settings.method_9630(THUNDERED_PLANKS.get()), class_8177.field_42830));


    public static final RegistrySupplier<class_2248> THUNDERED_LEAVES = registerBlock("thundered_leaves",
            () -> new class_2397(class_2248.Settings.method_9630(class_2246.field_10503).method_9632(1.0f).method_29292()));

    public static final RegistrySupplier<class_2248> THUNDERED_SAPLING = registerBlock("thundered_sapling",
            () -> new class_2473(new ThunderedSaplingGenerator(), class_2248.Settings.method_9630(class_2246.field_10394)));


    //Corrupted Tree
    public static final RegistrySupplier<class_2248> CORRUPTED_LOG = registerBlock("corrupted_log",
            () -> new class_2465(class_2248.Settings.method_9630(class_2246.field_10431).method_9632(2.0f)));
    public static final RegistrySupplier<class_2248> CORRUPTED_WOOD = registerBlock("corrupted_wood",
            () -> new class_2465(class_2248.Settings.method_9630(class_2246.field_10126).method_9632(2.0f)));
    public static final RegistrySupplier<class_2248> STRIPPED_CORRUPTED_LOG = registerBlock("stripped_corrupted_log",
            () -> new class_2465(class_2248.Settings.method_9630(class_2246.field_10519).method_9632(2.0f)));
    public static final RegistrySupplier<class_2248> STRIPPED_CORRUPTED_WOOD = registerBlock("stripped_corrupted_wood",
            () -> new class_2465(class_2248.Settings.method_9630(class_2246.field_10250).method_9632(2.0f)));

    public static final RegistrySupplier<class_2248> CORRUPTED_PLANKS = registerBlock("corrupted_planks",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10161).method_9632(2.0f)));

    public static final RegistrySupplier<class_2248> CORRUPTED_SAPLING = registerBlock("corrupted_sapling",
            () -> new class_2473(new CorruptedSaplingGenerator(), class_2248.Settings.method_9630(class_2246.field_10394)));

    //Portal Blocks
    public static final RegistrySupplier<class_2248> VOIDSTONE = registerBlock("voidstone",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10340).method_9632(4.0f).method_29292()));
    public static final RegistrySupplier<class_2248> MIMIMCARIUM_PORTAL_FRAME = registerBlock("mimicarium_portal_frame",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10085).method_9632(4.0f).method_29292()));

    public static final RegistrySupplier<class_2248> THUNDERANIUM_PORTAL_FRAME = registerBlock("thunderanium_portal_frame",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10085).method_9632(4.0f).method_29292()));

    public static final RegistrySupplier<class_2248> CORRUPTION_PORTAL_FRAME = registerBlock("corruption_portal_frame",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10085).method_9632(4.2f).method_29292()));

    //Dreadstone + Dreadstone Ores
    public static final RegistrySupplier<class_2248> DREADSTONE = registerBlock("dreadstone",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10340).method_9632(2.4f).method_29292()));

    public static final RegistrySupplier<class_2248> REINFORCED_DREADSTONE = registerBlock("reinforced_dreadstone",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_22108).method_9629(255f, Float.MAX_VALUE).method_29292().method_9631(state -> 15).method_9626(class_2498.field_22150)));

    public static final RegistrySupplier<class_2248> REINFORCED_DREADSTONE_SLAB = registerBlock("reinforced_dreadstone_slab",
            () -> new class_2482(class_2248.Settings.method_9630(REINFORCED_DREADSTONE.get())));

    public static final RegistrySupplier<class_2248> REINFORCED_DREADSTONE_STAIRS = registerBlock("reinforced_dreadstone_stairs",
            () -> new class_2510(REINFORCED_DREADSTONE.get().method_9564(), class_2248.Settings.method_9630(REINFORCED_DREADSTONE.get())));

    public static final RegistrySupplier<class_2248> REINFORCED_DREADSTONE_WALL = registerBlock("reinforced_dreadstone_wall",
            () -> new class_2544(class_2248.Settings.method_9630(REINFORCED_DREADSTONE.get())));

    public static final RegistrySupplier<class_2248> REINFORCED_DREADSTONE_DOOR = registerBlock("reinforced_dreadstone_door",
            () -> new class_2323(class_2248.Settings.method_9630(REINFORCED_DREADSTONE.get()), class_8177.field_42830));

    public static final RegistrySupplier<class_2248> REINFORCED_DREADSTONE_TRAPDOOR = registerBlock("reinforced_dreadstone_trapdoor",
            () -> new class_2533(class_2248.Settings.method_9630(REINFORCED_DREADSTONE.get()), class_8177.field_42830));

    public static final RegistrySupplier<class_2248> REINFORCED_DREADSTONE_GLASS = registerBlock("reinforced_dreadstone_glass",
            () -> new class_2373(class_2248.Settings.method_9630(REINFORCED_DREADSTONE.get()).method_22488().method_26235((state, world, pos, entityType) -> false).method_26236((state, world, pos) -> false).method_26243((state, world, pos) -> false).method_26245((state, world, pos) -> false)));

    public static final RegistrySupplier<class_2248> DREADSTONE_DIAMOND_ORE = registerBlock("dreadstone_diamond_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_29029).method_9632(2.4f).method_29292(),
                    class_6019.method_35017(7, 10)));

    public static final RegistrySupplier<class_2248> DREADSTONE_THUNDERANIUM_ORE = registerBlock("dreadstone_thunderanium_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_29029).method_9632(2.4f).method_29292(),
                    class_6019.method_35017(10, 17)));
    public static final RegistrySupplier<class_2248> DREADSTONE_NETHERITE_ORE = registerBlock("dreadstone_netherite_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_22109).method_9632(4.5f).method_29292(),
                    class_6019.method_35017(10, 17)));

    public static final RegistrySupplier<class_2248> VOID_COAL_ORE = registerBlock("void_coal_ore",
            () -> new class_2431(class_2248.Settings.method_9630(class_2246.field_10418).method_9632(2.4f).method_29292(),
                    class_6019.method_35017(7, 10)));

    public static final RegistrySupplier<class_2248> VOID_COAL_BLOCK = registerBlock("void_coal_block",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10340).method_9632(2.4f).method_29292()));



    //MISC
    public static final RegistrySupplier<class_2248> OCTUPLE_COMPRESSED_COBBLESTONE = registerBlock("octuple_compressed_cobblestone",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10445).method_9632(2.1f).method_29292()));

    //TNT
    public static final RegistrySupplier<class_2248> THUNDERANIUM_TNT = registerBlock("thunderanium_tnt",
            () -> new ThunderaniumTntBlock(class_2248.Settings.method_9630(class_2246.field_10085)));

    public static final RegistrySupplier<class_2248> RED_THUNDERANIUM_TNT = registerBlock("red_thunderanium_tnt",
            () -> new RedThunderaniumTntBlock(class_2248.Settings.method_9630(class_2246.field_10085)));

    public static final RegistrySupplier<class_2248> AXON_ALLOY_TNT = registerBlock("axon_alloy_tnt",
            () -> new AxonAlloyTntBlock(class_2248.Settings.method_9630(class_2246.field_10085)));


    //Mimic World
    public static final RegistrySupplier<class_2248> FAKESTONE = registerBlock("fakestone",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10340).method_9632(2.1f).method_29292()));


    public static final RegistrySupplier<class_2248> FAKESLATE = registerBlock("fakeslate",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_28888).method_9632(2.4f).method_29292()));

    //Thunderlands
    public static final RegistrySupplier<class_2248> CHARGED_DIRT = registerBlock("charged_dirt",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10566).method_9632(0.6f)));

    public static final RegistrySupplier<class_2248> THUNDERED_STONE = registerBlock("thundered_stone",
            () -> new class_2248(class_2248.Settings.method_9630(class_2246.field_10340).method_9632(2.1f).method_29292()));

    public static final RegistrySupplier<class_2248> THUNDERANIUM_ORE = registerBlock("thunderanium_ore",
            () -> new class_2431(class_2248.Settings.method_9630(THUNDERED_STONE.get()).method_9632(2.5f).method_29292().method_9631(state -> 10),
                    class_6019.method_35017(15, 25)));

    public static final RegistrySupplier<class_2248> RENDERIUM_ORE = registerBlock("renderium_ore",
            () -> new class_2431(class_2248.Settings.method_9630(THUNDERED_STONE.get()).method_9632(2.5f).method_29292().method_9631(state -> 10),
                    class_6019.method_35017(15, 25)));

    //Corruptionlands
    public static final RegistrySupplier<class_2248> CORRUPTED_DIRT = registerBlock("corrupted_dirt",
            () -> new class_2248(class_2248.Settings.method_9630(CHARGED_DIRT.get()).method_9632(0.8f)));

    public static final RegistrySupplier<class_2248> CORRUPTED_STONE = registerBlock("corrupted_stone",
            () -> new class_2248(class_2248.Settings.method_9630(THUNDERED_STONE.get()).method_9632(2.3f).method_29292()));
    public static final RegistrySupplier<class_2248> CORRUPTION_BLOCK = registerBlock("corruption_block",
            () -> new CorruptionBlock(class_2248.Settings.method_9630(THUNDERED_STONE.get()).method_9632(2.3f).method_29292()));

    public static final RegistrySupplier<class_2248> CORRUPTINITE_ORE = registerBlock("corruptinite_ore",
            () -> new class_2431(class_2248.Settings.method_9630(CORRUPTED_STONE.get()).method_9632(2.5f).method_29292().method_9631(state -> 10),
                    class_6019.method_35017(20, 27)));

    public static final RegistrySupplier<class_2248> DENDERIUM_ORE = registerBlock("denderium_ore",
            () -> new class_2431(class_2248.Settings.method_9630(CORRUPTED_STONE.get()).method_9632(2.5f).method_29292().method_9631(state -> 10),
                    class_6019.method_35017(15, 25)));

    //Dimension Core Ores
    public static final RegistrySupplier<class_2248> MWDC_ORE = registerBlock("mimic_world_dimension_core_ore",
            () -> new class_2431(class_2248.Settings.method_9630(FAKESLATE.get()).method_9632(4.5f).method_29292().method_9631(state -> 15),
                    class_6019.method_35017(30, 37)));

    public static final RegistrySupplier<class_2248> DCDC_ORE = registerBlock("dread_caverns_dimension_core_ore",
            () -> new class_2431(class_2248.Settings.method_9630(DREADSTONE.get()).method_9632(4.5f).method_29292().method_9631(state -> 15),
                    class_6019.method_35017(30, 37)));

    public static final RegistrySupplier<class_2248> TLDC_ORE = registerBlock("thunderlands_dimension_core_ore",
            () -> new class_2431(class_2248.Settings.method_9630(THUNDERED_STONE.get()).method_9632(4.5f).method_29292().method_9631(state -> 15),
                    class_6019.method_35017(30, 37)));

    public static final RegistrySupplier<class_2248> CLDC_ORE = registerBlock("corruptionlands_dimension_core_ore",
            () -> new class_2431(class_2248.Settings.method_9630(CORRUPTED_STONE.get()).method_9632(4.5f).method_29292().method_9631(state -> 15),
                    class_6019.method_35017(30, 37)));




    private static <T extends class_2248> RegistrySupplier<T> registerBlock(String name, Supplier<T> block) {
        RegistrySupplier<T> blockSupplier = BLOCKS.register(name, block);
        registerBlockItem(name, blockSupplier);
        return blockSupplier;
    }



    private static <T extends class_2248> RegistrySupplier<class_1792> registerBlockItem(String name, RegistrySupplier<T> block) {
        return ModItems.ITEMS.register(name, () -> new class_1747(block.get(), new class_1792.class_1793()));
    }




    /*public static void registerModBlocks() {
        AxonTechnologies.LOGGER.info("Registering ModBlocks for " + AxonTechnologiesConstants.MOD_ID);
    }*/
}
