package net.stickmanm.axontechnologies.block.custom;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.stickmanm.axontechnologies.entity.custom.ThunderaniumTntEntity;
import org.jetbrains.annotations.Nullable;

public class ThunderaniumTntBlock extends class_2248 {
    public static final class_2746 UNSTABLE;

    public ThunderaniumTntBlock(class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)this.method_9564().method_11657(UNSTABLE, false));
    }

    public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        if (!oldState.method_27852(state.method_26204())) {
            if (world.method_49803(pos)) {
                primeTnt(world, pos);
                world.method_8650(pos, false);
            }

        }
    }

    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        if (world.method_49803(pos)) {
            primeTnt(world, pos);
            world.method_8650(pos, false);
        }

    }

    public void method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!world.method_8608() && !player.method_7337() && (Boolean)state.method_11654(UNSTABLE)) {
            primeTnt(world, pos);
        }

        super.method_9576(world, pos, state, player);
    }

    public void method_9586(class_1937 world, class_2338 pos, class_1927 explosion) {
        if (!world.field_9236) {
            ThunderaniumTntEntity tntEntity = new ThunderaniumTntEntity(world, (double)pos.method_10263() + (double)0.5F, (double)pos.method_10264(), (double)pos.method_10260() + (double)0.5F, explosion.method_8347());
            int i = tntEntity.method_6969();
            tntEntity.method_6967((short)(world.field_9229.method_43048(i / 4) + i / 8));
            world.method_8649(tntEntity);
        }
    }

    public static void primeTnt(class_1937 world, class_2338 pos) {
        primeTnt(world, pos, (class_1309)null);
    }

    private static void primeTnt(class_1937 world, class_2338 pos, @Nullable class_1309 igniter) {
        if (!world.field_9236) {
            ThunderaniumTntEntity tntEntity = new ThunderaniumTntEntity(world, (double)pos.method_10263() + (double)0.5F, (double)pos.method_10264(), (double)pos.method_10260() + (double)0.5F, igniter);
            world.method_8649(tntEntity);
            world.method_43128((class_1657)null, tntEntity.method_23317(), tntEntity.method_23318(), tntEntity.method_23321(), class_3417.field_15079, class_3419.field_15245, 1.0F, 1.0F);
            world.method_33596(igniter, class_5712.field_28727, pos);
        }
    }

    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_1799 itemStack = player.method_5998(hand);
        if (!itemStack.method_31574(class_1802.field_8884) && !itemStack.method_31574(class_1802.field_8814)) {
            return super.method_9534(state, world, pos, player, hand, hit);
        } else {
            primeTnt(world, pos, player);
            world.method_8652(pos, class_2246.field_10124.method_9564(), 11);
            class_1792 item = itemStack.method_7909();
            if (!player.method_7337()) {
                if (itemStack.method_31574(class_1802.field_8884)) {
                    itemStack.method_7956(1, player, (playerx) -> playerx.method_20236(hand));
                } else {
                    itemStack.method_7934(1);
                }
            }

            player.method_7259(class_3468.field_15372.method_14956(item));
            return class_1269.method_29236(world.field_9236);
        }
    }

    public void method_19286(class_1937 world, class_2680 state, class_3965 hit, class_1676 projectile) {
        if (!world.field_9236) {
            class_2338 blockPos = hit.method_17777();
            class_1297 entity = projectile.method_24921();
            if (projectile.method_5809() && projectile.method_36971(world, blockPos)) {
                primeTnt(world, blockPos, entity instanceof class_1309 ? (class_1309)entity : null);
                world.method_8650(blockPos, false);
            }
        }

    }

    public boolean method_9533(class_1927 explosion) {
        return false;
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{UNSTABLE});
    }

    static {
        UNSTABLE = class_2741.field_12539;
    }
}