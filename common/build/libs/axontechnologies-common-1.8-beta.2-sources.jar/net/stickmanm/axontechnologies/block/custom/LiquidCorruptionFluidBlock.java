package net.stickmanm.axontechnologies.block.custom;

import net.minecraft.class_1267;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.stickmanm.axontechnologies.effect.ModEffects;

public class LiquidCorruptionFluidBlock extends class_2404 {
    public LiquidCorruptionFluidBlock(class_3609 fluid, class_2251 settings) {
        super(fluid, settings);
    }

    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        if (!world.field_9236 && world.method_8407() != class_1267.field_5801) {
            if (entity instanceof class_1309 livingEntity) {
                if (!livingEntity.method_5679(world.method_48963().method_48809())) {
                    livingEntity.method_6092(new class_1293(ModEffects.THUNDER_POISONING.get(), 4));
                    livingEntity.method_6016(ModEffects.ANTI_CORRUPTED_GLITCHSTER.get());
                }
            }

        }
    }
}