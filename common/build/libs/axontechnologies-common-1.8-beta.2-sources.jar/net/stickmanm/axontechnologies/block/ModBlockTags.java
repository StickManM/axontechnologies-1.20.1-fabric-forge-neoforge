package net.stickmanm.axontechnologies.block;

import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.stickmanm.axontechnologies.AxonTechnologies;
import net.stickmanm.axontechnologies.AxonTechnologiesConstants;

public class ModBlockTags {
    //Mimicarium Ore Replaceables
    public static final class_6862<class_2248> MIMICARIUM_REPLACEABLE_STONE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "mimicarium_replaceable"));
    public static final class_6862<class_2248> MIMICARIUM_REPLACEABLE_DEEPSLATE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "mimicarium_replaceable_deepslate"));
    public static final class_6862<class_2248> FAKESLATE_REPLACEABLE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "fakeslate_replaceable"));
    public static final class_6862<class_2248> FAKESTONE_REPLACEABLE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "fakestone_replaceable"));

    //MISC
    public static final class_6862<class_2248> DREADSTONE_REPLACEABLE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "dreadstone_replaceable"));
    public static final class_6862<class_2248> THUNDERED_STONE_REPLACEABLE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "thundered_stone_replaceable"));
    public static final class_6862<class_2248> CORRUPTED_STONE_REPLACEABLE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "corrupted_stone_replaceable"));
    public static final class_6862<class_2248> VOIDSTONE_REPLACEABLE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "voidstone_replaceable"));

    public static final class_6862<class_2248> REINFORCED_DREADSTONE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "reinforced_dreadstone"));

    public static final class_6862<class_2248> CORRUPTION = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "corruption"));

    public static final class_6862<class_2248> THUNDERED_PLANKS_CONVERTIBLE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "thundered_planks_convertible"));
    public static final class_6862<class_2248> CORRUPTED_PLANKS_CONVERTIBLE = class_6862.method_40092(class_7924.field_41254, new class_2960(AxonTechnologiesConstants.MOD_ID, "corrupted_planks_convertible"));





    public static void registerModTags() {
        AxonTechnologies.LOGGER.info("Registering ModTags for " + AxonTechnologiesConstants.MOD_ID);
    }
}
