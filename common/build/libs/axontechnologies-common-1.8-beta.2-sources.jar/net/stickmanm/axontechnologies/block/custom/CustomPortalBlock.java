package net.stickmanm.axontechnologies.block.custom;

import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_5819;
import net.stickmanm.axontechnologies.world.portal.ModPortals;
import net.stickmanm.axontechnologies.world.portal.PortalDef;

/**
 * Portal block shared by all of the mod's portals (one registered instance per {@link PortalDef}).
 * AXIS = the plane the portal lies in: X (spans X/Y), Z (spans Z/Y) or Y (flat, spans X/Z).
 */
public class CustomPortalBlock extends class_2248 {
    public static final class_2754<class_2350.class_2351> AXIS = class_2741.field_12496;

    private static final class_265 X_SHAPE = class_2248.method_9541(0, 0, 6, 16, 16, 10);
    private static final class_265 Z_SHAPE = class_2248.method_9541(6, 0, 0, 10, 16, 16);
    private static final class_265 Y_SHAPE = class_2248.method_9541(0, 6, 0, 16, 10, 16);

    private final PortalDef def;

    public CustomPortalBlock(PortalDef def, class_2251 settings) {
        super(settings);
        this.def = def;
        method_9590(method_9595().method_11664().method_11657(AXIS, class_2350.class_2351.field_11048));
    }

    public PortalDef getDef() {
        return def;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(AXIS);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(AXIS)) {
            case field_11051 -> Z_SHAPE;
            case field_11052 -> Y_SHAPE;
            default -> X_SHAPE;
        };
    }

    /** The four directions that stay inside the portal's plane. */
    public static class_2350[] planeDirections(class_2350.class_2351 axis) {
        return switch (axis) {
            case field_11048 -> new class_2350[]{class_2350.field_11034, class_2350.field_11039, class_2350.field_11036, class_2350.field_11033};
            case field_11051 -> new class_2350[]{class_2350.field_11043, class_2350.field_11035, class_2350.field_11036, class_2350.field_11033};
            default -> new class_2350[]{class_2350.field_11034, class_2350.field_11039, class_2350.field_11043, class_2350.field_11035};
        };
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState,
                                                class_1936 world, class_2338 pos, class_2338 neighborPos) {
        for (class_2350 d : planeDirections(state.method_11654(AXIS))) {
            if (d == direction) {
                // a frame block or another portal block of ours has to stay there, otherwise the portal collapses
                if (!neighborState.method_27852(this) && !neighborState.method_27852(def.frame.get()))
                    return class_2246.field_10124.method_9564();
            }
        }
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        if (world.method_8608() || !(entity instanceof class_3222 player))
            return;
        if (player.method_5765() || player.method_5782())
            return;
        ModPortals.playerInPortal(player, def);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (random.method_43048(4) == 0) {
            world.method_8406(class_2398.field_11214,
                    pos.method_10263() + random.method_43058(), pos.method_10264() + random.method_43058(), pos.method_10260() + random.method_43058(),
                    (random.method_43058() - 0.5) * 0.5, (random.method_43058() - 0.5) * 0.5, (random.method_43058() - 0.5) * 0.5);
        }
    }

    @Override
    public class_1799 method_9574(class_1922 world, class_2338 pos, class_2680 state) {
        return class_1799.field_8037;
    }
}
