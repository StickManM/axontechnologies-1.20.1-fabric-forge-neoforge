package net.stickmanm.axontechnologies.block.custom;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_3965;
import net.stickmanm.axontechnologies.block.ModBlockTags;
import net.stickmanm.axontechnologies.block.ModBlocks;
import net.stickmanm.axontechnologies.fluid.ModFluids;
import net.stickmanm.axontechnologies.item.ModItems;

public class CorruptionBlock extends class_2248 {
    public CorruptionBlock(class_2251 settings) {
        super(settings);
    }
    private void spreadBlock(class_1937 world, class_2338 centerPos) {
        // Try to find a random position around the center block (in a 3x3x3 cube)
        class_2338 targetPos = centerPos.method_10069(
                world.field_9229.method_43048(3) - 1,
                world.field_9229.method_43048(3) - 1,
                world.field_9229.method_43048(3) - 1
        );

        // Ensure the target position is not the center block itself
        if (targetPos.equals(centerPos)) {
            return;
        }

        // Check if the target block is replaceable (like air, grass, etc.)
        class_2680 targetState = world.method_8320(targetPos);

        if (targetState.method_26164(class_3481.field_28992) || targetState.method_26164(class_3481.field_28993) || targetState.method_26204().equals(ModBlocks.THUNDERED_STONE)) {
            world.method_8652(targetPos, ModBlocks.CORRUPTED_STONE.get().method_9564(), 3);
        } else if (targetState.method_26164(class_3481.field_29822)) {
            world.method_8652(targetPos, ModBlocks.CORRUPTED_DIRT.get().method_9564(), 3);
        } else if (targetState.method_26204().equals(ModBlocks.THUNDERANIUM_ORE)) {
            world.method_8652(targetPos, ModBlocks.CORRUPTINITE_ORE.get().method_9564(), 3);
        } else if (targetState.method_26204().equals(ModFluids.LIQUID_THUNDER_BLOCK.get())) {
            world.method_8652(targetPos, ModFluids.LIQUID_CORRUPTION_BLOCK.get().method_9564(), 3);
        } else if (targetState.method_26204().equals(ModBlocks.RENDERIUM_ORE)) {
            world.method_8652(targetPos, ModBlocks.DENDERIUM_ORE.get().method_9564(), 3);
        }
        else if (!targetState.method_26164(ModBlockTags.CORRUPTION)){
            // Place the custom block at the target position
            world.method_8652(targetPos, this.method_9564(), 3);
        }
    }


    /**
     * This method runs every time the block is right-clicked.
     */
    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos,
                              class_1657 player, class_1268 hand, class_3965 hit) {

        class_1799 stack = player.method_5998(hand);

        if (!world.method_8608()) {

            // 🟢 MOSS BLOCK BEHAVIOR: Spreading with Bone Meal
            if (stack.method_7909() == ModItems.DARK_ESSENCE) {

                // Attempt to spread the block multiple times, just like Bone Meal
                int spreadAttempts = 6;
                for (int i = 0; i < spreadAttempts; i++) {
                    spreadBlock(world, pos);
                }

                // Play bone meal sound
                world.method_8396(null, pos, class_3417.field_37364,
                        class_3419.field_15245, 1.0F, 1.0F);

                // Consume the item
                if (!player.method_31549().field_7477) {
                    stack.method_7934(1);
                }
                return class_1269.field_5812;

                // 🟢 CUSTOM ITEM BEHAVIOR: Instantly transform the block (example)
            } /*else if (stack.getItem() == ModItems.RAZZORIUM) {

                // Example: Transform the spreading block into something valuable!
                world.setBlockState(pos, Blocks.DIAMOND_BLOCK.getDefaultState(), 3);

                // Optional: Play a cool sound effect
                world.playSound(null, pos, SoundEvents.BLOCK_RESPAWN_ANCHOR_CHARGE,
                        SoundCategory.BLOCKS, 1.0F, 1.0F);

                // Consume the item
                if (!player.getAbilities().creativeMode) {
                    stack.decrement(1);
                }
                return ActionResult.SUCCESS;
            }*/
        }

        // If no custom action was taken, return PASS
        return super.method_9534(state, world, pos, player, hand, hit);
    }


}
